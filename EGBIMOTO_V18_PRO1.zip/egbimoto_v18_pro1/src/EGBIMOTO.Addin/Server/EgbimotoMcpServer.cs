// EGBIMOTO V17 — EgbimotoMcpServer
// V16: 14 endpoint | V17: +3 (skills, skill/{id}, run-skill) = 17 endpoint
using System;
using System.IO;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading;
using EGBIMOTO.Core.Manifest;
using EGBIMOTO.Core.Ops;
using EGBIMOTO.Core.Skills;
using EGBIMOTO.Core.Translation;

namespace EGBIMOTO.Addin.Server
{
    public sealed class EgbimotoMcpServer
    {
        private readonly int _port;
        private readonly string? _token;
        private readonly RevitDispatcher _dispatcher;
        private readonly Func<string> _contractsPathProvider;
        private readonly Func<string, RevitDispatcher, string> _runManifestHandler;
        private readonly McpContextHandlers _ctx;
        private readonly McpPreviewHandler  _preview;
        private readonly McpSkillHandler       _skill;
        private readonly McpTranslationHandler _xlat;

        private HttpListener? _listener;
        private CancellationTokenSource? _cts;
        private Thread? _listenThread;

        public bool IsRunning { get; private set; }
        public int  Port      => _port;

        public EgbimotoMcpServer(
            RevitDispatcher dispatcher,
            Func<string> contractsPathProvider,
            Func<string, RevitDispatcher, string> runManifestHandler,
            OpRegistry registry,
            SkillRegistry skillRegistry,
            int port = 5577,
            string? token = null)
        {
            _dispatcher            = dispatcher            ?? throw new ArgumentNullException(nameof(dispatcher));
            _contractsPathProvider = contractsPathProvider ?? throw new ArgumentNullException(nameof(contractsPathProvider));
            _runManifestHandler    = runManifestHandler    ?? throw new ArgumentNullException(nameof(runManifestHandler));
            _port                  = port;
            _token                 = string.IsNullOrWhiteSpace(token) ? null : token;
            _ctx                   = new McpContextHandlers(dispatcher);
            _preview               = new McpPreviewHandler(dispatcher, registry);
            _skill                 = new McpSkillHandler(skillRegistry, dispatcher, runManifestHandler, _preview);
            // V18: TranslatorEngine — data/translation/ klasöründen yükle
            var translationDataDir = System.IO.Path.Combine(
                System.IO.Path.GetDirectoryName(typeof(EgbimotoMcpServer).Assembly.Location) ?? "",
                "data", "translation");
            var xlEngine = TranslatorEngine.Load(translationDataDir);
            _xlat = new McpTranslationHandler(xlEngine, dispatcher);
        }

        public void Start()
        {
            if (IsRunning) return;
            _listener = new HttpListener();
            _listener.Prefixes.Add($"http://127.0.0.1:{_port}/");
            _listener.Prefixes.Add($"http://localhost:{_port}/");
            try { _listener.Start(); }
            catch (HttpListenerException ex)
            { throw new InvalidOperationException($"MCP Server port {_port} açılamadı: {ex.Message}", ex); }
            _cts = new CancellationTokenSource();
            IsRunning = true;
            _listenThread = new Thread(() => ListenLoop(_cts.Token)) { IsBackground = true, Name = "EGBIMOTO-MCP-V17" };
            _listenThread.Start();
        }

        public void Stop()
        {
            if (!IsRunning) return;
            IsRunning = false;
            try { _cts?.Cancel();    } catch { }
            try { _listener?.Stop(); } catch { }
            try { _listener?.Close();} catch { }
            _listener = null;
        }

        private void ListenLoop(CancellationToken ct)
        {
            while (IsRunning && !ct.IsCancellationRequested && _listener != null)
            {
                HttpListenerContext ctx;
                try { ctx = _listener.GetContext(); } catch { break; }
                ThreadPool.QueueUserWorkItem(_ => HandleRequest(ctx));
            }
        }

        private void HandleRequest(HttpListenerContext ctx)
        {
            string method = ctx.Request.HttpMethod.ToUpperInvariant();
            string path   = ctx.Request.Url?.AbsolutePath.TrimEnd('/').ToLowerInvariant() ?? "";
            if (string.IsNullOrEmpty(path)) path = "/";

            try
            {
                if (_token != null && ctx.Request.Headers["X-EGBIMOTO-Token"] != _token)
                { WriteJson(ctx, 401, new { error = "Geçersiz token." }); return; }

                // V15.1 temel
                if      (method == "GET"  && path == "/health")     HandleHealth(ctx);
                else if (method == "GET"  && path == "/ops")        HandleOps(ctx);
                else if (method == "POST" && path == "/run")        HandleRun(ctx);
                else if (method == "POST" && path == "/validate")   HandleValidate(ctx);
                // V16 Tier 1
                else if (method == "POST" && path == "/preview")    _preview.Handle(ctx);
                else if (method == "GET"  && path == "/document")   _ctx.HandleDocument(ctx);
                else if (method == "GET"  && path == "/selection")  _ctx.HandleSelection(ctx);
                // V16 Tier 2
                else if (method == "GET"  && path == "/levels")     _ctx.HandleLevels(ctx);
                else if (method == "GET"  && path == "/rooms")      _ctx.HandleRooms(ctx);
                else if (method == "GET"  && path == "/families")   _ctx.HandleFamilies(ctx);
                else if (method == "GET"  && path == "/parameters") _ctx.HandleParameters(ctx);
                // V16 Tier 3
                else if (method == "POST" && path == "/undo")       _ctx.HandleUndo(ctx);
                else if (method == "POST" && path == "/explain")    _ctx.HandleExplain(ctx);
                else if (method == "POST" && path == "/generate")   _ctx.HandleGenerate(ctx);
                // V17 Skill
                else if (method == "GET"  && path == "/skills")                     _skill.HandleList(ctx);
                else if (method == "GET"  && path.StartsWith("/skills/"))            _skill.HandleGet(ctx, path.Substring("/skills/".Length));
                else if (method == "POST" && path == "/run-skill")                   _skill.HandleRunSkill(ctx);
                // V18 Translation
                else if (method == "GET"  && path == "/translate")                       _xlat.HandleTranslate(ctx);
                else if (method == "POST" && path == "/translate/batch")                 _xlat.HandleTranslateBatch(ctx);
                else if (method == "GET"  && path == "/translate/detect")                _xlat.HandleDetect(ctx);
                else if (method == "GET"  && path == "/translate/best-param")            _xlat.HandleBestParam(ctx);
                else WriteJson(ctx, 404, new { error = $"Bilinmeyen endpoint: {method} {path}" });
            }
            catch (Exception ex) { try { WriteJson(ctx, 500, new { error = ex.Message }); } catch { } }
        }

        private void HandleHealth(HttpListenerContext ctx)
        {
            string docTitle = "?";
            try { docTitle = _dispatcher.Invoke(app => app.ActiveUIDocument?.Document?.Title ?? "(doküman yok)", 10000) as string ?? "?"; }
            catch (Exception ex) { docTitle = $"(okunamadı: {ex.Message})"; }
            WriteJson(ctx, 200, new
            {
                status          = "ok",
                server          = "EGBIMOTO MCP Server",
                version         = "4.0",
                port            = _port,
                active_document = docTitle,
                skills_loaded   = new SkillRegistry(string.Empty).Count, // placeholder
                tools = new[]
                {
                    "egbimoto_health","egbimoto_list_ops","egbimoto_run_manifest",
                    "egbimoto_preview_manifest","egbimoto_get_document","egbimoto_get_selection",
                    "egbimoto_get_levels","egbimoto_get_rooms","egbimoto_get_families","egbimoto_search_parameters",
                    "egbimoto_undo_last","egbimoto_explain_failure","egbimoto_generate_manifest",
                    "egbimoto_list_skills","egbimoto_get_skill","egbimoto_run_skill",
                    "egbimoto_translate","egbimoto_translate_batch","egbimoto_best_param",
                },
            });
        }

        private void HandleOps(HttpListenerContext ctx)
        {
            var p = _contractsPathProvider();
            if (!File.Exists(p)) { WriteJson(ctx, 500, new { error = $"op_contracts.json bulunamadı: {p}" }); return; }
            WriteRaw(ctx, 200, File.ReadAllText(p, Encoding.UTF8));
        }

        private void HandleRun(HttpListenerContext ctx)
        {
            string body = ReadBody(ctx);
            if (string.IsNullOrWhiteSpace(body)) { WriteJson(ctx, 400, new { error = "Boş gövde." }); return; }
            try { WriteRaw(ctx, 200, _runManifestHandler(body, _dispatcher)); }
            catch (Exception ex) { WriteJson(ctx, 500, new { success = false, error = ex.Message }); }
        }

        private void HandleValidate(HttpListenerContext ctx)
        {
            string body = ReadBody(ctx);
            if (string.IsNullOrWhiteSpace(body)) { WriteJson(ctx, 400, new { error = "Boş gövde." }); return; }
            try
            {
                var opts = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var manifest = JsonSerializer.Deserialize<EgManifest>(body, opts);
                if (manifest == null) { WriteJson(ctx, 200, new { valid = false, errors = new[] { "Parse edilemedi." } }); return; }
                var knownOps = LoadOpNames(_contractsPathProvider());
                var errors = new System.Collections.Generic.List<string>();
                foreach (var step in manifest.Steps)
                {
                    if (string.IsNullOrWhiteSpace(step.Op)) errors.Add($"Adım '{step.Id}': op boş.");
                    else if (knownOps.Count > 0 && !knownOps.Contains(step.Op)) errors.Add($"Adım '{step.Id}': bilinmeyen op '{step.Op}'.");
                }
                if (manifest.IsAtomic)
                {
                    var ownTx = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "kalip_all","export_ifc4_csb2026","export_xlsx" };
                    foreach (var step in manifest.Steps)
                        if (ownTx.Contains(step.Op)) errors.Add($"'{step.Op}' atomic ile uyumsuz — transaction_policy='none' kullanın.");
                }
                WriteJson(ctx, 200, new { valid = errors.Count == 0, title = manifest.Title, step_count = manifest.Steps.Count, errors });
            }
            catch (Exception ex) { WriteJson(ctx, 200, new { valid = false, errors = new[] { ex.Message } }); }
        }

        private static HashSet<string> LoadOpNames(string contractsPath)
        {
            var set = new HashSet<string>(StringComparer.Ordinal);
            try { if (!File.Exists(contractsPath)) return set; using var doc = JsonDocument.Parse(File.ReadAllText(contractsPath, Encoding.UTF8)); foreach (var p in doc.RootElement.EnumerateObject()) set.Add(p.Name); } catch { }
            return set;
        }

        private static string ReadBody(HttpListenerContext ctx)
        { using var r = new StreamReader(ctx.Request.InputStream, ctx.Request.ContentEncoding ?? Encoding.UTF8); return r.ReadToEnd(); }

        private static void WriteJson(HttpListenerContext ctx, int status, object payload)
            => WriteRaw(ctx, status, JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = false }));

        private static void WriteRaw(HttpListenerContext ctx, int status, string json)
        {
            var bytes = Encoding.UTF8.GetBytes(json);
            ctx.Response.StatusCode = status; ctx.Response.ContentType = "application/json; charset=utf-8";
            ctx.Response.ContentLength64 = bytes.Length;
            ctx.Response.OutputStream.Write(bytes, 0, bytes.Length); ctx.Response.OutputStream.Close();
        }
    }
}
