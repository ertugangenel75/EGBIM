// EGBIMOTO V16 — McpContextHandlers
// Hata düzeltmeleri:
//   CS1061 Level.IsBuildingStory   → get_Parameter(BuiltInParameter.LEVEL_IS_BUILDING_STORY)
//   CS1061 Room.Phase              → get_Parameter(BuiltInParameter.ROOM_PHASE)
//   CS0118 Family namespace        → Autodesk.Revit.DB.Family (tam niteleme)
//   CS8121 InternalDefinition cast → ExternalDefinition only (mevcut codebase deseni)

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using EGBIMOTO.Core.MCP;

namespace EGBIMOTO.Addin.Server
{
    public sealed class McpContextHandlers
    {
        private readonly RevitDispatcher _dispatcher;

        private static readonly JsonSerializerOptions _json = new()
        {
            WriteIndented = false,
            DefaultIgnoreCondition =
                System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull,
        };

        public McpContextHandlers(RevitDispatcher dispatcher)
        {
            _dispatcher = dispatcher ?? throw new ArgumentNullException(nameof(dispatcher));
        }

        // ── GET /document ────────────────────────────────────────────────────

        public void HandleDocument(HttpListenerContext ctx)
        {
            var result = _dispatcher.Invoke(app =>
            {
                var doc = app.ActiveUIDocument?.Document;
                if (doc == null) return (object)Err("Aktif doküman yok.");

                var pi  = doc.ProjectInformation;
                var dto = new DocumentInfoDto
                {
                    Title            = doc.Title         ?? "",
                    Path             = doc.PathName      ?? "",
                    IsWorkshared     = doc.IsWorkshared,
                    IsFamily         = doc.IsFamilyDocument,
                    ProjectNumber    = pi?.Number        ?? "",
                    ProjectName      = pi?.Name          ?? "",
                    ClientName       = pi?.ClientName    ?? "",
                    BuildingName     = pi?.BuildingName  ?? "",
                    Author           = pi?.Author        ?? "",
                    OrganizationName = pi?.OrganizationName ?? "",
                    RevitVersion     = app.Application.VersionNumber ?? "",
                    WarningsCount    = doc.GetWarnings().Count,
                };

                // Birimler
                try
                {
                    var u = doc.GetUnits();
                    dto.LengthUnit = u.GetFormatOptions(SpecTypeId.Length).GetUnitTypeId().TypeId ?? "";
                    dto.AreaUnit   = u.GetFormatOptions(SpecTypeId.Area).GetUnitTypeId().TypeId   ?? "";
                }
                catch { /* Revit versiyon farkı — boş bırak */ }

                // Phase'ler
                dto.Phases = doc.Phases.Cast<Phase>().Select(p => p.Name).ToList();

                // Aktif phase
                try
                {
                    var vp = app.ActiveUIDocument?.ActiveView?.get_Parameter(BuiltInParameter.VIEW_PHASE);
                    if (vp != null && doc.GetElement(vp.AsElementId()) is Phase ph)
                        dto.ActivePhase = ph.Name;
                }
                catch { }

                dto.LevelCount = new FilteredElementCollector(doc)
                    .OfClass(typeof(Level)).GetElementCount();
                dto.RoomCount = new FilteredElementCollector(doc)
                    .OfClass(typeof(SpatialElement))
                    .OfType<Room>().Count(r => r.Area > 0);
                dto.ElementCount = new FilteredElementCollector(doc)
                    .WhereElementIsNotElementType().GetElementCount();

                return (object)dto;
            });
            WriteResult(ctx, result);
        }

        // ── GET /selection ───────────────────────────────────────────────────

        public void HandleSelection(HttpListenerContext ctx)
        {
            var result = _dispatcher.Invoke(app =>
            {
                var uidoc = app.ActiveUIDocument;
                if (uidoc == null) return (object)Err("Aktif doküman yok.");
                var doc = uidoc.Document;
                var ids = uidoc.Selection.GetElementIds().ToList();

                var dto = new SelectionSnapshotDto
                {
                    Count      = ids.Count,
                    ElementIds = ids.Select(id => id.Value).ToList(),
                };

                var groups = new Dictionary<string, List<long>>(StringComparer.Ordinal);
                foreach (var id in ids)
                {
                    var el = doc.GetElement(id);
                    if (el == null) continue;
                    var cat = el.Category?.Name ?? "(Kategori yok)";
                    if (!groups.TryGetValue(cat, out var list)) { list = new List<long>(); groups[cat] = list; }
                    list.Add(id.Value);
                }

                dto.Summary = groups
                    .OrderByDescending(g => g.Value.Count)
                    .Select(g => new SelectionCategoryGroup { Category = g.Key, Count = g.Value.Count, ElementIds = g.Value })
                    .ToList();

                return (object)dto;
            });
            WriteResult(ctx, result);
        }

        // ── GET /levels ──────────────────────────────────────────────────────

        public void HandleLevels(HttpListenerContext ctx)
        {
            var result = _dispatcher.Invoke(app =>
            {
                var doc = app.ActiveUIDocument?.Document;
                if (doc == null) return (object)Err("Aktif doküman yok.");

                var levels = new FilteredElementCollector(doc)
                    .OfClass(typeof(Level))
                    .Cast<Level>()
                    .OrderBy(l => l.Elevation)
                    .Select(l => new LevelDto
                    {
                        Id          = l.Id.Value,
                        Name        = l.Name,
                        ElevationMm = UnitUtils.ConvertFromInternalUnits(l.Elevation, UnitTypeId.Millimeters),
                        // IsBuildingStory Revit 2026'da BuiltInParameter ile okunur
                        IsBuildingStory = l.get_Parameter(BuiltInParameter.LEVEL_IS_BUILDING_STORY)?.AsInteger() == 1,
                    })
                    .ToList();

                return (object)new { levels, count = levels.Count };
            });
            WriteResult(ctx, result);
        }

        // ── GET /rooms ───────────────────────────────────────────────────────

        public void HandleRooms(HttpListenerContext ctx)
        {
            string q     = ctx.Request.QueryString["q"]     ?? "";
            string phase = ctx.Request.QueryString["phase"] ?? "";
            string level = ctx.Request.QueryString["level"] ?? "";
            int    max   = int.TryParse(ctx.Request.QueryString["max"], out var m) ? m : 200;

            var result = _dispatcher.Invoke(app =>
            {
                var doc = app.ActiveUIDocument?.Document;
                if (doc == null) return (object)Err("Aktif doküman yok.");

                IEnumerable<Room> rooms = new FilteredElementCollector(doc)
                    .OfClass(typeof(SpatialElement))
                    .OfType<Room>()
                    .Where(r => r.Area > 0);

                if (!string.IsNullOrWhiteSpace(q))
                {
                    var ql = q.ToLowerInvariant();
                    rooms = rooms.Where(r => r.Name.ToLowerInvariant().Contains(ql) ||
                                             r.Number.ToLowerInvariant().Contains(ql));
                }

                // Room.Phase — BuiltInParameter ile (mevcut codebase deseni)
                if (!string.IsNullOrWhiteSpace(phase))
                {
                    rooms = rooms.Where(r =>
                    {
                        var phaseId = r.get_Parameter(BuiltInParameter.ROOM_PHASE)?.AsElementId();
                        if (phaseId == null) return false;
                        return (doc.GetElement(phaseId) as Phase)?.Name
                            ?.Equals(phase, StringComparison.OrdinalIgnoreCase) == true;
                    });
                }

                if (!string.IsNullOrWhiteSpace(level))
                    rooms = rooms.Where(r => r.Level?.Name?.Equals(level, StringComparison.OrdinalIgnoreCase) == true);

                var dtos = rooms
                    .OrderBy(r => r.Level?.Elevation ?? 0)
                    .ThenBy(r => r.Number)
                    .Take(max)
                    .Select(r =>
                    {
                        // Phase adını BuiltInParameter üzerinden al
                        string phaseName = "";
                        try
                        {
                            var phId = r.get_Parameter(BuiltInParameter.ROOM_PHASE)?.AsElementId();
                            if (phId != null) phaseName = (doc.GetElement(phId) as Phase)?.Name ?? "";
                        }
                        catch { }

                        return new RoomDto
                        {
                            Id         = r.Id.Value,
                            Name       = r.Name,
                            Number     = r.Number,
                            LevelName  = r.Level?.Name ?? "",
                            AreaM2     = Math.Round(UnitUtils.ConvertFromInternalUnits(r.Area, UnitTypeId.SquareMeters), 3),
                            Phase      = phaseName,
                            Department = r.get_Parameter(BuiltInParameter.ROOM_DEPARTMENT)?.AsString() ?? "",
                        };
                    })
                    .ToList();

                return (object)new { rooms = dtos, count = dtos.Count, truncated = dtos.Count >= max };
            });
            WriteResult(ctx, result);
        }

        // ── GET /families ────────────────────────────────────────────────────

        public void HandleFamilies(HttpListenerContext ctx)
        {
            string q         = ctx.Request.QueryString["q"]          ?? "";
            string category  = ctx.Request.QueryString["category"]   ?? "";
            bool   withTypes = ctx.Request.QueryString["with_types"] == "true";
            int    max       = int.TryParse(ctx.Request.QueryString["max"], out var m) ? m : 100;

            var result = _dispatcher.Invoke(app =>
            {
                var doc = app.ActiveUIDocument?.Document;
                if (doc == null) return (object)Err("Aktif doküman yok.");

                // Autodesk.Revit.DB.Family — tam niteleme (namespace çakışması CS0118 önler)
                IEnumerable<Autodesk.Revit.DB.Family> families = new FilteredElementCollector(doc)
                    .OfClass(typeof(Autodesk.Revit.DB.Family))
                    .Cast<Autodesk.Revit.DB.Family>();

                if (!string.IsNullOrWhiteSpace(q))
                {
                    var ql = q.ToLowerInvariant();
                    families = families.Where(f => f.Name.ToLowerInvariant().Contains(ql));
                }

                if (!string.IsNullOrWhiteSpace(category))
                    families = families.Where(f =>
                        f.FamilyCategory?.Name?.Equals(category, StringComparison.OrdinalIgnoreCase) == true);

                var dtos = families
                    .OrderBy(f => f.FamilyCategory?.Name)
                    .ThenBy(f => f.Name)
                    .Take(max)
                    .Select(f =>
                    {
                        var dto = new FamilyDto
                        {
                            Id        = f.Id.Value,
                            Name      = f.Name,
                            Category  = f.FamilyCategory?.Name ?? "",
                            TypeCount = f.GetFamilySymbolIds().Count,
                            IsInPlace = f.IsInPlace,
                        };

                        if (withTypes)
                        {
                            dto.Types = f.GetFamilySymbolIds()
                                .Select(tid => doc.GetElement(tid) as FamilySymbol)
                                .Where(s => s != null)
                                .Select(s => new FamilyTypeDto
                                {
                                    Id   = s!.Id.Value,
                                    Name = s.Name,
                                    // instance sayımı — hızlı yol
                                    InstanceCount = new FilteredElementCollector(doc)
                                        .OfClass(typeof(FamilyInstance))
                                        .Cast<FamilyInstance>()
                                        .Count(fi => fi.GetTypeId() == s.Id),
                                })
                                .OrderBy(t => t.Name)
                                .ToList();
                        }

                        return dto;
                    })
                    .ToList();

                return (object)new { families = dtos, count = dtos.Count, truncated = dtos.Count >= max };
            });
            WriteResult(ctx, result);
        }

        // ── GET /parameters ──────────────────────────────────────────────────
        // Mevcut codebase deseni: ExternalDefinition only (ParamOps.cs:303)

        public void HandleParameters(HttpListenerContext ctx)
        {
            string q   = ctx.Request.QueryString["q"]   ?? "";
            int    max = int.TryParse(ctx.Request.QueryString["max"], out var m) ? m : 50;

            if (q.Length < 2)
            {
                WriteJson(ctx, 400, Err("'q' parametresi en az 2 karakter olmalı."));
                return;
            }

            var result = _dispatcher.Invoke(app =>
            {
                var doc = app.ActiveUIDocument?.Document;
                if (doc == null) return (object)Err("Aktif doküman yok.");

                var found = new List<ParameterInfoDto>();
                var ql    = q.ToLowerInvariant();

                // Mevcut codebase deseni (ParamOps.cs satır 300-303):
                // ExternalDefinition (shared param) arar — project param için ayrı yol gerekir
                var it = doc.ParameterBindings.ForwardIterator();
                it.Reset();
                while (it.MoveNext() && found.Count < max)
                {
                    // Önce ExternalDefinition (SharedParam)
                    if (it.Key is ExternalDefinition extDef)
                    {
                        if (!extDef.Name.ToLowerInvariant().Contains(ql)) continue;

                        var binding  = it.Current as ElementBinding;
                        var catNames = new List<string>();
                        if (binding?.Categories != null)
                            foreach (Category cat in binding.Categories)
                                catNames.Add(cat.Name);

                        found.Add(new ParameterInfoDto
                        {
                            Name       = extDef.Name,
                            Guid       = extDef.GUID.ToString(),
                            Type       = "SharedParameter",
                            DataType   = TryGetDataType(extDef),
                            Group      = extDef.OwnerGroup?.Name ?? "",
                            Categories = catNames,
                            IsInstance = binding is InstanceBinding,
                        });
                    }
                    // ProjectParameter (InternalDefinition ama GUID olmayan)
                    else if (it.Key is InternalDefinition intDef)
                    {
                        if (!intDef.Name.ToLowerInvariant().Contains(ql)) continue;

                        var binding  = it.Current as ElementBinding;
                        var catNames = new List<string>();
                        if (binding?.Categories != null)
                            foreach (Category cat in binding.Categories)
                                catNames.Add(cat.Name);

                        found.Add(new ParameterInfoDto
                        {
                            Name       = intDef.Name,
                            Guid       = "",
                            Type       = "ProjectParameter",
                            DataType   = "",
                            Group      = "",
                            Categories = catNames,
                            IsInstance = binding is InstanceBinding,
                        });
                    }
                }

                return (object)new ParameterSearchResultDto
                {
                    Query      = q,
                    TotalFound = found.Count,
                    Results    = found,
                };
            });
            WriteResult(ctx, result);
        }

        // ── POST /undo ───────────────────────────────────────────────────────

        public void HandleUndo(HttpListenerContext ctx)
        {
            var result = _dispatcher.Invoke(app =>
            {
                try
                {
                    var undoCmdId = RevitCommandId.LookupPostableCommandId(PostableCommand.Undo);
                    if (!app.CanPostCommand(undoCmdId))
                        return (object)new UndoResultDto { Success = false, Message = "Undo şu an kullanılamıyor." };
                    app.PostCommand(undoCmdId);
                    return (object)new UndoResultDto { Success = true, Message = "Undo komutu gönderildi." };
                }
                catch (Exception ex)
                {
                    return (object)new UndoResultDto { Success = false, Message = $"Undo başarısız: {ex.Message}" };
                }
            });
            WriteResult(ctx, result);
        }

        // ── POST /explain ────────────────────────────────────────────────────

        public void HandleExplain(HttpListenerContext ctx)
        {
            string body = ReadBody(ctx);
            if (string.IsNullOrWhiteSpace(body)) { WriteJson(ctx, 400, Err("Boş gövde.")); return; }

            FailureExplanationDto dto;
            try
            {
                using var jdoc = JsonDocument.Parse(body);
                var root   = jdoc.RootElement;
                var errMsg = root.TryGetProperty("error", out var ep) ? ep.GetString() ?? "" : "";
                var stepId = root.TryGetProperty("step",  out var sp) ? sp.GetString() ?? "" : "";
                var opName = root.TryGetProperty("op",    out var op) ? op.GetString() ?? "" : "";
                dto = AnalyzeFailure(errMsg, stepId, opName);
            }
            catch (Exception ex) { WriteJson(ctx, 400, Err($"JSON parse hatası: {ex.Message}")); return; }

            WriteJson(ctx, 200, dto);
        }

        // ── POST /generate ───────────────────────────────────────────────────

        public void HandleGenerate(HttpListenerContext ctx)
        {
            string body = ReadBody(ctx);
            if (string.IsNullOrWhiteSpace(body)) { WriteJson(ctx, 400, Err("Boş gövde.")); return; }

            try
            {
                using var jdoc  = JsonDocument.Parse(body);
                var patternName = jdoc.RootElement.TryGetProperty("pattern", out var p) ? p.GetString() ?? "" : "";
                var generated   = GenerateManifest(patternName);
                if (generated == null) { WriteJson(ctx, 404, Err($"Bilinmeyen pattern: '{patternName}'.")); return; }
                WriteJson(ctx, 200, generated);
            }
            catch (Exception ex) { WriteJson(ctx, 500, Err($"Generate hatası: {ex.Message}")); }
        }

        // ── Yardımcılar ──────────────────────────────────────────────────────

        private static string TryGetDataType(ExternalDefinition def)
        {
            try { return def.GetDataType().TypeId ?? ""; }
            catch { return ""; }
        }

        private static FailureExplanationDto AnalyzeFailure(string error, string step, string op)
        {
            var dto = new FailureExplanationDto { OriginalError = error, FailedStep = step, FailedOp = op };
            var err = error.ToLowerInvariant();

            if (err.Contains("transaction") && (err.Contains("already open") || err.Contains("açık")))
            {
                dto.Category    = "TransactionConflict";
                dto.LikelyCause = $"'{op}' kendi transaction'ını açıyor, atomic policy ile uyumsuz.";
                dto.Suggestions = new List<string> { "transaction_policy='none' kullanın." };
                dto.ManifestFixHint = "\"transaction_policy\": \"none\"";
            }
            else if (err.Contains("empty") || err.Contains("first()") || err.Contains("sequence"))
            {
                dto.Category    = "EmptyCollection";
                dto.LikelyCause = $"'{op}' op'u çalışacak eleman bulamadı.";
                dto.Suggestions = new List<string> { "Kategori/faz filtrelerini kontrol edin.", "Model doğru açık mı?" };
            }
            else if (err.Contains("from") && (err.Contains("bulunamadı") || err.Contains("vars[")))
            {
                dto.Category    = "DataFlowError";
                dto.LikelyCause = "'from' referansı vars'ta yok — önceki adım başarısız olmuş olabilir.";
                dto.Suggestions = new List<string> { "Adım sıralamasını kontrol edin.", "'from' alanının doğru step ID'yi gösterdiğini doğrulayın." };
            }
            else if (err.Contains("timeout") || err.Contains("zaman aşımı"))
            {
                dto.Category    = "Timeout";
                dto.LikelyCause = "Revit ana thread 120s içinde yanıt vermedi.";
                dto.Suggestions = new List<string> { "Daha küçük eleman gruplarına bölün." };
            }
            else
            {
                dto.Category    = "Unknown";
                dto.LikelyCause = "Hata otomatik sınıflandırılamadı.";
                dto.Suggestions = new List<string> { "Ham hata mesajını inceleyin.", "Revit Journal dosyasına bakın." };
            }
            return dto;
        }

        private static object? GenerateManifest(string pattern) =>
            pattern.ToLowerInvariant() switch
            {
                "kalip_chain" => new
                {
                    title = "Kalıp Maliyet Zinciri",
                    description = "kalip_all → poz_match_keynote_aware → calc_cost → export_xlsx",
                    category = "Maliyet",
                    transaction_policy = "none",
                    steps = new object[]
                    {
                        new { id = "step_kalip", op = "kalip_all", inputs = new { } },
                        new { id = "step_poz",   op = "poz_match_keynote_aware", from = "step_kalip", inputs = new { } },
                        new { id = "step_cost",  op = "calc_cost",  from = "step_poz",   inputs = new { } },
                        new { id = "step_xlsx",  op = "export_xlsx", from = "step_cost", inputs = new { output_path = "C:\\EGBIMOTO\\kalip_maliyet.xlsx" } },
                    },
                },
                "cost_export" => new
                {
                    title = "Hızlı Maliyet Raporu",
                    category = "Maliyet",
                    transaction_policy = "none",
                    steps = new object[]
                    {
                        new { id = "step_sel",  op = "selection_gate",           inputs = new { prompt = "Elemanları seçin" } },
                        new { id = "step_poz",  op = "poz_match_keynote_aware",  from = "step_sel",  inputs = new { } },
                        new { id = "step_cost", op = "calc_cost",                from = "step_poz",  inputs = new { } },
                        new { id = "step_xlsx", op = "export_xlsx",              from = "step_cost", inputs = new { output_path = "C:\\EGBIMOTO\\maliyet.xlsx" } },
                    },
                },
                "qa_check" => new
                {
                    title = "TR BIM QA Kontrolü",
                    category = "Kalite",
                    transaction_policy = "none",
                    steps = new object[]
                    {
                        new { id = "step_precheck", op = "model_has_elements",     inputs = new { } },
                        new { id = "step_qa",       op = "qa_param_check_csb2026", inputs = new { } },
                        new { id = "step_report",   op = "qa_report_html", from = "step_qa", inputs = new { output_path = "C:\\EGBIMOTO\\qa_rapor.html" } },
                    },
                },
                "room_param_fill" => new
                {
                    title = "Oda Parametre Doldurma",
                    category = "Parametreler",
                    transaction_policy = "atomic",
                    steps = new object[]
                    {
                        new { id = "step_load", op = "load_csv_data",   inputs = new { data_path = "C:\\EGBIMOTO\\odalar.csv" } },
                        new { id = "step_fill", op = "room_param_write", from = "step_load", inputs = new { param_name = "EG_OdaTipi" } },
                    },
                },
                "ifc_export" => new
                {
                    title = "IFC Export ÇŞB 2026",
                    category = "Export",
                    transaction_policy = "none",
                    steps = new object[]
                    {
                        new { id = "step_precheck", op = "model_has_elements",   inputs = new { } },
                        new { id = "step_ifc",      op = "export_ifc4_csb2026",  inputs = new { output_folder = "C:\\EGBIMOTO\\IFC" } },
                    },
                },
                _ => null,
            };

        private void WriteResult(HttpListenerContext ctx, object? result)
        {
            if (result is string s && s.StartsWith("{\"error\""))
                WriteJson(ctx, 500, result);
            else
                WriteJson(ctx, 200, result ?? Err("Sonuç alınamadı."));
        }

        private static void WriteJson(HttpListenerContext ctx, int status, object? payload)
        {
            var json  = JsonSerializer.Serialize(payload, _json);
            var bytes = Encoding.UTF8.GetBytes(json);
            ctx.Response.StatusCode      = status;
            ctx.Response.ContentType     = "application/json; charset=utf-8";
            ctx.Response.ContentLength64 = bytes.Length;
            ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
            ctx.Response.OutputStream.Close();
        }

        private static string ReadBody(HttpListenerContext ctx)
        {
            using var reader = new StreamReader(ctx.Request.InputStream,
                ctx.Request.ContentEncoding ?? Encoding.UTF8);
            return reader.ReadToEnd();
        }

        private static object Err(string msg) => new { error = msg };
    }
}
