// EGBIMOTO V17 — McpServerManager
// V16'dan fark: SkillRegistry inject edildi
using System;
using System.IO;
using EGBIMOTO.Core.Ops;
using EGBIMOTO.Core.Skills;

namespace EGBIMOTO.Addin.Server
{
    public sealed class McpServerManager
    {
        private static readonly Lazy<McpServerManager> _instance = new(() => new McpServerManager());
        public static McpServerManager Instance => _instance.Value;

        private RevitDispatcher?   _dispatcher;
        private EgbimotoMcpServer? _server;
        private McpManifestRunner? _runner;
        private SkillRegistry?     _skillRegistry;

        private McpServerManager() { }

        public bool   IsRunning      => _server?.IsRunning ?? false;
        public int    Port           => _server?.Port ?? 0;
        public int    SkillsLoaded   => _skillRegistry?.Count ?? 0;
        public string StatusLabel    => IsRunning ? $"MCP ✓ :{Port} | {SkillsLoaded} skill" : "MCP ✗";

        /// <summary>
        /// skillsRoot: manifest_skills/ klasörünün tam yolu.
        /// Genellikle addin kurulum dizininin altında: Path.Combine(addinDir, "manifest_skills")
        /// </summary>
        public void Start(
            OpRegistry registry,
            Func<string> contractsPathProvider,
            string skillsRoot,
            int port = 5577,
            string? token = null)
        {
            if (IsRunning) return;

            // Skill registry yükle
            _skillRegistry = new SkillRegistry(skillsRoot);
            var loadResult = _skillRegistry.Load();
            // Yükleme hatalarını logla (BootLog veya Debug)
            foreach (var err in loadResult.Errors)
                System.Diagnostics.Debug.WriteLine($"[EGBIMOTO Skills] {err}");

            _dispatcher = new RevitDispatcher();
            _dispatcher.Initialize();

            _runner = new McpManifestRunner(registry);

            _server = new EgbimotoMcpServer(
                _dispatcher,
                contractsPathProvider,
                (manifestJson, dispatcher) => _runner.Run(manifestJson, dispatcher),
                registry,
                _skillRegistry,
                port,
                token);

            _server.Start();
        }

        public void Stop()
        {
            _server?.Stop();
            _server = null; _dispatcher = null; _runner = null; _skillRegistry = null;
        }

        public bool Toggle(OpRegistry registry, Func<string> contractsPathProvider,
            string skillsRoot, int port = 5577, string? token = null)
        {
            if (IsRunning) { Stop(); return false; }
            Start(registry, contractsPathProvider, skillsRoot, port, token);
            return true;
        }
    }
}
