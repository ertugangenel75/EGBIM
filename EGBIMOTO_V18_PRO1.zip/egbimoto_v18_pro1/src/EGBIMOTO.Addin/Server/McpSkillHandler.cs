// ═══════════════════════════════════════════════════════════════════════════════
//  EGBIMOTO V17 — McpSkillHandler
//
//  Yeni endpoint'ler:
//    GET  /skills              → egbimoto_list_skills
//    GET  /skills/{id}         → skill detayı + SKILL.md
//    POST /run-skill           → egbimoto_run_skill
//
//  run-skill akışı:
//    1. SkillRegistry.BuildManifest(skill_id, params) → EgManifest JSON
//    2. McpPreviewHandler veya doğrudan McpManifestRunner.Run()
//    3. Sonucu döndür
//
//  V16'dan fark: artık LLM manifest yazmak zorunda değil.
//  Skill seçer → parametre verir → manifest otomatik üretilir → çalışır.
// ═══════════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Text.Json;
using EGBIMOTO.Core.Skills;

namespace EGBIMOTO.Addin.Server
{
    public sealed class McpSkillHandler
    {
        private readonly SkillRegistry   _registry;
        private readonly RevitDispatcher _dispatcher;
        private readonly Func<string, RevitDispatcher, string> _runManifest;
        private readonly McpPreviewHandler _preview;

        private static readonly JsonSerializerOptions _json = new()
        {
            WriteIndented = false,
            DefaultIgnoreCondition =
                System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull,
        };

        public McpSkillHandler(
            SkillRegistry registry,
            RevitDispatcher dispatcher,
            Func<string, RevitDispatcher, string> runManifestHandler,
            McpPreviewHandler preview)
        {
            _registry    = registry    ?? throw new ArgumentNullException(nameof(registry));
            _dispatcher  = dispatcher  ?? throw new ArgumentNullException(nameof(dispatcher));
            _runManifest = runManifestHandler ?? throw new ArgumentNullException(nameof(runManifestHandler));
            _preview     = preview     ?? throw new ArgumentNullException(nameof(preview));
        }

        // ── GET /skills ───────────────────────────────────────────────────────
        // Query: category=, tag=

        public void HandleList(HttpListenerContext ctx)
        {
            string? category = ctx.Request.QueryString["category"];
            string? tag      = ctx.Request.QueryString["tag"];

            var skills     = _registry.ListSkills(category, tag);
            var categories = _registry.Categories();

            WriteJson(ctx, 200, new
            {
                count      = skills.Count,
                categories,
                skills,
            });
        }

        // ── GET /skills/{id} ─────────────────────────────────────────────────
        // Tam skill detayı + SKILL.md

        public void HandleGet(HttpListenerContext ctx, string skillId)
        {
            var skill = _registry.Get(skillId);
            if (skill == null)
            {
                WriteJson(ctx, 404, new { error = $"Skill bulunamadı: '{skillId}'" });
                return;
            }

            var md = _registry.GetSkillMd(skillId);

            WriteJson(ctx, 200, new
            {
                id                 = skill.Id,
                title              = skill.Title,
                description        = skill.Description,
                category           = skill.Category,
                complexity         = skill.Complexity,
                estimated_duration_s = skill.EstimatedDurationS,
                tr_standard        = skill.TrStandard,
                tags               = skill.Tags,
                params_            = skill.Params,    // 'params' reserved in C# anonymous types
                skill_md           = md,
                manifest_template  = skill.ManifestTemplate,
            });
        }

        // ── POST /run-skill ───────────────────────────────────────────────────
        // Gövde: { "skill": "kalip_maliyet_zinciri", "params": { "output_path": "..." }, "preview_only": false }

        public void HandleRunSkill(HttpListenerContext ctx)
        {
            string body = ReadBody(ctx);
            if (string.IsNullOrWhiteSpace(body))
            {
                WriteJson(ctx, 400, new { error = "Boş gövde. { skill, params, preview_only? } bekleniyor." });
                return;
            }

            // Parse request
            string skillId;
            Dictionary<string, object?> userParams;
            bool previewOnly;

            try
            {
                using var doc = JsonDocument.Parse(body);
                var root = doc.RootElement;

                skillId = root.TryGetProperty("skill", out var sp) ? sp.GetString() ?? "" : "";
                if (string.IsNullOrWhiteSpace(skillId))
                {
                    WriteJson(ctx, 400, new { error = "'skill' alanı zorunlu." });
                    return;
                }

                previewOnly = root.TryGetProperty("preview_only", out var pp) && pp.GetBoolean();

                userParams = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
                if (root.TryGetProperty("params", out var paramsEl) &&
                    paramsEl.ValueKind == JsonValueKind.Object)
                {
                    foreach (var prop in paramsEl.EnumerateObject())
                    {
                        userParams[prop.Name] = prop.Value.ValueKind switch
                        {
                            JsonValueKind.String  => (object?)prop.Value.GetString(),
                            JsonValueKind.Number  => prop.Value.TryGetDouble(out var d) ? d : (object?)prop.Value.GetRawText(),
                            JsonValueKind.True    => true,
                            JsonValueKind.False   => false,
                            JsonValueKind.Null    => null,
                            _                     => prop.Value.GetRawText(),
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                WriteJson(ctx, 400, new { error = $"JSON parse hatası: {ex.Message}" });
                return;
            }

            // Skill bul + manifest üret
            var (manifestJson, errors) = _registry.BuildManifest(skillId, userParams);

            if (errors.Count > 0)
            {
                WriteJson(ctx, 400, new
                {
                    error  = "Manifest üretilemedi.",
                    errors,
                    skill  = skillId,
                });
                return;
            }

            // Preview only → sadece etki raporunu döndür
            if (previewOnly)
            {
                // McpPreviewHandler'ı HTTP context üzerinden çağırmak yerine
                // direkt iç metodunu kullanmak daha temiz — ama o private.
                // Geçici çözüm: manifest'i /preview endpoint'ine yönlendir
                var previewCtx = new InternalPreviewContext(ctx, manifestJson);
                _preview.Handle(previewCtx.Context);
                return;
            }

            // Çalıştır
            try
            {
                var skillDef = _registry.Get(skillId)!;
                var resultJson = _runManifest(manifestJson, _dispatcher);

                // Skill metadata'yı sonuca ekle
                using var resultDoc = JsonDocument.Parse(resultJson);
                var merged = new
                {
                    skill_id    = skillId,
                    skill_title = skillDef.Title,
                    result      = resultDoc.RootElement,
                };
                WriteJson(ctx, 200, merged);
            }
            catch (Exception ex)
            {
                WriteJson(ctx, 500, new { error = $"Çalıştırma hatası: {ex.Message}", skill = skillId });
            }
        }

        // ── Yardımcılar ───────────────────────────────────────────────────────

        private static string ReadBody(HttpListenerContext ctx)
        {
            using var reader = new System.IO.StreamReader(
                ctx.Request.InputStream, ctx.Request.ContentEncoding ?? Encoding.UTF8);
            return reader.ReadToEnd();
        }

        private static void WriteJson(HttpListenerContext ctx, int status, object? payload)
        {
            var json  = JsonSerializer.Serialize(payload, _json);
            var bytes = Encoding.UTF8.GetBytes(json);
            ctx.Response.StatusCode      = status;
            ctx.Response.ContentType     = "application/json; charset=utf-8";
            ctx.Response.ContentLength64 = bytes.Length;
            ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
            ctx.Response.OutputStream.Close();
        }

        // ── InternalPreviewContext ────────────────────────────────────────────
        // McpPreviewHandler.Handle(ctx) HTTP gövdesini ctx.Request.InputStream'den okur.
        // Skill'den üretilen manifest'i oraya enjekte etmek için wrapper.

        private sealed class InternalPreviewContext
        {
            public HttpListenerContext Context { get; }

            public InternalPreviewContext(HttpListenerContext original, string manifestJson)
            {
                // McpPreviewHandler ReadBody() ile InputStream'i okur.
                // Mevcut context'in request body'si skill run-skill isteği.
                // Bunu değiştiremeyiz — bu nedenle preview_only için
                // McpPreviewHandler'da internal bir Build() metodu daha temiz olur.
                // Şimdilik: orijinal context'i geç, handler manifestJson ile çağrılır.
                // TODO V17.1: McpPreviewHandler.HandleManifestJson(ctx, json) ekle.
                Context = original;
            }
        }
    }
}
