// ═══════════════════════════════════════════════════════════════════════════════
//  EGBIMOTO V18 — McpTranslationHandler
//
//  GET /parameters — mevcut V16 endpoint'ini genişletir:
//    çeviri middleware ekler → "Wall Height" araması "Duvar Yüksekliği" de bulur
//
//  GET /translate  — tek metin çeviri endpoint'i
//    ?text=Wall+Height&src=en&tgt=tr
//
//  POST /translate/batch — toplu çeviri
//    { "texts": [...], "src": "en", "tgt": "tr" }
// ═══════════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using Autodesk.Revit.DB;
using EGBIMOTO.Core.Translation;

namespace EGBIMOTO.Addin.Server
{
    public sealed class McpTranslationHandler
    {
        private readonly TranslatorEngine _engine;
        private readonly RevitDispatcher  _dispatcher;

        private static readonly JsonSerializerOptions _json = new()
        {
            WriteIndented = false,
            DefaultIgnoreCondition =
                System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull,
        };

        public McpTranslationHandler(TranslatorEngine engine, RevitDispatcher dispatcher)
        {
            _engine     = engine     ?? throw new ArgumentNullException(nameof(engine));
            _dispatcher = dispatcher ?? throw new ArgumentNullException(nameof(dispatcher));
        }

        // ── GET /translate ────────────────────────────────────────────────────
        // ?text=...&src=en&tgt=tr

        public void HandleTranslate(HttpListenerContext ctx)
        {
            var qs   = ctx.Request.QueryString;
            var text = qs["text"] ?? "";
            var src  = qs["src"]  ?? "auto";
            var tgt  = qs["tgt"]  ?? "tr";

            if (string.IsNullOrWhiteSpace(text))
            { WriteJson(ctx, 400, Err("'text' parametresi zorunlu.")); return; }

            if (src.Equals("auto", StringComparison.OrdinalIgnoreCase))
                src = TranslatorEngine.DetectLanguage(text);

            var result = _engine.Translate(text, src, tgt);

            WriteJson(ctx, 200, new
            {
                input      = text,
                output     = result.Text,
                src,
                tgt,
                method     = result.Method.ToString(),
                confidence = result.Confidence,
                changed    = result.Changed,
            });
        }

        // ── POST /translate/batch ─────────────────────────────────────────────

        public void HandleTranslateBatch(HttpListenerContext ctx)
        {
            string body = ReadBody(ctx);
            if (string.IsNullOrWhiteSpace(body))
            { WriteJson(ctx, 400, Err("Boş gövde.")); return; }

            try
            {
                using var doc = JsonDocument.Parse(body);
                var root = doc.RootElement;

                var texts = root.TryGetProperty("texts", out var tp)
                    ? tp.EnumerateArray().Select(e => e.GetString() ?? "").ToList()
                    : new List<string>();

                var src = root.TryGetProperty("src", out var sp) ? sp.GetString() ?? "auto" : "auto";
                var tgt = root.TryGetProperty("tgt", out var gp) ? gp.GetString() ?? "tr"   : "tr";

                var results = texts.Select(t =>
                {
                    var detectedSrc = src.Equals("auto", StringComparison.OrdinalIgnoreCase)
                        ? TranslatorEngine.DetectLanguage(t)
                        : src;
                    var r = _engine.Translate(t, detectedSrc, tgt);
                    return new
                    {
                        input      = t,
                        output     = r.Text,
                        method     = r.Method.ToString(),
                        confidence = r.Confidence,
                        changed    = r.Changed,
                    };
                }).ToList();

                WriteJson(ctx, 200, new
                {
                    count   = results.Count,
                    src,
                    tgt,
                    results,
                });
            }
            catch (Exception ex)
            {
                WriteJson(ctx, 400, Err($"JSON parse hatası: {ex.Message}"));
            }
        }

        // ── GET /parameters (çeviri middleware) ───────────────────────────────
        // Mevcut McpContextHandlers.HandleParameters() ile birlikte çalışır.
        // Bu metod doğrudan çağrılmaz — HandleParameters() tarafından genişletilir.

        /// <summary>
        /// Revit ParameterBindings sonuçlarını çeviri sözlüğüyle zenginleştirir.
        /// Arama terimi yabancı dilde ise TR karşılığıyla da arama yapar.
        /// </summary>
        public List<ParameterSearchEntry> EnrichParameterSearch(
            string query,
            IEnumerable<ParameterSearchEntry> revitResults)
        {
            var merged = revitResults.ToList();

            // Sorgunun Türkçe olmadığı durumda → çevir ve ek arama yap
            var srcLang = TranslatorEngine.DetectLanguage(query);
            if (srcLang != "tr")
            {
                var translated = _engine.Translate(query, srcLang, "tr");
                if (translated.Changed)
                {
                    foreach (var entry in merged)
                    {
                        if (!entry.Aliases.Contains(translated.Text, StringComparer.OrdinalIgnoreCase))
                            entry.Aliases.Add(translated.Text);
                        entry.TranslationHint = $"{query} → {translated.Text} ({translated.Method})";
                    }
                }
            }

            // Tersi: Türkçe sorgu → İngilizce karşılığını da Alias'a ekle
            else
            {
                var toEn = _engine.Translate(query, "tr", "en");
                if (toEn.Changed)
                {
                    foreach (var entry in merged)
                    {
                        if (!entry.Aliases.Contains(toEn.Text, StringComparer.OrdinalIgnoreCase))
                            entry.Aliases.Add(toEn.Text);
                    }
                }
            }

            return merged;
        }

        // ── GET /translate/detect ─────────────────────────────────────────────

        public void HandleDetect(HttpListenerContext ctx)
        {
            var text = ctx.Request.QueryString["text"] ?? "";
            if (string.IsNullOrWhiteSpace(text))
            { WriteJson(ctx, 400, Err("'text' parametresi zorunlu.")); return; }

            WriteJson(ctx, 200, new
            {
                text,
                detected_language = TranslatorEngine.DetectLanguage(text),
            });
        }

        // ── GET /translate/best-param ─────────────────────────────────────────
        // ?name=Wall+Height&category=Walls

        public void HandleBestParam(HttpListenerContext ctx)
        {
            var name     = ctx.Request.QueryString["name"]     ?? "";
            var category = ctx.Request.QueryString["category"] ?? "";

            if (string.IsNullOrWhiteSpace(name))
            { WriteJson(ctx, 400, Err("'name' parametresi zorunlu.")); return; }

            var srcLang  = TranslatorEngine.DetectLanguage(name);
            var xlat     = _engine.Translate(name, srcLang, "tr");
            var bestParam = _engine.FindBestSharedParam(category, name, xlat.Text);

            WriteJson(ctx, 200, new
            {
                input            = name,
                category,
                detected_lang    = srcLang,
                translated       = xlat.Text,
                method           = xlat.Method.ToString(),
                best_shared_param = bestParam,
            });
        }

        // ── Yardımcılar ───────────────────────────────────────────────────────

        private static void WriteJson(HttpListenerContext ctx, int status, object payload)
        {
            var json  = JsonSerializer.Serialize(payload, _json);
            var bytes = Encoding.UTF8.GetBytes(json);
            ctx.Response.StatusCode      = status;
            ctx.Response.ContentType     = "application/json; charset=utf-8";
            ctx.Response.ContentLength64 = bytes.Length;
            ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
            ctx.Response.OutputStream.Close();
        }

        private static string ReadBody(HttpListenerContext ctx)
        {
            using var r = new System.IO.StreamReader(
                ctx.Request.InputStream, ctx.Request.ContentEncoding ?? Encoding.UTF8);
            return r.ReadToEnd();
        }

        private static object Err(string msg) => new { error = msg };
    }

    // ── ParameterSearchEntry ──────────────────────────────────────────────────
    // Mevcut ParameterInfoDto'yu genişletir

    public sealed class ParameterSearchEntry
    {
        public string       Name            { get; set; } = "";
        public string       Guid            { get; set; } = "";
        public string       Type            { get; set; } = "";
        public string       DataType        { get; set; } = "";
        public string       Group           { get; set; } = "";
        public List<string> Categories      { get; set; } = new();
        public bool         IsInstance      { get; set; }
        public List<string> Aliases         { get; set; } = new(); // V18: çeviri karşılıkları
        public string?      TranslationHint { get; set; }          // V18: çeviri notu
    }
}
