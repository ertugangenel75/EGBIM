// ═══════════════════════════════════════════════════════════════════════════════
//  EGBIMOTO V16 — McpPreviewHandler
//
//  POST /preview endpoint'i — manifest çalıştırmadan etki raporu üretir.
//
//  Strateji: Her adım için op adına göre heuristik kategorilendirme yapılır,
//  ardından Revit'te SALT OKUMA sorgular ile gerçek eleman sayıları alınır.
//  Hiçbir Transaction açılmaz, model değişmez.
//
//  Adım Kategorileri:
//    Read   → FilteredElementCollector (salt okuma)
//    Write  → element sayısı tahmin edilir, uyarı eklenir
//    Export → dosya sistemi etkisi, uyarı eklenir
//    Gate   → selection/preview/schedule_gate, atlanır
//    Create → oluşturulacak eleman sayısı tahmin edilir
//
//  Çıktı:
//    PreviewManifestResult (McpDtos.cs)
//    → Claude bu sonucu kullanıcıya gösterir, kullanıcı onaylar, sonra run_manifest
// ═══════════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using Autodesk.Revit.DB;
using EGBIMOTO.Core.MCP;
using EGBIMOTO.Core.Manifest;
using EGBIMOTO.Core.Ops;

namespace EGBIMOTO.Addin.Server
{
    /// <summary>
    /// POST /preview — manifest dry-run (etki raporu).
    /// Transaction açmaz, modeli değiştirmez.
    /// </summary>
    public sealed class McpPreviewHandler
    {
        private readonly RevitDispatcher _dispatcher;
        private readonly OpRegistry      _registry;

        private static readonly JsonSerializerOptions _parseOpts = new()
        {
            PropertyNameCaseInsensitive = true,
        };

        private static readonly JsonSerializerOptions _writeOpts = new()
        {
            WriteIndented = false,
            DefaultIgnoreCondition =
                System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull,
        };

        public McpPreviewHandler(RevitDispatcher dispatcher, OpRegistry registry)
        {
            _dispatcher = dispatcher ?? throw new ArgumentNullException(nameof(dispatcher));
            _registry   = registry   ?? throw new ArgumentNullException(nameof(registry));
        }

        public void Handle(HttpListenerContext ctx)
        {
            // 1) Body'yi oku ve parse et (Revit gerektirmez)
            string body = ReadBody(ctx);
            if (string.IsNullOrWhiteSpace(body))
            {
                WriteError(ctx, 400, "Bos govde. Manifest JSON bekleniyor.");
                return;
            }

            EgManifest? manifest;
            try
            {
                manifest = JsonSerializer.Deserialize<EgManifest>(body, _parseOpts);
            }
            catch (Exception ex)
            {
                WriteError(ctx, 400, $"Manifest JSON parse edilemedi: {ex.Message}");
                return;
            }

            if (manifest == null || manifest.Steps.Count == 0)
            {
                WriteError(ctx, 400, "Manifest bos veya adim yok.");
                return;
            }

            // 2) Dry-run'ı Revit ana thread'inde yürüt (salt okuma)
            var resultObj = _dispatcher.Invoke(app =>
            {
                var doc = app.ActiveUIDocument?.Document;
                if (doc == null)
                    return (object)ErrorResult("Aktif Revit dokumani yok.");

                return (object)RunDryRun(manifest, doc);
            });

            var json  = JsonSerializer.Serialize(resultObj, _writeOpts);
            var bytes = Encoding.UTF8.GetBytes(json);
            ctx.Response.StatusCode      = 200;
            ctx.Response.ContentType     = "application/json; charset=utf-8";
            ctx.Response.ContentLength64 = bytes.Length;
            ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
            ctx.Response.OutputStream.Close();
        }

        // ── Dry-Run Core ─────────────────────────────────────────────────────────

        private PreviewManifestResult RunDryRun(EgManifest manifest, Document doc)
        {
            var result = new PreviewManifestResult
            {
                Title     = manifest.Title,
                StepCount = manifest.Steps.Count,
                Feasible  = true,
            };

            // Op varlığı kontrolü
            foreach (var step in manifest.Steps)
            {
                if (string.IsNullOrWhiteSpace(step.Op))
                {
                    result.Errors.Add($"Adım '{step.Id}': op adı boş.");
                    result.Feasible = false;
                    continue;
                }

                if (!_registry.HasOp(step.Op) && !IsBuiltInGate(step.Op))
                    result.Warnings.Add($"'{step.Op}' op'u registry'de bulunamadı — bilinmeyen op.");
            }

            // Transaction policy uyum kontrolü
            if (manifest.IsAtomic)
            {
                var ownTxOps = manifest.Steps
                    .Where(s => IsKnownOwnTransactionOp(s.Op))
                    .Select(s => s.Op)
                    .ToList();
                if (ownTxOps.Count > 0)
                {
                    result.Errors.Add(
                        $"transaction_policy='atomic' ile uyumsuz op'lar: {string.Join(", ", ownTxOps)}. " +
                        "Bu op'lar kendi transaction'larını açar. 'none' kullanın.");
                    result.Feasible = false;
                }
            }

            // Her adım için etki analizi
            long totalMs = 0;
            foreach (var step in manifest.Steps)
            {
                var stepResult = AnalyzeStep(step, doc);
                result.Steps.Add(stepResult);

                result.TotalElementsAffected  += stepResult.ElementCount;
                result.TotalElementsCreated   += stepResult.ElementsCreated;
                result.TotalParametersUpdated += stepResult.ParametersUpdated;
                result.TotalElementsRead      += (stepResult.OpDomain == "Read") ? stepResult.ElementCount : 0;
                totalMs += stepResult.EstimatedMs;
            }

            result.EstimatedMs = totalMs;

            // Özet metin
            result.Summary = BuildSummary(result);

            return result;
        }

        private PreviewStepResult AnalyzeStep(EgStep step, Document doc)
        {
            var r = new PreviewStepResult
            {
                Id  = step.Id,
                Op  = step.Op,
            };

            // Gate op'lar
            if (IsBuiltInGate(step.Op))
            {
                r.OpDomain    = "Gate";
                r.Skipped     = true;
                r.SkipReason  = "Kullanıcı etkileşimi gerektiren gate adımı — önizlemede atlanır.";
                r.EstimatedMs = 0;
                return r;
            }

            // Op domain'i belirle
            r.OpDomain = ClassifyOp(step.Op);

            switch (r.OpDomain)
            {
                case "Read":
                    FillReadStep(r, step, doc);
                    break;

                case "Write":
                    FillWriteStep(r, step, doc);
                    break;

                case "Create":
                    FillCreateStep(r, step, doc);
                    break;

                case "Export":
                    FillExportStep(r, step);
                    break;

                default:
                    r.EstimatedMs = 500;
                    r.Warning     = $"'{step.Op}' op'u için etki analizi yapılamadı — bilinmeyen domain.";
                    break;
            }

            return r;
        }

        // ── Okuma adımları ───────────────────────────────────────────────────────

        private static void FillReadStep(PreviewStepResult r, EgStep step, Document doc)
        {
            var op = step.Op.ToLowerInvariant();

            // Kategori bazlı heuristik
            BuiltInCategory? bic = GuessCategoryFromOp(op);

            if (bic.HasValue)
            {
                try
                {
                    var col = new FilteredElementCollector(doc)
                        .OfCategory(bic.Value)
                        .WhereElementIsNotElementType();

                    var catGroups = new Dictionary<string, int>();
                    foreach (var el in col)
                    {
                        var catName = el.Category?.Name ?? "?";
                        catGroups.TryGetValue(catName, out var cnt);
                        catGroups[catName] = cnt + 1;
                    }

                    r.ElementCount       = catGroups.Values.Sum();
                    r.CategoryBreakdown  = catGroups;
                    r.EstimatedMs        = EstimateReadMs(r.ElementCount);
                }
                catch
                {
                    r.ElementCount = 0;
                    r.Warning      = "Eleman sayısı sorgulanırken hata oluştu.";
                }
            }
            else if (op.Contains("kalip"))
            {
                // kalip_all özel: duvar + döşeme + kiriş + kolon
                r.ElementCount      = CountMultiCategory(doc,
                    BuiltInCategory.OST_Walls,
                    BuiltInCategory.OST_Floors,
                    BuiltInCategory.OST_StructuralFraming,
                    BuiltInCategory.OST_StructuralColumns);
                r.CategoryBreakdown = BuildKalipBreakdown(doc);
                r.EstimatedMs       = EstimateReadMs(r.ElementCount) * 3; // ağır op
                r.Warning           = "kalip_all tüm modeli tarar — büyük modellerde yavaş olabilir.";
            }
            else
            {
                r.ElementCount = 0;
                r.EstimatedMs  = 300;
            }
        }

        // ── Yazma adımları ───────────────────────────────────────────────────────

        private static void FillWriteStep(PreviewStepResult r, EgStep step, Document doc)
        {
            var op = step.Op.ToLowerInvariant();

            // Parametre yazma
            if (op.Contains("param") && (op.Contains("write") || op.Contains("set") || op.Contains("fill")))
            {
                var bic = GuessCategoryFromOp(op);
                r.ElementCount        = bic.HasValue
                    ? new FilteredElementCollector(doc).OfCategory(bic.Value)
                        .WhereElementIsNotElementType().GetElementCount()
                    : CountAll(doc);
                r.ParametersUpdated   = r.ElementCount; // her eleman için 1 parametre
                r.EstimatedMs         = r.ElementCount * 2; // ~2ms/eleman
                r.Warning             = $"Bu adım ~{r.ElementCount} elemana parametre yazacak.";
            }
            else
            {
                // Genel yazma adımı — muhafazakar tahmin
                r.ElementCount    = 0;
                r.EstimatedMs     = 1000;
                r.Warning         = $"'{step.Op}' yazma adımının tam etkisi çalıştırılmadan belirlenemiyor.";
            }
        }

        // ── Oluşturma adımları ───────────────────────────────────────────────────

        private static void FillCreateStep(PreviewStepResult r, EgStep step, Document doc)
        {
            r.ElementsCreated = 0;  // Oluşturma adımlarında önceden bilinmez
            r.EstimatedMs     = 2000;
            r.Warning         = $"'{step.Op}' yeni eleman(lar) oluşturacak. Önceki adımların çıktısına göre sayı değişir.";
        }

        // ── Export adımları ──────────────────────────────────────────────────────

        private static void FillExportStep(PreviewStepResult r, EgStep step)
        {
            r.EstimatedMs = 500;

            // Çıktı dosyasını göster
            object? outputPath = null, outputFolder = null;
            step.Params?.TryGetValue("output_path",   out outputPath);
            step.Params?.TryGetValue("output_folder", out outputFolder);

            var filePath = (outputPath ?? outputFolder)?.ToString() ?? "";
            if (!string.IsNullOrWhiteSpace(filePath))
                r.Warning = $"Dosya yazılacak: {filePath}";
        }

        // ── Yardımcı metodlar ─────────────────────────────────────────────────────

        private static bool IsBuiltInGate(string op) =>
            op is "preview_gate" or "selection_gate" or "schedule_gate";

        private static bool IsKnownOwnTransactionOp(string op)
        {
            // Bu op'lar kendi Transaction'larını açar, atomic ile uyumsuz
            var known = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "kalip_all", "export_ifc4_csb2026", "export_xlsx",
                "schedule_create", "family_load", "purge_unused",
            };
            return known.Contains(op);
        }

        private static string ClassifyOp(string op)
        {
            var o = op.ToLowerInvariant();

            if (o.StartsWith("export_") || o.Contains("_export") || o.StartsWith("print_"))
                return "Export";

            if (o.Contains("_create") || o.StartsWith("create_") || o.Contains("_place") ||
                o.Contains("_load") || o.StartsWith("family_load"))
                return "Create";

            if (o.Contains("_write") || o.Contains("_set") || o.Contains("_fill") ||
                o.Contains("_update") || o.Contains("_move") || o.Contains("_delete") ||
                o.Contains("_remove") || o.Contains("_purge") || o.Contains("_rename"))
                return "Write";

            // Varsayılan: okuma
            return "Read";
        }

        private static BuiltInCategory? GuessCategoryFromOp(string op)
        {
            if (op.Contains("wall"))   return BuiltInCategory.OST_Walls;
            if (op.Contains("floor"))  return BuiltInCategory.OST_Floors;
            if (op.Contains("column")) return BuiltInCategory.OST_StructuralColumns;
            if (op.Contains("beam") || op.Contains("framing")) return BuiltInCategory.OST_StructuralFraming;
            if (op.Contains("room"))   return BuiltInCategory.OST_Rooms;
            if (op.Contains("door"))   return BuiltInCategory.OST_Doors;
            if (op.Contains("window")) return BuiltInCategory.OST_Windows;
            if (op.Contains("pipe"))   return BuiltInCategory.OST_PipeCurves;
            if (op.Contains("duct"))   return BuiltInCategory.OST_DuctCurves;
            if (op.Contains("rebar"))  return BuiltInCategory.OST_Rebar;
            if (op.Contains("stair"))  return BuiltInCategory.OST_Stairs;
            return null;
        }

        private static int CountMultiCategory(Document doc, params BuiltInCategory[] cats)
        {
            int total = 0;
            foreach (var cat in cats)
            {
                try
                {
                    total += new FilteredElementCollector(doc)
                        .OfCategory(cat)
                        .WhereElementIsNotElementType()
                        .GetElementCount();
                }
                catch { }
            }
            return total;
        }

        private static Dictionary<string, int> BuildKalipBreakdown(Document doc)
        {
            var map = new Dictionary<string, int>();
            var cats = new[]
            {
                (BuiltInCategory.OST_Walls,              "Duvarlar"),
                (BuiltInCategory.OST_Floors,             "Döşemeler"),
                (BuiltInCategory.OST_StructuralFraming,  "Kirişler"),
                (BuiltInCategory.OST_StructuralColumns,  "Kolonlar"),
            };
            foreach (var (bic, label) in cats)
            {
                try
                {
                    map[label] = new FilteredElementCollector(doc)
                        .OfCategory(bic).WhereElementIsNotElementType().GetElementCount();
                }
                catch { map[label] = 0; }
            }
            return map;
        }

        private static int CountAll(Document doc)
        {
            try
            {
                return new FilteredElementCollector(doc)
                    .WhereElementIsNotElementType().GetElementCount();
            }
            catch { return 0; }
        }

        private static long EstimateReadMs(int elementCount)
        {
            if (elementCount < 100)  return 200;
            if (elementCount < 500)  return 500;
            if (elementCount < 2000) return 1500;
            if (elementCount < 5000) return 3000;
            return 6000;
        }

        private static string BuildSummary(PreviewManifestResult r)
        {
            var parts = new List<string>();

            if (r.TotalElementsRead > 0)
                parts.Add($"{r.TotalElementsRead} eleman okunacak");
            if (r.TotalElementsAffected > 0)
                parts.Add($"{r.TotalElementsAffected} eleman etkilenecek");
            if (r.TotalElementsCreated > 0)
                parts.Add($"{r.TotalElementsCreated} eleman oluşturulacak");
            if (r.TotalParametersUpdated > 0)
                parts.Add($"{r.TotalParametersUpdated} parametre güncellenecek");

            var exportSteps = r.Steps.Count(s => s.OpDomain == "Export");
            if (exportSteps > 0)
                parts.Add($"{exportSteps} dosya dışa aktarılacak");

            if (parts.Count == 0)
                return "Manifest etki analizi tamamlandı.";

            var base_ = string.Join(", ", parts);
            var time  = r.EstimatedMs < 1000
                ? $"{r.EstimatedMs}ms"
                : $"~{r.EstimatedMs / 1000.0:F1}s";

            return $"{r.Title}: {base_}. Tahmini süre: {time}.";
        }

        // ── HTTP yardımcıları ─────────────────────────────────────────────────────

        private static object ErrorResult(string msg) => new PreviewManifestResult
        {
            Feasible = false,
            Errors   = new List<string> { msg },
            Summary  = $"Hata: {msg}",
        };

        private static void WriteError(HttpListenerContext ctx, int status, string msg)
        {
            var json  = JsonSerializer.Serialize(new { error = msg });
            var bytes = Encoding.UTF8.GetBytes(json);
            ctx.Response.StatusCode       = status;
            ctx.Response.ContentType      = "application/json; charset=utf-8";
            ctx.Response.ContentLength64  = bytes.Length;
            ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
            ctx.Response.OutputStream.Close();
        }

        private static string ReadBody(HttpListenerContext ctx)
        {
            using var reader = new System.IO.StreamReader(
                ctx.Request.InputStream, ctx.Request.ContentEncoding ?? Encoding.UTF8);
            return reader.ReadToEnd();
        }
    }
}
