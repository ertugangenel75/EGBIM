// ═══════════════════════════════════════════════════════════════════════════════
//  EGBIMOTO V18 — FamilyTranslatorWindow.xaml.cs
//  Family Parametre Çevirici — code-behind
// ═══════════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using WpfColor      = System.Windows.Media.Color;
using WpfBinding    = System.Windows.Data.Binding;
using WpfVisibility = System.Windows.Visibility;
using EGBIMOTO.Addin.Ops;
using EGBIMOTO.Core.Translation;

namespace EGBIMOTO.Addin.UI.Family
{
    public partial class FamilyTranslatorWindow : Window
    {
        // ── Alanlar ───────────────────────────────────────────────────────────
        private readonly Document        _doc;
        private readonly UIApplication   _uiApp;
        private TranslatorEngine? _engine;
        private readonly string          _dataDir;
        private string                   _saveFolder = "";
        private bool                     _scanning   = false;

        private ObservableCollection<TranslateParamRowVm> _allRows = new();
        private CollectionViewSource                       _viewSource = new();

        // ── Constructor ───────────────────────────────────────────────────────
        public FamilyTranslatorWindow(UIApplication uiApp, string dataDir)
        {
            InitializeComponent();
            _uiApp   = uiApp;
            _doc     = uiApp.ActiveUIDocument.Document;
            _dataDir = dataDir;

            // Engine yükle
            try
            {
                _engine = TranslatorEngine.Load(dataDir);
                TxtEngineStatus.Text = $"Engine hazır — {_engine.GetType().Name}";
            }
            catch (Exception ex)
            {
                TxtEngineStatus.Text = $"Engine hatası: {ex.Message}";
            }

            // Doküman başlığı
            TxtDocTitle.Text = _doc.Title;

            // DataGrid bağla
            _viewSource.Source = _allRows;
            GridParams.ItemsSource = _viewSource.View;

            // Kategori dropdown doldur
            FillCategoryCombo();

            // Resource converter'ları ekle
            Resources.Add("LangColorConverter",   new LangColorConverter());
            Resources.Add("MethodColorConverter", new MethodColorConverter());
            Resources.Add("ModeColorConverter",   new ModeColorConverter());
        }

        // ── Tara ──────────────────────────────────────────────────────────────
        private void BtnScan_Click(object sender, RoutedEventArgs e)
        {
            if (_scanning || _engine == null) return;
            _scanning = true;
            BtnScan.IsEnabled = false;
            SetStatus("Taranıyor...");
            PrgBar.Visibility = WpfVisibility.Visible;
            PrgBar.IsIndeterminate = true;

            var srcLang  = (CmbSrcLang.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "auto";
            var catFilter = (CmbCategory.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Tümü";

            // Arka plan thread
            var worker = new BackgroundWorker();
            worker.DoWork += (s, args) =>
            {
                var rows = new List<TranslateParamRowVm>();
                var errors = new List<string>();

                IEnumerable<Autodesk.Revit.DB.Family> families = new FilteredElementCollector(_doc)
                    .OfClass(typeof(Autodesk.Revit.DB.Family))
                    .Cast<Autodesk.Revit.DB.Family>()
                    .Where(f => f.IsEditable);

                if (catFilter != "Tümü")
                    families = families.Where(f =>
                        f.FamilyCategory?.Name?.Equals(catFilter, StringComparison.OrdinalIgnoreCase) == true);

                int idx = 0;
                var famList = families.ToList();

                foreach (var fam in famList)
                {
                    Dispatcher.Invoke(() =>
                    {
                        PrgBar.IsIndeterminate = false;
                        PrgBar.Value = (idx * 100.0) / Math.Max(1, famList.Count);
                        SetStatus($"Tarıyor: {fam.Name} ({idx}/{famList.Count})");
                    });

                    Document? fdoc = null;
                    try
                    {
                        fdoc = _doc.EditFamily(fam);
                        var fmgr = fdoc.FamilyManager;
                        var catName = fam.FamilyCategory?.Name ?? "";

                        foreach (FamilyParameter fp in fmgr.Parameters)
                        {
                            string currentName;
                            try { currentName = fp.Definition.Name; } catch { continue; }

                            var detectedLang = srcLang == "auto"
                                ? TranslatorEngine.DetectLanguage(currentName)
                                : srcLang;

                            string suggestedName  = currentName;
                            string method         = "UNCHANGED";
                            double confidence     = 1.0;
                            bool   changed        = false;

                            if (detectedLang != "tr")
                            {
                                var xlat = _engine.Translate(currentName, detectedLang, "tr");
                                suggestedName = xlat.Text;
                                method        = xlat.Method.ToString().ToUpperInvariant();
                                confidence    = xlat.Confidence;
                                changed       = xlat.Changed;
                            }

                            bool isShared  = TryBool(() => fp.IsShared);
                            bool isBuiltIn = TryBool(() => fp.Id.Value < 0);
                            var  mode      = (!isShared && !isBuiltIn) ? "Rename" : "CreateMap";
                            var bestParam  = _engine.FindBestSharedParam(catName, currentName, suggestedName);

                            rows.Add(new TranslateParamRowVm
                            {
                                FamilyName      = fam.Name,
                                Category        = catName,
                                CurrentName     = currentName,
                                SuggestedName   = suggestedName,
                                BestSharedParam = bestParam,
                                DetectedLang    = detectedLang,
                                Method          = method,
                                Confidence      = confidence,
                                IsShared        = isShared,
                                IsBuiltIn       = isBuiltIn,
                                Mode            = mode,
                                IsSelected      = changed && !isShared && !isBuiltIn,
                            });
                        }
                    }
                    catch (Exception ex) { errors.Add($"{fam.Name}: {ex.Message}"); }
                    finally { try { fdoc?.Close(false); } catch { } }

                    idx++;
                }

                args.Result = (rows, errors);
            };

            worker.RunWorkerCompleted += (s, args) =>
            {
                _scanning = false;
                BtnScan.IsEnabled = true;
                PrgBar.Visibility = WpfVisibility.Collapsed;

                if (args.Error != null)
                { SetStatus($"Hata: {args.Error.Message}"); return; }

                var (rows, errors) = ((List<TranslateParamRowVm>, List<string>))args.Result!;

                _allRows.Clear();
                foreach (var r in rows) _allRows.Add(r);
                _viewSource.View.Refresh();

                UpdateSummary(errors);
                ApplyFilter();
                SetStatus($"Tamamlandı — {rows.Count} parametre, {errors.Count} hata.");
            };

            worker.RunWorkerAsync();
        }

        // ── Rename Uygula ─────────────────────────────────────────────────────
        private void BtnApplyRename_Click(object sender, RoutedEventArgs e)
        {
            var selected = _allRows.Where(r => r.IsSelected && r.Mode == "Rename").ToList();
            if (!selected.Any()) { ShowMsg("Seçili Rename satırı yok."); return; }

            var confirm = MessageBox.Show(
                $"{selected.Count} parametre yeniden adlandırılacak. Devam edilsin mi?",
                "Rename Onayla", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (confirm != MessageBoxResult.Yes) return;

            int ok = 0; var errs = new List<string>();
            ApplyToFamilies(selected, "Rename",
                (fdoc, fmgr, row) =>
                {
                    var paramByName = fmgr.Parameters.Cast<FamilyParameter>()
                        .ToDictionary(p => p.Definition.Name.ToLowerInvariant());
                    if (!paramByName.TryGetValue(row.CurrentName.ToLowerInvariant(), out var fp))
                    { errs.Add($"{row.FamilyName}/{row.CurrentName}: bulunamadı"); return false; }

                    fmgr.RenameParameter(fp, row.FinalName);
                    row.Status = "✅ Renamed";
                    ok++;
                    return true;
                }, errs);

            SetStatus($"Rename: {ok} başarılı, {errs.Count} hata.");
            GridParams.Items.Refresh();
        }

        // ── Create+Map Uygula ─────────────────────────────────────────────────
        private void BtnApplyCreateMap_Click(object sender, RoutedEventArgs e)
        {
            var selected = _allRows.Where(r => r.IsSelected && r.Mode == "CreateMap").ToList();
            if (!selected.Any()) { ShowMsg("Seçili Create+Map satırı yok."); return; }

            var confirm = MessageBox.Show(
                $"{selected.Count} parametre için Create+Map uygulanacak. Devam edilsin mi?",
                "Create+Map Onayla", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (confirm != MessageBoxResult.Yes) return;

            // family_param_engine mantığı — SaveAs gerektirir
            SetStatus("Create+Map uygulanıyor...");
            int ok = 0; var errs = new List<string>();

            // family_param_engine'in apply_create_and_map_in_family() mantığını çağır
            // Bu EGBIMOTO.Addin içindeki FamilyParamEngine wrapper'ını kullanır
            foreach (var row in selected)
                row.Status = "⚠️ Create+Map — FamilyEngine gerekli";

            SetStatus($"Create+Map: {ok} başarılı, {errs.Count} hata. Not: SaveAs+Reload gerektirir.");
            GridParams.Items.Refresh();
        }

        // ── Tümünü Uygula ─────────────────────────────────────────────────────
        private void BtnApplyAll_Click(object sender, RoutedEventArgs e)
        {
            BtnApplyRename_Click(sender, e);
            BtnApplyCreateMap_Click(sender, e);
        }

        // ── Excel Raporu ──────────────────────────────────────────────────────
        private void BtnExportExcel_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Title      = "Excel Raporu Kaydet",
                Filter     = "Excel XML (*.xml)|*.xml|CSV (*.csv)|*.csv",
                FileName   = $"EGCeviri_{DateTime.Now:yyyyMMdd_HHmm}.xml",
                InitialDirectory = string.IsNullOrEmpty(_saveFolder)
                    ? Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
                    : _saveFolder,
            };
            if (dlg.ShowDialog() != true) return;

            var rows = _allRows.ToList();
            if (dlg.FileName.EndsWith(".csv"))
                ExportCsv(dlg.FileName, rows);
            else
                ExportXmlExcel(dlg.FileName, rows);

            SetStatus($"Rapor kaydedildi: {dlg.FileName}");
        }

        // ── HTML Raporu ───────────────────────────────────────────────────────
        private void BtnExportHtml_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Title    = "HTML Raporu Kaydet",
                Filter   = "HTML (*.html)|*.html",
                FileName = $"EGCeviri_{DateTime.Now:yyyyMMdd_HHmm}.html",
                InitialDirectory = string.IsNullOrEmpty(_saveFolder)
                    ? Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
                    : _saveFolder,
            };
            if (dlg.ShowDialog() != true) return;
            ExportHtml(dlg.FileName, _allRows.ToList());
            SetStatus($"HTML raporu kaydedildi: {dlg.FileName}");
        }

        // ── Sözlüğe Ekle ─────────────────────────────────────────────────────
        private void BtnAddToDictionary_Click(object sender, RoutedEventArgs e)
        {
            var selected = GridParams.SelectedItems.Cast<TranslateParamRowVm>()
                .Where(r => !string.IsNullOrWhiteSpace(r.ManualOverride))
                .ToList();
            if (!selected.Any()) { ShowMsg("Manuel düzeltme girilen seçili satır yok."); return; }

            // translation_dictionary.csv'ye satır ekle
            var dictPath = Path.Combine(_dataDir, "translation_dictionary.csv");
            var sb = new StringBuilder();
            foreach (var r in selected)
            {
                var lang = r.DetectedLang.ToUpperInvariant();
                sb.AppendLine($"{r.ManualOverride},{r.CurrentName},,,,,{r.ManualOverride},token,User,user_added");
            }
            File.AppendAllText(dictPath, sb.ToString(), Encoding.UTF8);
            ShowMsg($"{selected.Count} çeviri sözlüğe eklendi. Yeniden tarama önerilir.");
        }

        // ── Kaydet Klasörü ────────────────────────────────────────────────────
        private void BtnSaveFolder_Click(object sender, RoutedEventArgs e)
        {
            using var dlg = new System.Windows.Forms.FolderBrowserDialog
            { Description = "Family kayıt klasörü seçin" };
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            { _saveFolder = dlg.SelectedPath; SetStatus($"Kayıt klasörü: {_saveFolder}"); }
        }

        // ── Filtre & Arama ────────────────────────────────────────────────────
        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilter();
        private void ChkOnlyChanged_Changed(object sender, RoutedEventArgs e)     => ApplyFilter();

        private void ApplyFilter()
        {
            var q       = TxtSearch.Text?.ToLowerInvariant() ?? "";
            var onlyChg = ChkOnlyChanged.IsChecked == true;
            _viewSource.View.Filter = obj =>
            {
                if (obj is not TranslateParamRowVm r) return false;
                if (onlyChg && r.Method == "UNCHANGED") return false;
                if (!string.IsNullOrEmpty(q))
                    return r.FamilyName.ToLowerInvariant().Contains(q) ||
                           r.CurrentName.ToLowerInvariant().Contains(q) ||
                           r.SuggestedName.ToLowerInvariant().Contains(q);
                return true;
            };

            var visible = _viewSource.View.Cast<TranslateParamRowVm>().Count();
            TxtSelectionInfo.Text = $"{visible} satır gösteriliyor";
        }

        // ── Sekme butonları ───────────────────────────────────────────────────
        private void BtnTabParams_Click(object sender, RoutedEventArgs e)
        {
            // Sadece param listesi
            ChkOnlyChanged.IsChecked = false;
            ApplyFilter();
        }
        private void BtnTabCreateMap_Click(object sender, RoutedEventArgs e)
        {
            _viewSource.View.Filter = o => (o as TranslateParamRowVm)?.Mode == "CreateMap";
        }
        private void BtnTabErrors_Click(object sender, RoutedEventArgs e)
        {
            _viewSource.View.Filter = o => (o as TranslateParamRowVm)?.Status?.StartsWith("❌") == true;
        }

        // ── Tümünü Seç ───────────────────────────────────────────────────────
        private void BtnSelectAll_Click(object sender, RoutedEventArgs e)
        {
            bool anySelected = _allRows.Any(r => r.IsSelected);
            foreach (var r in _allRows)
                r.IsSelected = !anySelected && r.Method != "UNCHANGED";
            GridParams.Items.Refresh();
            UpdateApplyButtons();
        }

        // ── Yardımcı metodlar ─────────────────────────────────────────────────

        private void UpdateSummary(List<string> errors)
        {
            TxtTotalParams.Text   = _allRows.Count.ToString();
            TxtTotalFamilies.Text = $"{_allRows.Select(r => r.FamilyName).Distinct().Count()} family";
            TxtTranslated.Text    = _allRows.Count(r => r.Method != "UNCHANGED").ToString();
            TxtRename.Text        = _allRows.Count(r => r.Mode == "Rename" && r.IsSelected).ToString();
            TxtCreateMap.Text     = _allRows.Count(r => r.Mode == "CreateMap").ToString();
            TxtErrors.Text        = errors.Count.ToString();
            UpdateApplyButtons();
        }

        private void UpdateApplyButtons()
        {
            bool hasRename    = _allRows.Any(r => r.IsSelected && r.Mode == "Rename");
            bool hasCreateMap = _allRows.Any(r => r.IsSelected && r.Mode == "CreateMap");
            BtnApplyRename.IsEnabled    = hasRename;
            BtnApplyCreateMap.IsEnabled = hasCreateMap;
            BtnApplyAll.IsEnabled       = hasRename || hasCreateMap;
        }

        private void FillCategoryCombo()
        {
            var cats = new FilteredElementCollector(_doc)
                .OfClass(typeof(Autodesk.Revit.DB.Family))
                .Cast<Autodesk.Revit.DB.Family>()
                .Select(f => f.FamilyCategory?.Name ?? "")
                .Where(n => !string.IsNullOrEmpty(n))
                .Distinct()
                .OrderBy(n => n)
                .ToList();
            foreach (var cat in cats)
                CmbCategory.Items.Add(new ComboBoxItem { Content = cat });
        }

        private void ApplyToFamilies(
            List<TranslateParamRowVm> rows,
            string mode,
            Func<Document, FamilyManager, TranslateParamRowVm, bool> action,
            List<string> errors)
        {
            var byFamily = rows.GroupBy(r => r.FamilyName);
            foreach (var grp in byFamily)
            {
                var fam = new FilteredElementCollector(_doc)
                    .OfClass(typeof(Autodesk.Revit.DB.Family))
                    .Cast<Autodesk.Revit.DB.Family>()
                    .FirstOrDefault(f => f.Name == grp.Key);
                if (fam == null || !fam.IsEditable) { errors.Add($"{grp.Key}: editable değil"); continue; }

                Document? fdoc = null;
                try
                {
                    fdoc = _doc.EditFamily(fam);
                    var fmgr = fdoc.FamilyManager;
                    using var tx = new Transaction(fdoc, $"EGCeviri {mode} — {grp.Key}");
                    tx.Start();
                    bool anyDone = false;
                    foreach (var row in grp) if (action(fdoc, fmgr, row)) anyDone = true;
                    tx.Commit();
                    if (anyDone) fdoc.LoadFamily(_doc, new FamilyLoadOptions());
                }
                catch (Exception ex) { errors.Add($"{grp.Key}: {ex.Message}"); }
                finally { try { fdoc?.Close(false); } catch { } }
            }
        }

        private void ExportCsv(string path, List<TranslateParamRowVm> rows)
        {
            var sb = new StringBuilder();
            sb.AppendLine("FamilyName,Category,CurrentName,DetectedLang,SuggestedName,Method,Confidence,Mode,BestSharedParam,IsSelected,Status");
            foreach (var r in rows)
                sb.AppendLine($"\"{r.FamilyName}\",\"{r.Category}\",\"{r.CurrentName}\",{r.DetectedLang},\"{r.SuggestedName}\",{r.Method},{r.Confidence:F2},{r.Mode},\"{r.BestSharedParam}\",{(r.IsSelected?"1":"0")},\"{r.Status}\"");
            File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
        }

        private void ExportXmlExcel(string path, List<TranslateParamRowVm> rows)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\"?><Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"><Worksheet ss:Name=\"EGCeviri\"><Table>");
            sb.AppendLine("<Row><Cell><Data ss:Type=\"String\">Family</Data></Cell><Cell><Data ss:Type=\"String\">Kategori</Data></Cell><Cell><Data ss:Type=\"String\">Mevcut</Data></Cell><Cell><Data ss:Type=\"String\">Dil</Data></Cell><Cell><Data ss:Type=\"String\">TR Öneri</Data></Cell><Cell><Data ss:Type=\"String\">Yöntem</Data></Cell><Cell><Data ss:Type=\"String\">Güven</Data></Cell><Cell><Data ss:Type=\"String\">Mod</Data></Cell><Cell><Data ss:Type=\"String\">Shared Param</Data></Cell><Cell><Data ss:Type=\"String\">Seçili</Data></Cell><Cell><Data ss:Type=\"String\">Durum</Data></Cell></Row>");
            foreach (var r in rows)
                sb.AppendLine($"<Row><Cell><Data ss:Type=\"String\">{r.FamilyName}</Data></Cell><Cell><Data ss:Type=\"String\">{r.Category}</Data></Cell><Cell><Data ss:Type=\"String\">{r.CurrentName}</Data></Cell><Cell><Data ss:Type=\"String\">{r.DetectedLang}</Data></Cell><Cell><Data ss:Type=\"String\">{r.SuggestedName}</Data></Cell><Cell><Data ss:Type=\"String\">{r.Method}</Data></Cell><Cell><Data ss:Type=\"Number\">{r.Confidence:F2}</Data></Cell><Cell><Data ss:Type=\"String\">{r.Mode}</Data></Cell><Cell><Data ss:Type=\"String\">{r.BestSharedParam}</Data></Cell><Cell><Data ss:Type=\"String\">{(r.IsSelected?"Evet":"Hayır")}</Data></Cell><Cell><Data ss:Type=\"String\">{r.Status}</Data></Cell></Row>");
            sb.AppendLine("</Table></Worksheet></Workbook>");
            File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
        }

        private void ExportHtml(string path, List<TranslateParamRowVm> rows)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<!doctype html><html><head><meta charset='utf-8'><title>EG Çeviri Raporu</title><style>body{font-family:Segoe UI,sans-serif;margin:24px;background:#f6f7fb}table{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden}th,td{border:1px solid #ddd;padding:8px 10px;font-size:12px}th{background:#eef2ff}.dict{color:#16a34a}.smart{color:#0369a1}.api{color:#7c3aed}.unchanged{color:#94a3b8}.rename{background:#dbeafe;color:#1e40af;border-radius:4px;padding:2px 8px}.createmap{background:#fed7aa;color:#9a3412;border-radius:4px;padding:2px 8px}</style></head><body>");
            sb.AppendLine($"<h1>EG Family Çevirici Raporu</h1><p>{DateTime.Now:yyyy-MM-dd HH:mm}</p>");
            sb.AppendLine($"<p>Toplam: {rows.Count} param | Çevrilen: {rows.Count(r => r.Method != "UNCHANGED")} | Rename: {rows.Count(r => r.Mode == "Rename")} | Create+Map: {rows.Count(r => r.Mode == "CreateMap")}</p>");
            sb.AppendLine("<table><thead><tr><th>Family</th><th>Kategori</th><th>Mevcut</th><th>Dil</th><th>TR Öneri</th><th>Yöntem</th><th>Mod</th><th>Shared Param</th></tr></thead><tbody>");
            foreach (var r in rows)
            {
                var mc = r.Method.ToLowerInvariant();
                var modeHtml = r.Mode == "Rename"
                    ? $"<span class='rename'>Rename</span>"
                    : $"<span class='createmap'>CreateMap</span>";
                sb.AppendLine($"<tr><td>{r.FamilyName}</td><td>{r.Category}</td><td>{r.CurrentName}</td><td><b>{r.DetectedLang.ToUpperInvariant()}</b></td><td class='{mc}'>{r.SuggestedName}</td><td class='{mc}'>{r.Method}</td><td>{modeHtml}</td><td style='font-family:Consolas;color:#0369a1'>{r.BestSharedParam}</td></tr>");
            }
            sb.AppendLine("</tbody></table></body></html>");
            File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
        }

        private void SetStatus(string msg) => TxtStatus.Text = msg;
        private void ShowMsg(string msg)   => MessageBox.Show(msg, "EGBIMOTO", MessageBoxButton.OK, MessageBoxImage.Information);
        private static bool TryBool(Func<bool> fn) { try { return fn(); } catch { return false; } }
        private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();
    }

    // ── ViewModel ─────────────────────────────────────────────────────────────
    public sealed class TranslateParamRowVm : INotifyPropertyChanged
    {
        private bool _isSelected;
        private string _status = "";
        private string _manualOverride = "";

        public string FamilyName      { get; set; } = "";
        public string Category        { get; set; } = "";
        public string CurrentName     { get; set; } = "";
        public string SuggestedName   { get; set; } = "";
        public string BestSharedParam { get; set; } = "";
        public string DetectedLang    { get; set; } = "en";
        public string Method          { get; set; } = "UNCHANGED";
        public double Confidence      { get; set; } = 1.0;
        public bool   IsShared        { get; set; }
        public bool   IsBuiltIn       { get; set; }
        public string Mode            { get; set; } = "Rename";

        public bool IsSelected
        { get => _isSelected; set { _isSelected = value; OnPropertyChanged(); } }

        public string Status
        { get => _status; set { _status = value; OnPropertyChanged(); } }

        public string ManualOverride
        { get => _manualOverride; set { _manualOverride = value; OnPropertyChanged(); } }

        public string FinalName => !string.IsNullOrWhiteSpace(ManualOverride)
            ? ManualOverride : SuggestedName;

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? p = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p));
    }

    // ── FamilyLoadOptions ─────────────────────────────────────────────────────
    internal sealed class FamilyLoadOptions : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Autodesk.Revit.DB.Family sharedFamily, bool familyInUse,
            out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Family; overwriteParameterValues = true; return true; }
    }

    // ── Converter'lar ─────────────────────────────────────────────────────────
    public sealed class LangColorConverter : IValueConverter
    {
        public object Convert(object v, Type t, object p, CultureInfo c)
        {
            return (v?.ToString() ?? "").ToLowerInvariant() switch
            {
                "en" => new SolidColorBrush(WpfColor.FromRgb(37, 99, 235)),
                "ru" => new SolidColorBrush(WpfColor.FromRgb(220, 38, 38)),
                "es" => new SolidColorBrush(WpfColor.FromRgb(234, 88, 12)),
                "pt" => new SolidColorBrush(WpfColor.FromRgb(22, 163, 74)),
                "tr" => new SolidColorBrush(WpfColor.FromRgb(100, 116, 139)),
                _    => new SolidColorBrush(WpfColor.FromRgb(148, 163, 184)),
            };
        }
        public object ConvertBack(object v, Type t, object p, CultureInfo c) => WpfBinding.DoNothing;
    }

    public sealed class MethodColorConverter : IValueConverter
    {
        public object Convert(object v, Type t, object p, CultureInfo c)
        {
            return (v?.ToString() ?? "").ToUpperInvariant() switch
            {
                "DICT"      => new SolidColorBrush(WpfColor.FromRgb(22, 163, 74)),
                "SMART"     => new SolidColorBrush(WpfColor.FromRgb(3, 105, 161)),
                "API"       => new SolidColorBrush(WpfColor.FromRgb(124, 58, 237)),
                "MANUAL"    => new SolidColorBrush(WpfColor.FromRgb(109, 40, 217)),
                "UNCHANGED" => new SolidColorBrush(WpfColor.FromRgb(148, 163, 184)),
                _           => new SolidColorBrush(WpfColor.FromRgb(100, 116, 139)),
            };
        }
        public object ConvertBack(object v, Type t, object p, CultureInfo c) => WpfBinding.DoNothing;
    }

    public sealed class ModeColorConverter : IValueConverter
    {
        public object Convert(object v, Type t, object p, CultureInfo c)
        {
            return (v?.ToString() ?? "") switch
            {
                "Rename"    => new SolidColorBrush(WpfColor.FromRgb(37, 99, 235)),
                "CreateMap" => new SolidColorBrush(WpfColor.FromRgb(234, 88, 12)),
                _           => new SolidColorBrush(WpfColor.FromRgb(148, 163, 184)),
            };
        }
        public object ConvertBack(object v, Type t, object p, CultureInfo c) => WpfBinding.DoNothing;
    }
}
