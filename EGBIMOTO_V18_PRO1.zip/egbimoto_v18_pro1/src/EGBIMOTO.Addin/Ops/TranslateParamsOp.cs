// EGBIMOTO V18 — TranslateParamsOp
// Op: translate_params | Domain: Elements→TranslateParamsResult

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Autodesk.Revit.DB;
using EGBIMOTO.Core.Ops;
using EGBIMOTO.Core.Translation;
using EGBIMOTO.Addin.Host;
using RevitFamily = Autodesk.Revit.DB.Family;

namespace EGBIMOTO.Addin.Ops
{
    public static class TranslateParamsOp
    {
        [EgOp("translate_params",
            Category    = "Translation",
            Description = "Family parametrelerini otomatik tespit eder ve TR karşılığını önerir veya uygular.",
            InputType   = "List<Element>",
            OutputType  = "TranslateParamsResult")]
        public static TranslateParamsResult Execute(OpContext ctx)
        {
            var rctx = (RevitOpContext)ctx;

            var srcLang         = ctx.GetParam<string>("source_language", "auto");
            bool applyRename    = ctx.GetParam<bool>("apply_rename",      true);
            bool applyCreateMap = ctx.GetParam<bool>("apply_create_map",  true);
            int  maxFamilies    = ctx.GetParam<int>("max_families",       200);

            // data/translation/ klasörünü add-in assembly yanından bul
            var asmDir  = Path.GetDirectoryName(typeof(TranslateParamsOp).Assembly.Location) ?? "";
            var dataDir = Path.Combine(asmDir, "data", "translation");
            if (!Directory.Exists(dataDir))
            {
                ctx.Log($"[translate_params] data/translation/ bulunamadı: {dataDir}");
                return new TranslateParamsResult { Errors = { "data/translation/ klasörü bulunamadı." } };
            }

            var engine = TranslatorEngine.Load(dataDir);
            var doc    = rctx.Doc;

            List<RevitFamily> families;
            if (ctx.Input is List<Element> inputElements)
            {
                families = inputElements.OfType<RevitFamily>().Take(maxFamilies).ToList();
                if (!families.Any())
                    families = inputElements
                        .OfType<FamilyInstance>()
                        .Select(fi => fi.Symbol?.Family)
                        .Where(f => f != null)
                        .Select(f => f!)
                        .DistinctBy(f => f.Id)
                        .Take(maxFamilies)
                        .ToList();
            }
            else
            {
                families = new FilteredElementCollector(doc)
                    .OfClass(typeof(RevitFamily))
                    .Cast<RevitFamily>()
                    .Take(maxFamilies)
                    .ToList();
            }

            var result = new TranslateParamsResult();

            foreach (var fam in families)
            {
                Document? fdoc = null;
                try
                {
                    if (!fam.IsEditable) continue;
                    fdoc = doc.EditFamily(fam);
                    var fmgr    = fdoc.FamilyManager;
                    var catName = fam.FamilyCategory?.Name ?? "";

                    foreach (FamilyParameter fp in fmgr.Parameters)
                    {
                        string currentName;
                        try { currentName = fp.Definition.Name; } catch { continue; }

                        var detectedLang = string.Equals(srcLang, "auto", StringComparison.OrdinalIgnoreCase)
                            ? TranslatorEngine.DetectLanguage(currentName)
                            : srcLang.ToLowerInvariant();

                        bool isShared  = TryGetIsShared(fp);
                        bool isBuiltIn = TryGetIsBuiltIn(fp);

                        if (detectedLang == "tr")
                        {
                            result.Rows.Add(new TranslateParamRow
                            {
                                FamilyName = fam.Name, Category = catName,
                                CurrentName = currentName, SuggestedName = currentName,
                                Method = "UNCHANGED", IsShared = isShared, IsBuiltIn = isBuiltIn,
                            });
                            continue;
                        }

                        var xlat       = engine.Translate(currentName, detectedLang, "tr");
                        var bestShared = engine.FindBestSharedParam(catName, currentName, xlat.Text);
                        var mode       = (!isShared && !isBuiltIn) ? "Rename" : "CreateMap";

                        result.Rows.Add(new TranslateParamRow
                        {
                            FamilyName = fam.Name,          Category      = catName,
                            CurrentName = currentName,       SuggestedName = xlat.Text,
                            BestSharedParam = bestShared,    DetectedLang  = detectedLang,
                            Method = xlat.Method.ToString().ToUpperInvariant(),
                            Confidence = xlat.Confidence,    IsShared = isShared,
                            IsBuiltIn = isBuiltIn,           Mode     = mode,
                            IsSelected = xlat.Changed && !isShared && !isBuiltIn,
                        });
                    }
                }
                catch (Exception ex) { result.Errors.Add($"{fam.Name}: {ex.Message}"); }
                finally { try { fdoc?.Close(false); } catch { } }
            }

            result.TotalFamilies   = families.Count;
            result.TotalParams     = result.Rows.Count;
            result.TranslatedCount = result.Rows.Count(r => r.Method != "UNCHANGED");
            result.RenameCount     = result.Rows.Count(r => r.Mode == "Rename"    && r.IsSelected);
            result.CreateMapCount  = result.Rows.Count(r => r.Mode == "CreateMap");

            ctx.Log($"[translate_params] {result.TotalFamilies} family, {result.TotalParams} param, " +
                    $"{result.TranslatedCount} çevrildi, {result.RenameCount} rename önerisi");
            return result;
        }

        private static bool TryGetIsShared(FamilyParameter fp)  { try { return fp.IsShared;     } catch { return false; } }
        private static bool TryGetIsBuiltIn(FamilyParameter fp) { try { return fp.Id.Value < 0; } catch { return false; } }
    }

    public sealed class TranslateParamsResult
    {
        public int TotalFamilies   { get; set; }
        public int TotalParams     { get; set; }
        public int TranslatedCount { get; set; }
        public int RenameCount     { get; set; }
        public int CreateMapCount  { get; set; }
        public List<TranslateParamRow> Rows   { get; } = new();
        public List<string>            Errors { get; } = new();
        public string Summary =>
            $"{TotalFamilies} family, {TotalParams} param: " +
            $"{TranslatedCount} çevrildi, {RenameCount} rename, {CreateMapCount} create+map önerisi";
    }

    public sealed class TranslateParamRow
    {
        public string FamilyName      { get; set; } = "";
        public string Category        { get; set; } = "";
        public string CurrentName     { get; set; } = "";
        public string SuggestedName   { get; set; } = "";
        public string BestSharedParam { get; set; } = "";
        public string DetectedLang    { get; set; } = "en";
        public string Method          { get; set; } = "UNCHANGED";
        public double Confidence      { get; set; } = 1.0;
        public bool   IsShared        { get; set; }
        public bool   IsBuiltIn       { get; set; }
        public string Mode            { get; set; } = "Rename";
        public bool   IsSelected      { get; set; }
        public string Status          { get; set; } = "";
        public string ManualOverride  { get; set; } = "";
        public string FinalName =>
            !string.IsNullOrWhiteSpace(ManualOverride) ? ManualOverride : SuggestedName;
    }
}
