// ═══════════════════════════════════════════════════════════════════════════════
//  EGBIMOTO V18 — TranslatorEngine
//
//  EGTranslatorProV2 translator_engine.py + data_loader.py → C# .NET 8 portu
//
//  Desteklenen diller: TR | EN | ES | PT | RU
//
//  3 kademeli çeviri:
//    1. DICT   — translation_dictionary.csv tam eşleşme
//    2. SMART  — token bazlı parçalı çeviri (camel-case, alt çizgi, boşluk)
//    3. API    — MyMemory ücretsiz API (opsiyonel, internet gerektirir)
//
//  Yükleme:
//    var engine = TranslatorEngine.Load("data/translation/");
//    var (tr, method) = engine.Translate("Wall Height", "en", "tr");
//    // → ("Duvar Yüksekliği", MatchType.Dict)
// ═══════════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EGBIMOTO.Core.Translation
{
    // ── Sonuç tipleri ─────────────────────────────────────────────────────────

    public enum MatchType { Unchanged, Cache, Dict, Smart, Api, Manual }

    public sealed class TranslateResult
    {
        public string Text      { get; init; } = "";
        public MatchType Method { get; init; } = MatchType.Unchanged;
        public double Confidence { get; init; } = 1.0;

        public bool Changed => Method != MatchType.Unchanged;
        public override string ToString() => Text;
    }

    // ── TranslationData ───────────────────────────────────────────────────────

    public sealed class TranslationData
    {
        // (src, tgt, normalizedText) → çeviri
        public Dictionary<(string, string, string), string> Exact  { get; } = new();
        public Dictionary<(string, string, string), string> Tokens { get; } = new();

        // TR karşılığı bilinen standart parametreler
        public Dictionary<string, (string TR, string EN)> Standard { get; } = new();

        // SharedParam SSoT: normalKey → {guid, name, ...}
        public Dictionary<string, Dictionary<string, string>> SharedParams { get; } = new();

        // Category → common param isimleri (doors/windows/walls...)
        public static readonly Dictionary<string, Dictionary<string, string>> CategoryCommon =
            new(StringComparer.OrdinalIgnoreCase)
        {
            ["doors"] = new()
            {
                ["firerating"]           = "TR_KapiYanginSinifi",
                ["thermaltransmittance"] = "TR_KapiUDegeri",
                ["acousticrating"]       = "TR_KapiSesYalitim",
                ["reference"]            = "TR_KapiTipi",
                ["height"]               = "TR_KapiYukseklik",
                ["width"]                = "TR_KapiGenislik",
                ["rough height"]         = "TR_KapiKabaYukseklik",
                ["rough width"]          = "TR_KapiKabaGenislik",
            },
            ["windows"] = new()
            {
                ["thermaltransmittance"] = "TR_PencereUDegeri",
                ["acousticrating"]       = "TR_PencereSesYalitim",
                ["reference"]            = "TR_PencereTipi",
                ["height"]               = "TR_PencereYukseklik",
                ["width"]                = "TR_PencereGenislik",
            },
            ["walls"] = new()
            {
                ["firerating"]           = "TR_DuvarREI",
                ["thermaltransmittance"] = "TR_DuvarUDegeri",
                ["acousticrating"]       = "TR_DuvarSesYalitim",
            },
            ["floors"] = new()
            {
                ["firerating"]           = "TR_DosemeREI",
                ["thermaltransmittance"] = "TR_DosemeUDegeri",
                ["acousticrating"]       = "TR_DosemeSesYalitim",
            },
            ["rooms"] = new()
            {
                ["name"]     = "TR_MahalAdi",
                ["number"]   = "TR_MahalKodu",
                ["category"] = "TR_MahalFonksiyonu",
            },
        };

        public static readonly Dictionary<string, string> CategoryPrefix =
            new(StringComparer.OrdinalIgnoreCase)
        {
            ["Doors"]               = "Kapi",
            ["Windows"]             = "Pencere",
            ["Furniture"]           = "Mobilya",
            ["Generic Models"]      = "Genel",
            ["Mechanical Equipment"]= "Mekanik",
            ["Electrical Fixtures"] = "Elektrik",
            ["Lighting Fixtures"]   = "Aydinlatma",
            ["Plumbing Fixtures"]   = "Sihhi",
            ["Walls"]               = "Duvar",
            ["Floors"]              = "Doseme",
            ["Roofs"]               = "Cati",
            ["Rooms"]               = "Mahal",
            ["Project Information"] = "Proje",
        };
    }

    // ── TranslatorEngine ─────────────────────────────────────────────────────

    public sealed class TranslatorEngine
    {
        private readonly TranslationData _data;
        private readonly bool _useApi;
        private readonly Dictionary<(string, string, string), TranslateResult> _cache = new();

        private static readonly HashSet<string> StopTokens =
            new(StringComparer.OrdinalIgnoreCase) { "tr", "en", "es", "pt", "ru" };

        private static readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(5) };

        // ── Yükleme ───────────────────────────────────────────────────────────

        public static TranslatorEngine Load(string dataDir, bool useApi = false)
        {
            var data = new TranslationData();
            LoadCsvFiles(dataDir, data);
            LoadSharedParamMaster(
                Path.Combine(dataDir, "TR_BIM_SharedParameters_MASTER_QA_CSB2026.txt"), data);
            return new TranslatorEngine(data, useApi);
        }

        private TranslatorEngine(TranslationData data, bool useApi)
        {
            _data   = data;
            _useApi = useApi;
        }

        // ── Ana çeviri metodu ─────────────────────────────────────────────────

        public TranslateResult Translate(string text, string src, string tgt, string manual = "")
        {
            src = src.ToUpperInvariant();
            tgt = tgt.ToUpperInvariant();
            var original = text ?? "";

            if (!string.IsNullOrWhiteSpace(manual))
                return new TranslateResult { Text = manual.Trim(), Method = MatchType.Manual };

            if (string.IsNullOrWhiteSpace(original) || src == tgt)
                return new TranslateResult { Text = original, Method = MatchType.Unchanged };

            var cacheKey = (src, tgt, NormalizeKey(original));
            if (_cache.TryGetValue(cacheKey, out var cached)) return cached;

            // 1. Tam sözlük eşleşmesi
            if (_data.Exact.TryGetValue(cacheKey, out var exact))
                return Store(cacheKey, new TranslateResult { Text = exact, Method = MatchType.Dict, Confidence = 1.0 });

            // 2. Smart (token bazlı)
            var smart = SmartTranslate(original, src, tgt);
            if (smart != null)
                return Store(cacheKey, new TranslateResult { Text = smart, Method = MatchType.Smart, Confidence = 0.85 });

            // 3. API (opsiyonel)
            if (_useApi)
            {
                var api = ApiTranslate(original, src, tgt).GetAwaiter().GetResult();
                if (api != null)
                    return Store(cacheKey, new TranslateResult { Text = api, Method = MatchType.Api, Confidence = 0.70 });
            }

            return Store(cacheKey, new TranslateResult { Text = original, Method = MatchType.Unchanged });
        }

        /// <summary>Toplu çeviri — birden fazla metin için batch.</summary>
        public List<TranslateResult> TranslateBatch(IEnumerable<string> texts, string src, string tgt)
            => texts.Select(t => Translate(t, src, tgt)).ToList();

        /// <summary>
        /// Parametre adı için en iyi TR shared param adını döndürür.
        /// EGTranslatorProV2 find_best_shared_param() C# portu.
        /// </summary>
        public string FindBestSharedParam(string categoryName, string sourceName, string translatedName = "")
        {
            var names = new[] { sourceName, translatedName }.Where(n => !string.IsNullOrWhiteSpace(n));

            // 1. SharedParams SSoT'te direkt bak
            foreach (var name in names)
            {
                var nk = NormalizeKey(name);
                if (_data.SharedParams.TryGetValue(nk, out var sp))
                    return sp["name"];
            }

            // 2. Category bazlı common map
            var catKey = SanitizeAscii(categoryName ?? "");
            foreach (var name in names)
            {
                var nk = SanitizeAscii(name);
                if (TranslationData.CategoryCommon.TryGetValue(catKey, out var common) &&
                    common.TryGetValue(nk, out var commonParam))
                    return commonParam;
            }

            // 3. Prefix + camelCase oluştur
            TranslationData.CategoryPrefix.TryGetValue(categoryName ?? "", out var prefix);
            prefix ??= CamelJoin(categoryName ?? "Genel");
            var translated = !string.IsNullOrWhiteSpace(translatedName) ? translatedName : (sourceName ?? "Parametre");
            var candidate = $"TR_{prefix}{CamelJoin(translated)}";

            if (_data.SharedParams.ContainsKey(NormalizeKey(candidate)))
                return candidate;

            return candidate;
        }

        // ── Smart çeviri ──────────────────────────────────────────────────────

        private string? SmartTranslate(string text, string src, string tgt)
        {
            // Separatörlere göre böl: _, -, /, (), [], boşluk, .
            var chunks = Regex.Split(text, @"([_\-\/\(\)\[\]\s\.]+)");
            var out_ = new List<string>();
            bool changed = false;

            foreach (var chunk in chunks)
            {
                if (string.IsNullOrEmpty(chunk)) continue;

                if (Regex.IsMatch(chunk, @"^[_\-\/\(\)\[\]\s\.]+$"))
                { out_.Add(chunk); continue; }

                var nk = NormalizeKey(chunk);
                if (StopTokens.Contains(nk)) { out_.Add(chunk); continue; }

                // Tam eşleşme
                if (_data.Exact.TryGetValue((src, tgt, nk), out var ex))
                { out_.Add(ex); changed = true; continue; }

                // Token eşleşme
                if (_data.Tokens.TryGetValue((src, tgt, nk), out var tok))
                { out_.Add(tok); changed = true; continue; }

                // CamelCase / sayı-harf parçala
                var camelParts = Regex.Matches(chunk,
                    @"\d+[A-Z]+|[A-Z]?[a-zçğıöşü]+|[A-Z]+(?=[A-Z]|$)|\d+",
                    RegexOptions.None).Cast<Match>().Select(m => m.Value).ToList();

                if (camelParts.Count > 1)
                {
                    var local = new List<string>();
                    bool localChanged = false;
                    foreach (var part in camelParts)
                    {
                        if (_data.Tokens.TryGetValue((src, tgt, NormalizeKey(part)), out var pt))
                        { local.Add(pt); localChanged = true; }
                        else local.Add(part);
                    }
                    out_.Add(string.Join(" ", local));
                    changed = changed || localChanged;
                }
                else out_.Add(chunk);
            }

            return changed ? string.Join("", out_) : null;
        }

        // ── API çeviri (MyMemory) ─────────────────────────────────────────────

        private async Task<string?> ApiTranslate(string text, string src, string tgt)
        {
            try
            {
                var q   = Uri.EscapeDataString(text);
                var url = $"https://api.mymemory.translated.net/get?q={q}&langpair={src.ToLower()}|{tgt.ToLower()}";
                var resp = await _http.GetStringAsync(url);
                using var doc = JsonDocument.Parse(resp);
                var val = doc.RootElement
                    .GetProperty("responseData")
                    .GetProperty("translatedText")
                    .GetString()?.Trim() ?? "";

                if (string.IsNullOrEmpty(val)) return null;
                if (val.ToUpperInvariant().StartsWith("MYMEMORY") ||
                    val.ToUpperInvariant().StartsWith("PLEASE SELECT")) return null;
                if (NormalizeKey(val) == NormalizeKey(text)) return null;
                return val;
            }
            catch { return null; }
        }

        // ── CSV Yükleme ───────────────────────────────────────────────────────

        private static readonly Dictionary<string, List<string>> LangCols = new()
        {
            ["TR"] = new() { "Terim_TR", "TR_Name", "ParametreAdı", "StandartParametre_TR" },
            ["EN"] = new() { "StandartKarsilik_EN", "EN_Name", "StandartParametre_EN" },
            ["ES"] = new() { "Terim_ES" },
            ["PT"] = new() { "Terim_PT" },
            ["RU"] = new() { "Terim_RU" },
        };

        private static void LoadCsvFiles(string dataDir, TranslationData data)
        {
            var files = new[]
            {
                "translation_dictionary.csv",
                "semantic_dictionary.csv",
                "standard_parameters.csv",
                "shared_param_master_ref.csv",
            };

            foreach (var fn in files)
            {
                var path = Path.Combine(dataDir, fn);
                if (!File.Exists(path)) continue;
                foreach (var row in ReadCsv(path))
                    BindDictionaryRow(data, row);
            }
        }

        private static void BindDictionaryRow(TranslationData data, Dictionary<string, string> row)
        {
            foreach (var src in LangCols.Keys)
            {
                var srcText = FirstValue(row, LangCols[src]);
                if (string.IsNullOrWhiteSpace(srcText)) continue;

                foreach (var tgt in LangCols.Keys)
                {
                    if (tgt == src) continue;
                    var tgtText = FirstValue(row, LangCols[tgt]);
                    if (string.IsNullOrWhiteSpace(tgtText)) continue;

                    var key = (src, tgt, NormalizeKey(srcText));
                    data.Exact[key] = tgtText;

                    // Tek kelimeyse token olarak da kaydet
                    if (!srcText.Contains(' ') && !tgtText.Contains(' '))
                        data.Tokens[(src, tgt, NormalizeKey(srcText))] = tgtText;
                }

                // Standard map (TR ↔ EN)
                var tr = FirstValue(row, LangCols["TR"]);
                var en = FirstValue(row, LangCols["EN"]);
                if (!string.IsNullOrWhiteSpace(tr) && !string.IsNullOrWhiteSpace(en))
                {
                    data.Standard[NormalizeKey(tr)] = (tr, en);
                    data.Standard[NormalizeKey(en)] = (tr, en);
                }
            }
        }

        private static void LoadSharedParamMaster(string path, TranslationData data)
        {
            if (!File.Exists(path)) return;
            var groups = new Dictionary<string, string>();
            foreach (var line in File.ReadAllLines(path, Encoding.UTF8))
            {
                if (string.IsNullOrEmpty(line) || line.StartsWith("#")) continue;
                var parts = line.Split('\t');
                if (parts[0] == "GROUP" && parts.Length >= 3)
                    groups[parts[1]] = parts[2];
                else if (parts[0] == "PARAM" && parts.Length >= 10)
                {
                    var name = parts[2];
                    data.SharedParams[NormalizeKey(name)] = new Dictionary<string, string>
                    {
                        ["guid"]       = parts[1],
                        ["name"]       = name,
                        ["datatype"]   = parts[3],
                        ["group_id"]   = parts[5],
                        ["group_name"] = groups.TryGetValue(parts[5], out var gn) ? gn : "",
                    };
                }
            }
        }

        // ── CSV okuyucu ───────────────────────────────────────────────────────

        public static List<Dictionary<string, string>> ReadCsv(string path)
        {
            var rows = new List<Dictionary<string, string>>();
            try
            {
                // BOM-aware okuma
                var text = File.ReadAllText(path, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
                var lines = text.Replace("\r\n", "\n").Replace("\r", "\n").Split('\n');
                if (lines.Length < 2) return rows;

                var headers = ParseCsvLine(lines[0]);
                for (int i = 1; i < lines.Length; i++)
                {
                    if (string.IsNullOrWhiteSpace(lines[i])) continue;
                    var values = ParseCsvLine(lines[i]);
                    var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    for (int j = 0; j < headers.Count; j++)
                        row[headers[j]] = j < values.Count ? values[j] : "";
                    rows.Add(row);
                }
            }
            catch { /* yüklenemezse boş döner */ }
            return rows;
        }

        private static List<string> ParseCsvLine(string line)
        {
            var result = new List<string>();
            bool inQ = false;
            var cur = new StringBuilder();
            foreach (char c in line)
            {
                if (c == '"') { inQ = !inQ; continue; }
                if (c == ',' && !inQ) { result.Add(cur.ToString().Trim()); cur.Clear(); continue; }
                cur.Append(c);
            }
            result.Add(cur.ToString().Trim());
            return result;
        }

        // ── Yardımcılar ───────────────────────────────────────────────────────

        public static string NormalizeKey(string? value)
        {
            if (value == null) return "";
            return Regex.Replace(value.Trim().ToLowerInvariant(), @"\s+", " ");
        }

        public static string SanitizeAscii(string value)
        {
            var v = NormalizeKey(value);
            v = v.Replace("ç","c").Replace("ğ","g").Replace("ı","i")
                 .Replace("ö","o").Replace("ş","s").Replace("ü","u");
            v = Regex.Replace(v, @"[^0-9a-z ]+", " ");
            v = Regex.Replace(v, @"\s+", " ").Trim();
            return v;
        }

        public static string CamelJoin(string text)
        {
            var parts = Regex.Split(text ?? "", @"[^0-9A-Za-zÇĞİÖŞÜçğıöşü]+")
                             .Where(p => !string.IsNullOrEmpty(p));
            return string.Concat(parts.Select(p =>
                char.ToUpperInvariant(p[0]) + p.Substring(1)));
        }

        private static string FirstValue(Dictionary<string, string> row, List<string> names)
        {
            foreach (var n in names)
                if (row.TryGetValue(n, out var v) && !string.IsNullOrWhiteSpace(v))
                    return v;
            return "";
        }

        private TranslateResult Store((string, string, string) key, TranslateResult result)
        {
            _cache[key] = result;
            return result;
        }

        // ── Dil tespiti (basit heuristik) ─────────────────────────────────────

        public static string DetectLanguage(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return "en";

            // Kiril harfler → Rusça
            if (Regex.IsMatch(text, @"[\u0400-\u04FF]")) return "ru";

            // Türkçe özel karakterler
            if (Regex.IsMatch(text, @"[ğĞışİöÖüÜçÇ]")) return "tr";

            // İspanyolca karakterler
            if (Regex.IsMatch(text, @"[ñáéíóúü]", RegexOptions.IgnoreCase)) return "es";

            // Portekizce karakterler
            if (Regex.IsMatch(text, @"[ãõâêôàç]", RegexOptions.IgnoreCase)) return "pt";

            return "en"; // varsayılan
        }
    }
}
