using System;

namespace EGBIMOTO.Core.Ops
{
    /// <summary>
    /// v15 — Domain SSoT Katman A.
    ///
    /// Bir op'un semantik giriş/çıkış domain'ini kod seviyesinde bildirir.
    /// generate_op_contracts.py bu attribute'u okuyup op_contracts.json'a
    /// domain_in / domain_out olarak yazar (domain_source = "attribute").
    ///
    /// Neden gerekli:
    ///   C# tip imzası domain'i belirleyemez — kalip_all, poz_match ve calc_cost
    ///   hepsi List&lt;Dictionary&gt; döndürür ama domainleri KalipResult / PozData /
    ///   Rows'tur. Domain, tipin değil niyetin etiketidir.
    ///
    /// Öncelik zinciri (generator'da):
    ///   A. [OpDomain(...)]              ← bu attribute, en yüksek otorite
    ///   B. ManifestLinter.OpDomains    ← mevcut 150 op tablosu
    ///   C. isim + tip heuristiği        ← kalan oplar
    ///
    /// Kullanım:
    ///   [EgOp("kalip_all", Category = "Maliyet")]
    ///   [OpDomain(In = Domain.Structural, Out = Domain.KalipResult)]
    ///   public static List&lt;Dictionary&lt;string, object?&gt;&gt; KalipAll(OpContext ctx) { ... }
    ///
    /// Yeni op yazarken bu attribute'u eklemek, o op'u Pattern Üret zincir
    /// grafiğine otomatik dahil eder — Linter tablosuna elle satır eklemeye gerek kalmaz.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    public sealed class OpDomainAttribute : Attribute
    {
        public Domain In  { get; init; } = Domain.Any;
        public Domain Out { get; init; } = Domain.Any;

        public OpDomainAttribute() { }

        public OpDomainAttribute(Domain @in, Domain @out)
        {
            In  = @in;
            Out = @out;
        }
    }

    /// <summary>
    /// EGBIMOTO domain sınıflandırması — manifest zincir uyumluluğunun temeli.
    ///
    /// v15: Domain enum'unun tek tanımı burada (Core.Ops). ManifestLinter bu enum'u
    /// 'using EGBIMOTO.Core.Ops' ile kullanır. İki ayrı tanım YOKTUR — eskiden
    /// Linter'da da vardı, ambiguity yaratıyordu; tek SSoT'ye indirildi.
    /// </summary>
    public enum Domain
    {
        Any,           // Joker — her domain ile uyumlu (collect_elements, utility)
        Structural,    // Wall, Column, Beam, Floor, Foundation, Rebar
        MEP,           // Pipe, Duct, CableTray, Conduit, Sprinkler, FireAlarm
        Architectural, // Room, Door, Window, Ceiling, Stair
        Report,        // ValidationReport — check/validate çıktısı
        Rows,          // List<Dictionary> — tabular data, show_table/export girişi
        Scalar,        // int/double/string — count, length, cost toplamı
        PozData,       // Poz eşleştirme verisi
        KalipResult,   // Kalıp hesap sonucu
        WbsData,       // WBS hiyerarşi verisi
        IfcData,       // IFC mapping verisi
    }
}
