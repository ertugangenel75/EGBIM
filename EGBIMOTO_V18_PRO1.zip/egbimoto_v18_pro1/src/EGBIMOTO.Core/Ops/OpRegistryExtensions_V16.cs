// ═══════════════════════════════════════════════════════════════════════════════
//  EGBIMOTO V16 — OpRegistry extension (V16 için ek metod)
//
//  McpPreviewHandler OpRegistry.HasOp() kullanıyor.
//  V15.1'de bu metod yoksa buraya ekle, varsa sil.
//
//  KONTROL: OpRegistry.cs'de "HasOp" metodu var mı?
//    Varsa → bu dosyayı projeye ekleme (compile hatası verir).
//    Yoksa → ekle.
// ═══════════════════════════════════════════════════════════════════════════════

using System;

namespace EGBIMOTO.Core.Ops
{
    /// <summary>
    /// V16: McpPreviewHandler için OpRegistry'e HasOp() ekler.
    /// OpRegistry.cs'de zaten HasOp varsa bu partial class gerekmiyor.
    /// </summary>
    public static class OpRegistryV16Extensions
    {
        /// <summary>
        /// Op adının registry'de kayıtlı olup olmadığını döndürür.
        /// V15.1 OpRegistry'de olmayan bir metod — extension olarak eklendi.
        /// </summary>
        public static bool HasOp(this OpRegistry registry, string opName)
        {
            if (string.IsNullOrWhiteSpace(opName)) return false;
            try
            {
                // OpRegistry.Get() veya TryGet() varsa kullan
                // Yoksa: registry'nin internal dictionary'sine reflection ile bak
                // (OpRegistry.cs okuyarak gerçek metod adını kullan)
                var method = registry.GetType().GetMethod("TryGet",
                    System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);

                if (method != null)
                {
                    var pars = new object[] { opName, null! };
                    return (bool)(method.Invoke(registry, pars) ?? false);
                }

                // Alternatif: Get() ve null kontrolü
                var getMethod = registry.GetType().GetMethod("Get",
                    System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance,
                    null,
                    new[] { typeof(string) },
                    null);

                if (getMethod != null)
                {
                    try
                    {
                        var result = getMethod.Invoke(registry, new object[] { opName });
                        return result != null;
                    }
                    catch
                    {
                        return false;
                    }
                }

                return false;
            }
            catch
            {
                return false;
            }
        }
    }
}
