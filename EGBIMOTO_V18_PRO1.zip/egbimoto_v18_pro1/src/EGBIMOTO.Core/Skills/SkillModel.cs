// ═══════════════════════════════════════════════════════════════════════════════
//  EGBIMOTO V17 — SkillModel
//
//  Skill sistemi veri modeli.
//  skill.json dosyası bu model üzerinden deserialize edilir.
//
//  Akış:
//    skill.json  →  SkillDefinition
//    SkillDefinition + params  →  ManifestBuilder.Build()  →  EgManifest JSON
//    EgManifest  →  DagExecutor (mevcut V16 altyapısı)
// ═══════════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using EGBIMOTO.Core.Manifest;

namespace EGBIMOTO.Core.Skills
{
    // ── SkillDefinition ───────────────────────────────────────────────────────

    public sealed class SkillDefinition
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = "";

        [JsonPropertyName("title")]
        public string Title { get; set; } = "";

        [JsonPropertyName("description")]
        public string Description { get; set; } = "";

        [JsonPropertyName("category")]
        public string Category { get; set; } = "";

        [JsonPropertyName("tags")]
        public List<string> Tags { get; set; } = new();

        /// <summary>simple | chain | interactive | write</summary>
        [JsonPropertyName("complexity")]
        public string Complexity { get; set; } = "chain";

        [JsonPropertyName("estimated_duration_s")]
        public int EstimatedDurationS { get; set; }

        [JsonPropertyName("tr_standard")]
        public string? TrStandard { get; set; }

        [JsonPropertyName("params")]
        public List<SkillParam> Params { get; set; } = new();

        /// <summary>EgManifest şablonu — {{param_name}} placeholder'ları içerir.</summary>
        [JsonPropertyName("manifest_template")]
        public JsonElement ManifestTemplate { get; set; }

        // Runtime — dosyadan yüklenince doldurulur
        [JsonIgnore] public string FilePath    { get; set; } = "";
        [JsonIgnore] public string SkillMdPath { get; set; } = "";
    }

    // ── SkillParam ────────────────────────────────────────────────────────────

    public sealed class SkillParam
    {
        [JsonPropertyName("name")]
        public string Name { get; set; } = "";

        /// <summary>string | number | boolean | integer</summary>
        [JsonPropertyName("type")]
        public string Type { get; set; } = "string";

        [JsonPropertyName("required")]
        public bool Required { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; } = "";

        [JsonPropertyName("example")]
        public JsonElement? Example { get; set; }
    }

    // ── SkillListItem ─────────────────────────────────────────────────────────
    // MCP list_skills endpoint'i bu tipi döndürür (hafif — tam manifest yok)

    public sealed class SkillListItem
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = "";

        [JsonPropertyName("title")]
        public string Title { get; set; } = "";

        [JsonPropertyName("description")]
        public string Description { get; set; } = "";

        [JsonPropertyName("category")]
        public string Category { get; set; } = "";

        [JsonPropertyName("complexity")]
        public string Complexity { get; set; } = "";

        [JsonPropertyName("estimated_duration_s")]
        public int EstimatedDurationS { get; set; }

        [JsonPropertyName("tr_standard")]
        public string? TrStandard { get; set; }

        [JsonPropertyName("tags")]
        public List<string> Tags { get; set; } = new();

        [JsonPropertyName("params")]
        public List<SkillParam> Params { get; set; } = new();

        public static SkillListItem From(SkillDefinition d) => new()
        {
            Id                 = d.Id,
            Title              = d.Title,
            Description        = d.Description,
            Category           = d.Category,
            Complexity         = d.Complexity,
            EstimatedDurationS = d.EstimatedDurationS,
            TrStandard         = d.TrStandard,
            Tags               = d.Tags,
            Params             = d.Params,
        };
    }

    // ── SkillRunRequest ───────────────────────────────────────────────────────
    // POST /run-skill gövdesi

    public sealed class SkillRunRequest
    {
        [JsonPropertyName("skill")]
        public string Skill { get; set; } = "";

        /// <summary>{{param_name}} → değer eşleştirmesi.</summary>
        [JsonPropertyName("params")]
        public Dictionary<string, object?> Params { get; set; } = new();
    }

    // ── ManifestBuilder ───────────────────────────────────────────────────────

    public static class SkillManifestBuilder
    {
        private static readonly JsonSerializerOptions _opts = new()
        {
            PropertyNameCaseInsensitive = true,
            WriteIndented              = false,
        };

        /// <summary>
        /// Skill şablonundaki {{param_name}} placeholder'larını kullanıcı
        /// değerleriyle doldurur ve EgManifest JSON string'i döndürür.
        /// </summary>
        public static (string ManifestJson, List<string> Errors) Build(
            SkillDefinition skill,
            Dictionary<string, object?> userParams)
        {
            var errors = new List<string>();

            // Zorunlu parametre kontrolü
            foreach (var p in skill.Params)
            {
                if (p.Required && !userParams.ContainsKey(p.Name))
                    errors.Add($"Zorunlu parametre eksik: '{p.Name}' ({p.Description})");
            }

            if (errors.Count > 0)
                return ("", errors);

            // Template JSON'u string'e al
            string templateJson = skill.ManifestTemplate.GetRawText();

            // {{param_name}} → değer
            foreach (var (key, val) in userParams)
            {
                string placeholder = "\"{{" + key + "}}\"";
                // placeholder = ""{{key}}"" — JSON template formatı
                string replacement = val is null
                    ? "null"
                    : JsonSerializer.Serialize(val);

                templateJson = templateJson.Replace(placeholder, replacement);
            }

            // Kalan doldurulmamış placeholder'ları varsayılan değerle temizle
            // (zorunlu olmayanlar için)
            foreach (var p in skill.Params)
            {
                string placeholder = "\"{{" + p.Name + "}}\"";
                if (templateJson.Contains(placeholder))
                    templateJson = templateJson.Replace(placeholder, "null");
            }

            // Geçerli JSON mi kontrol et
            try
            {
                JsonDocument.Parse(templateJson);
            }
            catch (Exception ex)
            {
                errors.Add($"Manifest JSON üretilemedi: {ex.Message}");
                return ("", errors);
            }

            return (templateJson, errors);
        }
    }
}
