// ═══════════════════════════════════════════════════════════════════════════════
//  EGBIMOTO V17 — SkillRegistry
//
//  manifest_skills/ klasöründen skill.json dosyalarını yükler.
//  MCP araçlarına list ve get ve build hizmeti verir.
//
//  Dizin yapısı:
//    <SkillsRoot>/
//      kalip_maliyet_zinciri/
//        skill.json
//        SKILL.md
//      qa_trbim_csb2026/
//        skill.json
//        SKILL.md
//      ...
//
//  Kullanım:
//    var registry = new SkillRegistry(skillsRootPath);
//    registry.Load();
//    var list    = registry.ListSkills();
//    var skill   = registry.Get("kalip_maliyet_zinciri");
//    var (json,errs) = registry.BuildManifest("kalip_maliyet_zinciri", params);
// ═══════════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace EGBIMOTO.Core.Skills
{
    public sealed class SkillRegistry
    {
        private readonly string _skillsRoot;
        private readonly Dictionary<string, SkillDefinition> _skills =
            new(StringComparer.OrdinalIgnoreCase);

        private static readonly JsonSerializerOptions _opts = new()
        {
            PropertyNameCaseInsensitive = true,
        };

        public int Count => _skills.Count;

        public SkillRegistry(string skillsRoot)
        {
            _skillsRoot = skillsRoot ?? throw new ArgumentNullException(nameof(skillsRoot));
        }

        // ── Yükleme ───────────────────────────────────────────────────────────

        /// <summary>
        /// manifest_skills/ altındaki tüm skill.json dosyalarını yükler.
        /// Hatalı dosyalar loglanır ve atlanır.
        /// </summary>
        public SkillLoadResult Load()
        {
            var result = new SkillLoadResult();
            _skills.Clear();

            if (!Directory.Exists(_skillsRoot))
            {
                result.Errors.Add($"Skills klasörü bulunamadı: {_skillsRoot}");
                return result;
            }

            foreach (var skillDir in Directory.GetDirectories(_skillsRoot))
            {
                var jsonPath = Path.Combine(skillDir, "skill.json");
                var mdPath   = Path.Combine(skillDir, "SKILL.md");

                if (!File.Exists(jsonPath))
                    continue;

                try
                {
                    var json  = File.ReadAllText(jsonPath, System.Text.Encoding.UTF8);
                    var skill = JsonSerializer.Deserialize<SkillDefinition>(json, _opts);

                    if (skill == null)
                    {
                        result.Errors.Add($"Parse null döndü: {jsonPath}");
                        continue;
                    }

                    if (string.IsNullOrWhiteSpace(skill.Id))
                        skill.Id = Path.GetFileName(skillDir);

                    skill.FilePath    = jsonPath;
                    skill.SkillMdPath = File.Exists(mdPath) ? mdPath : "";

                    _skills[skill.Id] = skill;
                    result.Loaded.Add(skill.Id);
                }
                catch (Exception ex)
                {
                    result.Errors.Add($"Yüklenemedi {jsonPath}: {ex.Message}");
                }
            }

            return result;
        }

        // ── Sorgulama ─────────────────────────────────────────────────────────

        public bool Has(string skillId) =>
            _skills.ContainsKey(skillId);

        public SkillDefinition? Get(string skillId) =>
            _skills.TryGetValue(skillId, out var s) ? s : null;

        /// <summary>
        /// Tüm skill'lerin hafif özetini döndürür (manifest_template yok).
        /// MCP list_skills için kullanılır.
        /// </summary>
        public List<SkillListItem> ListSkills(string? category = null, string? tag = null)
        {
            IEnumerable<SkillDefinition> skills = _skills.Values;

            if (!string.IsNullOrWhiteSpace(category))
                skills = skills.Where(s =>
                    s.Category.Equals(category, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(tag))
                skills = skills.Where(s =>
                    s.Tags.Any(t => t.Equals(tag, StringComparison.OrdinalIgnoreCase)));

            return skills
                .OrderBy(s => s.Category)
                .ThenBy(s => s.Id)
                .Select(SkillListItem.From)
                .ToList();
        }

        /// <summary>Kategorileri ve skill sayılarını döndürür.</summary>
        public Dictionary<string, int> Categories() =>
            _skills.Values
                .GroupBy(s => s.Category)
                .ToDictionary(g => g.Key, g => g.Count());

        /// <summary>SKILL.md içeriğini döndürür (LLM okumak için).</summary>
        public string? GetSkillMd(string skillId)
        {
            var skill = Get(skillId);
            if (skill == null || string.IsNullOrEmpty(skill.SkillMdPath)) return null;
            try { return File.ReadAllText(skill.SkillMdPath, System.Text.Encoding.UTF8); }
            catch { return null; }
        }

        // ── Manifest Üretimi ──────────────────────────────────────────────────

        /// <summary>
        /// Skill şablonundan manifest JSON üretir.
        /// Başarılıysa (json, []) döner. Hatalıysa ("", [hatalar]) döner.
        /// </summary>
        public (string ManifestJson, List<string> Errors) BuildManifest(
            string skillId,
            Dictionary<string, object?> userParams)
        {
            var skill = Get(skillId);
            if (skill == null)
                return ("", new List<string> { $"Skill bulunamadı: '{skillId}'" });

            return SkillManifestBuilder.Build(skill, userParams);
        }
    }

    // ── SkillLoadResult ───────────────────────────────────────────────────────

    public sealed class SkillLoadResult
    {
        public List<string> Loaded { get; } = new();
        public List<string> Errors { get; } = new();
        public bool HasErrors => Errors.Count > 0;
        public override string ToString() =>
            $"{Loaded.Count} skill yüklendi" +
            (HasErrors ? $", {Errors.Count} hata" : "");
    }
}
