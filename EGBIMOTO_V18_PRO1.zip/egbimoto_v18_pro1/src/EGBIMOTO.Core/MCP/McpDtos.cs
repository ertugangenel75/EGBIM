// ═══════════════════════════════════════════════════════════════════════════════
//  EGBIMOTO V16 — MCP DTO'ları  (EGBIMOTO.Core.MCP)
//
//  Tüm yeni MCP araçlarının istek/yanıt veri modelleri.
//  Revit API'ye bağımlı değil → Core katmanında yaşar.
//
//  Araç Haritası:
//    Tier 1 (V16.0) : PreviewManifestResult, DocumentInfoDto,  SelectionSnapshotDto
//    Tier 2 (V16.1) : LevelDto, RoomDto, FamilyDto, ParameterSearchResultDto
//    Tier 3 (V16.2) : UndoResultDto, FailureExplanationDto, GeneratedManifestDto
// ═══════════════════════════════════════════════════════════════════════════════

using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace EGBIMOTO.Core.MCP
{
    // ── Tier 1 ──────────────────────────────────────────────────────────────────

    /// <summary>
    /// POST /preview yanıtı.
    /// Manifest çalıştırılmadan Revit modelinde kaç eleman etkileneceğini raporlar.
    /// </summary>
    public sealed class PreviewManifestResult
    {
        [JsonPropertyName("feasible")]
        public bool Feasible { get; set; } = true;

        [JsonPropertyName("title")]
        public string Title { get; set; } = "";

        [JsonPropertyName("step_count")]
        public int StepCount { get; set; }

        /// <summary>Her adım için etki tahmini.</summary>
        [JsonPropertyName("steps")]
        public List<PreviewStepResult> Steps { get; set; } = new();

        /// <summary>Toplam etkilenecek eleman sayısı (yazma adımları).</summary>
        [JsonPropertyName("total_elements_affected")]
        public int TotalElementsAffected { get; set; }

        /// <summary>Toplam oluşturulacak eleman sayısı.</summary>
        [JsonPropertyName("total_elements_created")]
        public int TotalElementsCreated { get; set; }

        /// <summary>Toplam güncellenecek parametre sayısı.</summary>
        [JsonPropertyName("total_parameters_updated")]
        public int TotalParametersUpdated { get; set; }

        /// <summary>Toplam okunacak eleman sayısı (okuma adımları).</summary>
        [JsonPropertyName("total_elements_read")]
        public int TotalElementsRead { get; set; }

        /// <summary>Tahmini süre (ms) — op bazlı heuristik.</summary>
        [JsonPropertyName("estimated_ms")]
        public long EstimatedMs { get; set; }

        /// <summary>Kullanıcıya gösterilecek uyarılar.</summary>
        [JsonPropertyName("warnings")]
        public List<string> Warnings { get; set; } = new();

        /// <summary>Engel olan hatalar (Feasible=false ise dolu).</summary>
        [JsonPropertyName("errors")]
        public List<string> Errors { get; set; } = new();

        /// <summary>İnsan okunur özet (onay penceresi için).</summary>
        [JsonPropertyName("summary")]
        public string Summary { get; set; } = "";
    }

    public sealed class PreviewStepResult
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = "";

        [JsonPropertyName("op")]
        public string Op { get; set; } = "";

        [JsonPropertyName("op_domain")]
        public string OpDomain { get; set; } = "";  // Read / Write / Export / Gate

        [JsonPropertyName("element_count")]
        public int ElementCount { get; set; }

        [JsonPropertyName("elements_created")]
        public int ElementsCreated { get; set; }

        [JsonPropertyName("parameters_updated")]
        public int ParametersUpdated { get; set; }

        [JsonPropertyName("estimated_ms")]
        public long EstimatedMs { get; set; }

        [JsonPropertyName("category_breakdown")]
        public Dictionary<string, int> CategoryBreakdown { get; set; } = new();

        [JsonPropertyName("skipped")]
        public bool Skipped { get; set; }

        [JsonPropertyName("skip_reason")]
        public string? SkipReason { get; set; }

        [JsonPropertyName("warning")]
        public string? Warning { get; set; }
    }

    // ────────────────────────────────────────────────────────────────────────────

    /// <summary>GET /document yanıtı — aktif Revit dokümanı hakkında tam bağlam.</summary>
    public sealed class DocumentInfoDto
    {
        [JsonPropertyName("title")]
        public string Title { get; set; } = "";

        [JsonPropertyName("path")]
        public string Path { get; set; } = "";

        [JsonPropertyName("is_workshared")]
        public bool IsWorkshared { get; set; }

        [JsonPropertyName("is_family")]
        public bool IsFamily { get; set; }

        [JsonPropertyName("project_number")]
        public string ProjectNumber { get; set; } = "";

        [JsonPropertyName("project_name")]
        public string ProjectName { get; set; } = "";

        [JsonPropertyName("client_name")]
        public string ClientName { get; set; } = "";

        [JsonPropertyName("building_name")]
        public string BuildingName { get; set; } = "";

        [JsonPropertyName("author")]
        public string Author { get; set; } = "";

        [JsonPropertyName("organization_name")]
        public string OrganizationName { get; set; } = "";

        [JsonPropertyName("length_unit")]
        public string LengthUnit { get; set; } = "";  // "Millimeters" | "Meters" | ...

        [JsonPropertyName("area_unit")]
        public string AreaUnit { get; set; } = "";

        [JsonPropertyName("phases")]
        public List<string> Phases { get; set; } = new();

        [JsonPropertyName("active_phase")]
        public string ActivePhase { get; set; } = "";

        [JsonPropertyName("level_count")]
        public int LevelCount { get; set; }

        [JsonPropertyName("room_count")]
        public int RoomCount { get; set; }

        [JsonPropertyName("element_count")]
        public int ElementCount { get; set; }

        [JsonPropertyName("revit_version")]
        public string RevitVersion { get; set; } = "";

        [JsonPropertyName("last_save")]
        public string LastSave { get; set; } = "";

        [JsonPropertyName("warnings_count")]
        public int WarningsCount { get; set; }
    }

    // ────────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// GET /selection yanıtı — şu an Revit'te seçili elemanlar.
    /// </summary>
    public sealed class SelectionSnapshotDto
    {
        [JsonPropertyName("count")]
        public int Count { get; set; }

        [JsonPropertyName("element_ids")]
        public List<long> ElementIds { get; set; } = new();

        [JsonPropertyName("summary")]
        public List<SelectionCategoryGroup> Summary { get; set; } = new();

        [JsonPropertyName("empty")]
        public bool Empty => Count == 0;
    }

    public sealed class SelectionCategoryGroup
    {
        [JsonPropertyName("category")]
        public string Category { get; set; } = "";

        [JsonPropertyName("count")]
        public int Count { get; set; }

        [JsonPropertyName("element_ids")]
        public List<long> ElementIds { get; set; } = new();
    }

    // ── Tier 2 ──────────────────────────────────────────────────────────────────

    /// <summary>GET /levels — tek kat bilgisi.</summary>
    public sealed class LevelDto
    {
        [JsonPropertyName("id")]
        public long Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; } = "";

        [JsonPropertyName("elevation_mm")]
        public double ElevationMm { get; set; }

        [JsonPropertyName("is_building_story")]
        public bool IsBuildingStory { get; set; }
    }

    /// <summary>GET /rooms — tek oda bilgisi.</summary>
    public sealed class RoomDto
    {
        [JsonPropertyName("id")]
        public long Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; } = "";

        [JsonPropertyName("number")]
        public string Number { get; set; } = "";

        [JsonPropertyName("level_name")]
        public string LevelName { get; set; } = "";

        [JsonPropertyName("area_m2")]
        public double AreaM2 { get; set; }

        [JsonPropertyName("phase")]
        public string Phase { get; set; } = "";

        [JsonPropertyName("department")]
        public string Department { get; set; } = "";
    }

    /// <summary>GET /families — tek family bilgisi.</summary>
    public sealed class FamilyDto
    {
        [JsonPropertyName("id")]
        public long Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; } = "";

        [JsonPropertyName("category")]
        public string Category { get; set; } = "";

        [JsonPropertyName("type_count")]
        public int TypeCount { get; set; }

        [JsonPropertyName("is_in_place")]
        public bool IsInPlace { get; set; }

        [JsonPropertyName("source_path")]
        public string SourcePath { get; set; } = "";

        [JsonPropertyName("types")]
        public List<FamilyTypeDto> Types { get; set; } = new();
    }

    public sealed class FamilyTypeDto
    {
        [JsonPropertyName("id")]
        public long Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; } = "";

        [JsonPropertyName("instance_count")]
        public int InstanceCount { get; set; }
    }

    /// <summary>GET /parameters?q=... — parametre arama sonucu.</summary>
    public sealed class ParameterSearchResultDto
    {
        [JsonPropertyName("query")]
        public string Query { get; set; } = "";

        [JsonPropertyName("total_found")]
        public int TotalFound { get; set; }

        [JsonPropertyName("results")]
        public List<ParameterInfoDto> Results { get; set; } = new();
    }

    public sealed class ParameterInfoDto
    {
        [JsonPropertyName("name")]
        public string Name { get; set; } = "";

        [JsonPropertyName("guid")]
        public string Guid { get; set; } = "";

        [JsonPropertyName("type")]
        public string Type { get; set; } = "";   // "SharedParameter" | "ProjectParameter" | "BuiltIn"

        [JsonPropertyName("data_type")]
        public string DataType { get; set; } = "";  // "Text" | "Length" | "Area" | ...

        [JsonPropertyName("group")]
        public string Group { get; set; } = "";

        [JsonPropertyName("categories")]
        public List<string> Categories { get; set; } = new();

        [JsonPropertyName("is_instance")]
        public bool IsInstance { get; set; }
    }

    // ── Tier 3 ──────────────────────────────────────────────────────────────────

    /// <summary>POST /undo yanıtı.</summary>
    public sealed class UndoResultDto
    {
        [JsonPropertyName("success")]
        public bool Success { get; set; }

        [JsonPropertyName("message")]
        public string Message { get; set; } = "";

        [JsonPropertyName("undo_name")]
        public string UndoName { get; set; } = "";  // Revit'in Undo stack'indeki isim
    }

    /// <summary>POST /explain — hata açıklama yanıtı.</summary>
    public sealed class FailureExplanationDto
    {
        [JsonPropertyName("original_error")]
        public string OriginalError { get; set; } = "";

        [JsonPropertyName("failed_step")]
        public string FailedStep { get; set; } = "";

        [JsonPropertyName("failed_op")]
        public string FailedOp { get; set; } = "";

        [JsonPropertyName("category")]
        public string Category { get; set; } = "";  // "TransactionConflict" | "EmptyCollection" | "InvalidInput" | "RevitApi" | "Unknown"

        [JsonPropertyName("likely_cause")]
        public string LikelyCause { get; set; } = "";

        [JsonPropertyName("suggestions")]
        public List<string> Suggestions { get; set; } = new();

        [JsonPropertyName("manifest_fix_hint")]
        public string? ManifestFixHint { get; set; }  // transaction_policy değiştir vb.
    }

    /// <summary>POST /generate yanıtı — pattern'den üretilmiş manifest.</summary>
    public sealed class GeneratedManifestDto
    {
        [JsonPropertyName("pattern_name")]
        public string PatternName { get; set; } = "";

        [JsonPropertyName("manifest")]
        public object Manifest { get; set; } = new();  // ham EgManifest JSON

        [JsonPropertyName("description")]
        public string Description { get; set; } = "";

        [JsonPropertyName("required_inputs")]
        public List<string> RequiredInputs { get; set; } = new();
    }
}
