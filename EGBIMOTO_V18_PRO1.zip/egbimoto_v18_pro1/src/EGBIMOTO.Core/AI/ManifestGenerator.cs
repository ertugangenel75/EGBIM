using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using EGBIMOTO.Core.Manifest;

namespace EGBIMOTO.Core.AI
{
    public sealed class ManifestGenerator
    {
        private const string ApiUrl    = "https://api.anthropic.com/v1/messages";
        private const string Model     = "claude-sonnet-4-20250514";
        private const int    MaxTokens = 4096;
        private const int    MaxRetry  = 2;

        private readonly string            _apiKey;
        private readonly string            _contractsPath;
        private readonly ManifestValidator _validator;
        private static readonly HttpClient _http = new(new HttpClientHandler
        {
            UseProxy = true,
            ServerCertificateCustomValidationCallback = null,
        })
        {
            Timeout = TimeSpan.FromSeconds(60)
        };

        public ManifestGenerator(string apiKey, string contractsPath)
        {
            _apiKey        = apiKey;
            _contractsPath = contractsPath;
            _validator     = new ManifestValidator(contractsPath);
        }

        public async Task<ManifestGenerateResult> GenerateAsync(string userDescription)
        {
            var opNames      = LoadOpNames();
            var systemPrompt = BuildSystemPrompt(opNames);
            var userMsg      = "Şu isteği manifest JSON olarak yaz:\n\n" + userDescription;

            string rawJson = "";
            ValidationResult? lastVr = null;

            for (int attempt = 0; attempt <= MaxRetry; attempt++)
            {
                try
                {
                    var msgs = attempt == 0
                        ? new object[] { new { role = "user", content = userMsg } }
                        : new object[]
                          {
                              new { role = "user",      content = userMsg },
                              new { role = "assistant", content = rawJson },
                              new { role = "user",      content = ManifestValidator.BuildFixPrompt(rawJson, lastVr!) }
                          };
                    rawJson = await CallAnthropicAsync(systemPrompt, msgs).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    return new ManifestGenerateResult { Success = false, ErrorMessage = "API (" + (attempt+1) + "): " + ex.Message };
                }

                lastVr = _validator.Validate(rawJson);
                if (lastVr.IsValid)
                    return new ManifestGenerateResult
                    {
                        Success      = true,
                        Manifest     = lastVr.Manifest,
                        RawJson      = FormatJson(rawJson),
                        Warnings     = lastVr.Warnings,
                        AttemptCount = attempt + 1
                    };

                if (attempt == MaxRetry) break;
            }

            return new ManifestGenerateResult
            {
                Success          = false,
                ErrorMessage     = (MaxRetry+1) + " denemede doğrulama başarısız:\n" + lastVr?.ErrorSummary,
                RawJson          = rawJson,
                ValidationErrors = lastVr?.Errors.Select(e => "[" + e.JsonPath + "] " + e.Code + ": " + e.Message).ToList()
            };
        }

        private string BuildSystemPrompt(List<string> opNames)
        {
            var catalogText = BuildDomainCatalog(opNames);

            var sb = new StringBuilder();
            sb.AppendLine("Sen EGBIMOTO BIM otomasyon platformu için manifest JSON yazan asistansın.");
            sb.AppendLine();
            sb.AppendLine("## KRİTİK KURAL");
            sb.AppendLine("Sadece aşağıdaki katalogdaki op adlarını kullan. ASLA başka op adı uydurma.");
            sb.AppendLine();
            sb.AppendLine("## DOMAIN TİP SİSTEMİ — BAĞLANTI KURALLARI");
            sb.AppendLine("Her op: domain_in->domain_out formatında gösterilir.");
            sb.AppendLine("'from:' ile bağladığın adımın domain_out'u, sonraki adımın domain_in'iyle UYUMLU olmalı.");
            sb.AppendLine("Uyumluluk: aynı domain VEYA domain_in=Any.");
            sb.AppendLine();
            sb.AppendLine("Temel zincirler:");
            sb.AppendLine("  None/Any    -> collect_* -> Elements | MEP | Structural | Architectural | KalipResult");
            sb.AppendLine("  Elements    -> [check/validate/transform] -> Rows | Report | ValidationReport");
            sb.AppendLine("  KalipResult -> poz_match_keynote_aware -> PozData -> calc_cost -> Rows");
            sb.AppendLine("  ValidationReport/Report -> merge_validation_reports -> validation_to_rows -> Rows");
            sb.AppendLine("  Rows        -> [filtre/export] -> Rows | Scalar");
            sb.AppendLine();
            sb.AppendLine("DOGRULANMIS ZINCIR (gercek modelde test edildi, transaction_policy=none):");
            sb.AppendLine("  kalip_all -> poz_match_keynote_aware -> calc_cost -> export_xlsx");
            sb.AppendLine("  NOT: kalip_all input listesi yoksayar, kendisi toplar.");
            sb.AppendLine();
            sb.AppendLine("## MANIFEST SEMASI");
            sb.AppendLine("{");
            sb.AppendLine("  \"title\": \"Turkce baslik\",");
            sb.AppendLine("  \"description\": \"Aciklama\",");
            sb.AppendLine("  \"category\": \"kategori\",");
            sb.AppendLine("  \"version\": \"1.0.0\",");
            sb.AppendLine("  \"transaction_policy\": \"none\",");
            sb.AppendLine("  \"pre_checks\": [{\"type\": \"MODEL_HAS_ELEMENTS\", \"categories\": [\"OST_Walls\"], \"min_count\": 1, \"on_fail\": \"ABORT\", \"message\": \"Eleman bulunamadi\"}],");
            sb.AppendLine("  \"steps\": [");
            sb.AppendLine("    {\"id\": \"s1\", \"op\": \"op_adi\"},");
            sb.AppendLine("    {\"id\": \"s2\", \"op\": \"op_adi\", \"from\": \"s1\"},");
            sb.AppendLine("    {\"id\": \"s3\", \"op\": \"export_xlsx\", \"from\": \"s2\", \"required\": false, \"params\": {\"sheet_name\": \"Rapor\"}}");
            sb.AppendLine("  ]");
            sb.AppendLine("}");
            sb.AppendLine();
            sb.AppendLine("## 8 PATTERN");
            sb.AppendLine("QA_PATTERN:     collect_* -> param_*_check -> merge_validation_reports -> validation_to_rows -> export_xlsx");
            sb.AppendLine("BOQ_PATTERN:    kalip_all -> poz_match_keynote_aware -> calc_cost -> export_xlsx [transaction_policy:none]");
            sb.AppendLine("MEP_PATTERN:    collect_ducts|collect_pipes -> mep_by_system -> mep_total_length -> export_xlsx");
            sb.AppendLine("CALC_PATTERN:   calc_lap_length|calc_anchorage_length (params ile) -> show_result");
            sb.AppendLine("ROOM_PATTERN:   collect_rooms -> check_unplaced_rooms + check_overlapping_rooms -> merge_validation_reports");
            sb.AppendLine("RENAME_PATTERN: collect_* -> rename_preview -> show_table -> rename_apply [transaction_policy:atomic]");
            sb.AppendLine("IFC_PATTERN:    load_ifc_mapping -> collect_* -> validate_required_params -> map_to_ifc -> ifc_export");
            sb.AppendLine("SCRIPT_PATTERN: collect_* -> run_csharp_script(script_path) -> show_table|export_xlsx");
            sb.AppendLine();
            sb.AppendLine("## 9 KURAL");
            sb.AppendLine("1. Sadece katalogdaki op adlari — uydurma yok.");
            sb.AppendLine("2. from/from_many sadece onceki step id'ye baglanir.");
            sb.AppendLine("3. Her manifestte pre_checks olmali.");
            sb.AppendLine("4. Eleman yazan op'lardan once required:false veya preview adimi.");
            sb.AppendLine("5. Export adimlari required:false.");
            sb.AppendLine("6. Baslik ve rapor adlari Turkce.");
            sb.AppendLine("7. SADECE gecerli JSON dondur — markdown blok, on soz yazma.");
            sb.AppendLine("8. Kalip/poz/maliyet zincirinde transaction_policy='none' kullan.");
            sb.AppendLine("9. domain_in=None olan op'lar from: almaz (kendi baslaticisidir).");
            sb.AppendLine();
            sb.AppendLine("## OP KATALOGU (" + opNames.Count + " adet) [format: op_adi [kategori] domain_in->domain_out: aciklama]");
            sb.Append(catalogText);

            return sb.ToString();
        }

        private string BuildDomainCatalog(List<string> opNames)
        {
            var lines = new StringBuilder();
            try
            {
                if (!File.Exists(_contractsPath)) return string.Join(", ", opNames);
                using var doc = JsonDocument.Parse(File.ReadAllText(_contractsPath, Encoding.UTF8));
                foreach (var prop in doc.RootElement.EnumerateObject().OrderBy(p => p.Name))
                {
                    if (!opNames.Contains(prop.Name)) continue;
                    var v        = prop.Value;
                    var cat      = v.TryGetProperty("category",    out var c)  ? c.GetString()  ?? "?"   : "?";
                    var dIn      = v.TryGetProperty("domain_in",   out var di) ? di.GetString() ?? "Any" : "Any";
                    var dOut     = v.TryGetProperty("domain_out",  out var d0) ? d0.GetString() ?? "Any" : "Any";
                    var descFull = v.TryGetProperty("description", out var ds) ? ds.GetString() ?? ""    : "";
                    var desc     = descFull.Length > 80 ? descFull[..80] : descFull;

                    var reqParams = new List<string>();
                    if (v.TryGetProperty("params", out var pArr))
                        foreach (var p in pArr.EnumerateArray())
                            if (p.TryGetProperty("presence", out var pr) && pr.GetString() == "required"
                             && p.TryGetProperty("key", out var pk))
                                reqParams.Add(pk.GetString() ?? "");

                    var paramHint = reqParams.Count > 0 ? " REQ:" + string.Join(",", reqParams) : "";
                    lines.AppendLine(prop.Name + " [" + cat + "] " + dIn + "->" + dOut + paramHint + ": " + desc);
                }
            }
            catch { return string.Join(", ", opNames); }
            return lines.ToString();
        }

        private async Task<string> CallAnthropicAsync(string systemPrompt, object[] messages)
        {
            var body = JsonSerializer.Serialize(new { model = Model, max_tokens = MaxTokens, system = systemPrompt, messages });
            using var req = new HttpRequestMessage(HttpMethod.Post, ApiUrl);
            req.Headers.Add("x-api-key", _apiKey);
            req.Headers.Add("anthropic-version", "2023-06-01");
            req.Content = new StringContent(body, Encoding.UTF8, "application/json");

            HttpResponseMessage resp;
            try
            {
                resp = await _http.SendAsync(req).ConfigureAwait(false);
            }
            catch (HttpRequestException ex)
            {
                throw new InvalidOperationException(
                    "Anthropic API baglantisi kurulamadi. Internet baglantisini ve firewall ayarlarini kontrol edin.\n" +
                    "Detay: " + ex.Message, ex);
            }
            catch (TaskCanceledException)
            {
                throw new InvalidOperationException("Anthropic API istegi zaman asimina ugradi (60 saniye). Tekrar deneyin.");
            }

            if (!resp.IsSuccessStatusCode)
            {
                var errBody = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);
                var hint = resp.StatusCode switch
                {
                    System.Net.HttpStatusCode.Unauthorized    => "API anahtari gecersiz veya eksik.",
                    System.Net.HttpStatusCode.TooManyRequests => "Rate limit asildi. Birkas saniye bekleyip tekrar deneyin.",
                    System.Net.HttpStatusCode.BadRequest      => "Istek formati hatali.",
                    _ => "HTTP " + (int)resp.StatusCode
                };
                throw new InvalidOperationException(hint + "\nYanit: " + errBody[..Math.Min(200, errBody.Length)]);
            }

            var respJson = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);
            using var doc = JsonDocument.Parse(respJson);
            var text = doc.RootElement.GetProperty("content")[0].GetProperty("text").GetString() ?? "";
            return CleanJson(text);
        }

        private List<string> LoadOpNames()
        {
            try
            {
                if (!File.Exists(_contractsPath)) return new List<string>();
                using var doc = JsonDocument.Parse(File.ReadAllText(_contractsPath, Encoding.UTF8));
                return doc.RootElement.EnumerateObject().Select(p => p.Name).OrderBy(n => n).ToList();
            }
            catch { return new List<string>(); }
        }

        private static string CleanJson(string raw)
        {
            var s = raw.Trim();
            if (s.StartsWith("```json", StringComparison.OrdinalIgnoreCase)) s = s[7..];
            else if (s.StartsWith("```")) s = s[3..];
            if (s.EndsWith("```")) s = s[..^3];
            return s.Trim();
        }

        private static string FormatJson(string json)
        {
            try { return JsonSerializer.Serialize(JsonSerializer.Deserialize<object>(json), new JsonSerializerOptions { WriteIndented = true }); }
            catch { return json; }
        }
    }

    public sealed class ManifestGenerateResult
    {
        public bool          Success          { get; init; }
        public EgManifest?   Manifest         { get; init; }
        public string?       RawJson          { get; init; }
        public string?       ErrorMessage     { get; init; }
        public List<string>? Warnings         { get; init; }
        public List<string>? ValidationErrors { get; init; }
        public int           AttemptCount     { get; init; } = 1;
    }
}
