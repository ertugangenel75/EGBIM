# EGBIMOTO V17 — Changelog

## Özet
V17, "Skill-Driven Manifest Platform" — LLM artık manifest yazmak zorunda değil.
Skill seçer, parametrelerini verir, manifest otomatik üretilir.

## Yeni Dosyalar

| Dosya | Açıklama |
|---|---|
| `src/EGBIMOTO.Core/Skills/SkillModel.cs` | SkillDefinition, SkillParam, ManifestBuilder |
| `src/EGBIMOTO.Core/Skills/SkillRegistry.cs` | Skill loader, BuildManifest |
| `src/EGBIMOTO.Addin/Server/McpSkillHandler.cs` | /skills, /run-skill handler |
| `manifest_skills/*/skill.json` | 15 skill tanımı |
| `manifest_skills/*/SKILL.md` | 15 skill rehberi (LLM için) |

## Değiştirilen Dosyalar

| Dosya | Değişiklik |
|---|---|
| `EgbimotoMcpServer.cs` | 3 endpoint eklendi, version 3.0 |
| `McpServerManager.cs` | skillsRoot + SkillRegistry inject |
| `McpServerToggleCommand.cs` | skillsRoot parametresi |
| `mcp_bridge/egbimoto_mcp_bridge.py` | 3 araç eklendi (16 toplam) |

## Yeni MCP Araçları

### egbimoto_list_skills
Skill kütüphanesini listeler (~2K token). list_ops'tan (15K token) çok daha hafif.
Filtreler: category, tag.

### egbimoto_get_skill
Tek skill detayı: parametreler, SKILL.md rehberi, manifest şablonu.

### egbimoto_run_skill
```json
{ "skill": "kalip_maliyet_zinciri", "params": { "output_path": "C:\\..." }, "preview_only": true }
```
preview_only=true → etki raporu (kullanıcıya göster)
preview_only=false → gerçekten çalıştır

## V17 Önerilen Akış
```
1. egbimoto_list_skills()
   → "kalip_maliyet_zinciri" var, parametreler: output_path

2. egbimoto_run_skill(skill="kalip_maliyet_zinciri",
                      params={"output_path":"C:\\kalip.xlsx"},
                      preview_only=true)
   → "42 duvar, 13 döşeme, 8 kolon okunacak. Tahmini: 28s"

3. Kullanıcıya göster → "Evet çalıştır"

4. egbimoto_run_skill(skill="kalip_maliyet_zinciri",
                      params={"output_path":"C:\\kalip.xlsx"},
                      preview_only=false)
   → Çalışır, xlsx üretilir
```

## 15 Skill Listesi

| ID | Kategori | Açıklama |
|---|---|---|
| kalip_maliyet_zinciri | Maliyet | Tüm model kalıp → poz → xlsx |
| kalip_kat_bazli | Maliyet | Tek kat kalıp raporu |
| maliyet_secili_elemanlar | Maliyet | Seçili eleman maliyeti |
| qa_trbim_csb2026 | QA | TR BIM / ÇŞB 2026 kontrolü |
| qa_bos_param_tespiti | QA | Boş parametre tespiti |
| yapisal_ts500_dogrulama | Yapısal | TS500 / TBDY 2018 doğrulama |
| donati_agirlik_raporu | Yapısal | TS500 donatı ağırlık dökümü |
| mep_cakisma_tespiti | MEP | Hard clash tespiti |
| mep_aciklik_kontrolu | MEP | MEP-duvar kesişim tespiti |
| oda_analizi_raporu | Oda | Alan dökümü + kapı ilişkisi |
| oda_kaplama_atama | Oda | Kaplama tipi otomatik atama |
| ifc_export_csb2026 | Export | ÇŞB 2026 uyumlu IFC |
| cephe_u_deger_kontrolu | Cephe | TS 825 U-değer kontrolü |
| elektrik_gerilim_dususu | MEP-Elektrik | IEC 60364 gerilim düşümü |
| 4d_program_atama | 4D/5D | 4D program parametresi atama |

## Entegrasyon Notu
`McpServerManager.Start()` artık `skillsRoot` parametresi alıyor:
```csharp
var skillsRoot = Path.Combine(addinDir, "manifest_skills");
McpServerManager.Instance.Start(registry, contractsPath, skillsRoot, port);
```
