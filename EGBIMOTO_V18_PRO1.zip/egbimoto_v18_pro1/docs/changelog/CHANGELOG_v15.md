# EGBIMOTO v15.0.0

## Derleme / Uyumluluk Düzeltmeleri (Revit 2025/2026)

v14'te üç dosyada `ElementId.IntegerValue` / `Category.Id.IntegerValue`
doğrudan çağrılıyordu. Bu property Revit 2025'te `[Obsolete]`, 2026 API'sinde
kaldırılmıştır; `-p:RevitVersion=2025` veya `2026` ile derlemede CS hatası
üretiyordu. Tümü mevcut `Host.Rv` sürüm-adaptörüne yönlendirildi
(`Rv.GetCategoryId(element)` → `#if REVIT2024 .IntegerValue #else (int).Value`).

Düzeltilen dosyalar:
- `Revit/SelectionPickerService.cs` (CategoryFilter.AllowElement)
- `UI/Inspector/ElementInspectorPane.xaml.cs` (BuildParamHealth, BuildRelatedManifests)

Not: `RevitVersionAdapter.cs` içindeki `.IntegerValue` kullanımları zaten
`#if REVIT2024` korumalıdır ve kasıtlıdır — değiştirilmedi.

## Doğrulama (statik analiz)
- 140 C# dosyası: brace/paren/bracket dengesi — TAM.
- 8 XAML: XML geçerli; x:Class ↔ code-behind ve event handler bağlamaları — TAM.
- 360 JSON (manifest + contracts + categories) — TÜMÜ geçerli.
- Katman ayrımı: EGBIMOTO.Core içinde gerçek `using Autodesk.Revit` YOK — korundu.

## Sürüm
14.0.0 → 15.0.0 (Addin.csproj + AssemblyVersion 2024/2025/2026).
