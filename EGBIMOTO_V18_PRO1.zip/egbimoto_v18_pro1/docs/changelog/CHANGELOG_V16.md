# EGBIMOTO V16 — Değişiklik Günlüğü & Entegrasyon Rehberi

## Özet

V16, MCP katmanını 3 araçtan 14 araca çıkarır. Temel hedef: LLM'in **kör çalışmasını** sona erdirmek.

---

## Yeni Dosyalar

| Dosya | Açıklama |
|---|---|
| `EGBIMOTO.Core/MCP/McpDtos.cs` | Tüm araçların istek/yanıt DTO'ları |
| `EGBIMOTO.Addin/Server/McpContextHandlers.cs` | Bağlam araçlarının Revit implementasyonu |
| `EGBIMOTO.Addin/Server/McpPreviewHandler.cs` | `preview_manifest` dry-run motoru |
| `EGBIMOTO.Addin/Server/EgbimotoMcpServer_V16.cs` | Tam server (V15.1'in yerini alır) |
| `EGBIMOTO.Addin/Server/McpServerManager_V16.cs` | Güncellenmiş yaşam döngüsü yöneticisi |
| `EGBIMOTO.Addin/Server/McpToolDescriptors_V16.cs` | Python MCP bridge araç tanımları |
| `EGBIMOTO.Core/Ops/OpRegistryExtensions_V16.cs` | `HasOp()` extension (gerekirse) |

---

## Entegrasyon Adımları

### 1. Dosya Değişimi

```
# V15.1 dosyalarını SAKLA (backup)
EgbimotoMcpServer.cs  → EgbimotoMcpServer_V15.1_backup.cs
McpServerManager.cs   → McpServerManager_V15.1_backup.cs

# V16 dosyalarını yerleştir
EgbimotoMcpServer_V16.cs  → EgbimotoMcpServer.cs
McpServerManager_V16.cs   → McpServerManager.cs
```

### 2. EGBIMOTO.Core.csproj Güncelleme

```xml
<ItemGroup>
  <!-- Yeni klasör -->
  <Compile Include="MCP\McpDtos.cs" />
  <!-- Extension (OpRegistry.HasOp yoksa) -->
  <Compile Include="Ops\OpRegistryExtensions_V16.cs" />
</ItemGroup>
```

### 3. EGBIMOTO.Addin.csproj Güncelleme

```xml
<ItemGroup>
  <Compile Include="Server\McpContextHandlers.cs" />
  <Compile Include="Server\McpPreviewHandler.cs" />
  <!-- McpToolDescriptors_V16.cs → derlenmez, referans belgesidir -->
</ItemGroup>
```

### 4. McpToolDescriptors_V16.cs

Bu dosya Python bridge referansı içerir — `.csproj`'a **ekleme**.
Python MCP köprüsüne kopyala: `mcp_bridge/mcp_tools_v16.py`

### 5. OpRegistry.HasOp Kontrolü

`OpRegistry.cs`'de `HasOp` veya eşdeğeri varsa `OpRegistryExtensions_V16.cs`'i **silip**
`McpPreviewHandler.cs`'deki `_registry.HasOp(step.Op)` satırını güncelle:

```csharp
// Eğer registry'de TryGet varsa:
if (!_registry.TryGet(step.Op, out _) && !IsBuiltInGate(step.Op))

// Eğer registry'de Contains varsa:
if (!_registry.Contains(step.Op) && !IsBuiltInGate(step.Op))
```

---

## Araç Akışları

### preview_manifest akışı (YENİ — kritik)

```
Claude: manifest oluşturur
   ↓
egbimoto_preview_manifest(manifest)
   ↓
EGBIMOTO: dry-run → etki raporu
   ↓
Claude → kullanıcıya gösterir:
  "42 duvar okunacak, 8 parametre güncellenecek, tahmini 2.3s"
   ↓
Kullanıcı: "Evet, çalıştır"
   ↓
egbimoto_run_manifest(manifest)
```

### Bağlam araçları akışı (YENİ)

```
Kullanıcı: "Seçili elemanların kalıp maliyetini hesapla"
   ↓
egbimoto_get_selection()  → 15 duvar seçili, IDs: [...]
   ↓
egbimoto_get_document()   → aktif phase: "İnşaat"
   ↓
Claude: manifest oluşturur (gerçek ID'lerle)
   ↓
egbimoto_preview_manifest → "15 duvar, ~1.2s"
   ↓
Kullanıcı onaylar
   ↓
egbimoto_run_manifest
```

---

## Preview Motoru Mimarisi

`McpPreviewHandler` her adımı şu şekilde kategorize eder:

| Domain | Op Örneği | Strateji |
|---|---|---|
| `Gate` | `selection_gate`, `preview_gate` | Atlanır |
| `Read` | `kalip_all`, `room_collect` | Gerçek `FilteredElementCollector` sorgusu |
| `Write` | `param_write`, `room_param_fill` | Eleman sayısı sorgusu + uyarı |
| `Create` | `family_place`, `wall_create` | Tahmin + uyarı |
| `Export` | `export_xlsx`, `export_ifc4` | Çıktı yolu gösterilir |

**Transaction açılmaz.** Model değişmez.

---

## Bilinen Sınırlamalar

1. **Create domain**: Oluşturulacak eleman sayısı önceden bilinemez — her zaman 0 döner.
2. **Parametre güncelleme sayısı**: Yazma adımlarında tam sayı ancak çalıştırıldıktan sonra bilinir.
3. **Zincirleme bağımlılıklar**: `from:` referansları preview'da çözülmez — her adım bağımsız analiz edilir.
4. **`undo_last`**: `PostCommand(Undo)` async çalışır — gerçek Undo stacki Revit'in kontrolündedir.

---

## V16.1 Planı (Sonraki İterasyon)

- `get_families` → instance sayısı sayımı optimize edilecek (şu an O(n²))
- `preview_manifest` → zincirleme veri akışı simülasyonu
- `egbimoto_validate` → ManifestLinter entegrasyonu (domain uyumluluk)
- Ribbon: MCP araç durumu göstergesi (kaç araç aktif)
