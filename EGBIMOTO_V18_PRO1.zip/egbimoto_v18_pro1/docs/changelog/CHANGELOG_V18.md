# EGBIMOTO V18 — Changelog

## Özet
V18: EGTranslatorProV2 tam entegrasyonu.
Yabancı dilli family parametreleri (EN/RU/ES/PT) otomatik tespit, çeviri ve standardizasyon.

## Yeni Dosyalar

| Dosya | Açıklama |
|---|---|
| `src/EGBIMOTO.Core/Translation/TranslatorEngine.cs` | translator_engine.py + data_loader.py C# portu |
| `src/EGBIMOTO.Addin/Ops/TranslateParamsOp.cs` | translate_params op |
| `src/EGBIMOTO.Addin/Server/McpTranslationHandler.cs` | /translate endpoint'leri |
| `src/EGBIMOTO.Addin/UI/Family/FamilyTranslatorWindow.xaml` | WPF arayüzü |
| `src/EGBIMOTO.Addin/UI/Family/FamilyTranslatorWindow.xaml.cs` | Code-behind |
| `manifest_skills/yabanciDilFamilyStandardizasyonu/` | Yeni skill |
| `data/translation/*.csv` | EGTranslatorProV2 sözlük verileri (9 dosya) |

## Yeni MCP Araçları (16 → 19)

| Araç | Endpoint | Açıklama |
|---|---|---|
| egbimoto_translate | GET /translate | Tek metin EN/RU/ES/PT→TR |
| egbimoto_translate_batch | POST /translate/batch | Toplu çeviri |
| egbimoto_best_param | GET /translate/best-param | En uygun TR shared param önerisi |

## 3 Kademeli Çeviri Motoru

```
1. DICT (Güven: 1.0)
   translation_dictionary.csv → tam eşleşme
   "Wall Height" → "Duvar Yüksekliği"

2. SMART (Güven: 0.85)
   Token bazlı parçalı çeviri
   "WallFireRating" → "Duvar" + "Yangın" + "Sınıfı" → "Duvar Yangın Sınıfı"

3. API (Güven: 0.70)
   MyMemory ücretsiz API (opsiyonel, internet gerektirir)
```

## WPF Arayüzü

Family Translator Window özellikleri:
- Otomatik dil tespiti (RU/EN/ES/PT)
- Renk kodlu method (DICT=yeşil, SMART=mavi, API=mor, UNCHANGED=gri)
- Rename vs CreateMap mod ayrımı
- Manuel düzeltme sütunu (satır satır override)
- "Sözlüğe Ekle" — yeni çeviriyi translation_dictionary.csv'ye yazar
- Excel + HTML raporu
- Kayıt klasörü seçimi (SaveAs için)

## Family Manager Bağlantısı

V14 Family Manager'da:
- `FamilyLibraryScanner` → `UnknownShared` durumu → V18'de TranslatorEngine ile çözülür
- `FamilyScanResult` → `TranslatorHint` field'ı eklendi (V18 sonrası)

## Entegrasyon

`McpServerToggleCommand.cs` değişmez.
`EgbimotoMcpServer.cs` data/translation/ klasörünü otomatik bulur:
```csharp
var dir = Path.GetDirectoryName(Assembly.Location) + "\\data\\translation";
var engine = TranslatorEngine.Load(dir);
```

## Veri Dosyaları (data/translation/)

| Dosya | İçerik |
|---|---|
| translation_dictionary.csv | 1399 satır, EN/RU/ES/PT↔TR tam eşleşmeler |
| semantic_dictionary.csv | 418 satır, anlam bazlı eşleşmeler |
| standard_parameters.csv | 390 satır, TR BIM standart parametre adları |
| shared_param_master_ref.csv | 418 satır, shared param SSoT |
| category_profiles.csv | 438 satır, kategori profilleri |
| TR_BIM_SharedParameters_MASTER_QA_CSB2026.txt | TR BIM shared param master |
| TR_BIM_IFC_ParameterMapping_QA_CSB2026.txt | IFC mapping |
| TR_BIM_IFC_CustomPsets_QA_CSB2026.txt | Custom Pset tanımları |
| TR_BIM_Revit_Category_Binding_Import.csv | Kategori bağlama matrisi |
