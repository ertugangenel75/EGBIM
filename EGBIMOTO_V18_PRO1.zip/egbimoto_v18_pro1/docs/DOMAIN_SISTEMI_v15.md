# EGBIMOTO v15 - Domain Sistemi

op_contracts.json artik her op icin `domain_out` ve `domain_in_accepts` icerir.
Bu, manifest zincirlerinin statik dogrulanmasini ve Pattern Uret oneri motorunu mumkun kilar.

## SSoT katmanlari (oncelik sirasi)

| # | Katman | Kaynak | Op sayisi |
|---|---|---|---|
| A | attribute | `[OpDomain(In, Out)]` C# | 1 |
| B | linter | `ManifestLinter.OpDomains` | 132 |
| C | inferred | isim + tip heuristigi | 303 |
| D | corpus | 357 manifest kalibrasyonu (accepts genisletme) | 25 |
| - | default | (Any) jenerik utility | 44 |

**Kapsam: 436/480 = %90** (v14: %28 -> v15: %90)

## 11 Domain

`Any` (joker), `Structural`, `MEP`, `Architectural`, `Report`, `Rows`, `Scalar`, `PozData`, `KalipResult`, `WbsData`, `IfcData`

### Rows hiyerarsisi

`PozData`, `KalipResult`, `Report`, `WbsData` hepsi `List<Dictionary>` tasir -> `Rows` bekleyen oplari besleyebilir (alt-tur -> ust-tur). Ters yon gecersiz.

## Uyumluluk kurali

Bir zincir kenari `A -> B` gecerlidir <=> A'nin `domain_out`'u, B'nin `domain_in_accepts` listesindeki herhangi bir domainle uyumludur (Any joker veya Rows hiyerarsisi dahil).

## Dogrulama

- 357 manifestlik korpus: **0 yanlis pozitif**
- `collect_pipes -> kalip_summary` (MEP->KalipResult): **dogru reddedilir**
- `collect_walls -> kalip_all -> kalip_summary -> show_result`: **dogru kabul edilir**

## Kullanim

```
# op_contracts.json yeniden uret (domain dahil)
python3 deploy/generate_op_contracts.py

# zincir dogrula
python3 scripts/domain_chain.py validate collect_walls kalip_all show_result
# bir op sonrasi oneriler
python3 scripts/domain_chain.py suggest kalip_all
# hedef domaine zincir oner
python3 scripts/domain_chain.py chain Structural Scalar
```

## Yeni op eklerken

Op metoduna `[OpDomain(In = Domain.X, Out = Domain.Y)]` ekle. Generator otomatik alir; Linter tablosuna satir eklemeye gerek yok.

## ManifestValidator entegrasyonu

`ManifestValidator.Validate()` artik `DOMAIN_MISMATCH` hatasi uretir. Contracts'ta `domain_out` yoksa kontrol sessizce kapalidir (geriye donuk uyumlu).
