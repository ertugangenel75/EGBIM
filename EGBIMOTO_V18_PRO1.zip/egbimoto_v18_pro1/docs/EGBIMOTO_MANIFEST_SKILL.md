# EGBIMOTO Manifest Yazım Skill

## Bu skill ne zaman kullanılır?
EGBIMOTO için manifest JSON dosyası yazacağın, düzelteceğin veya analiz edeceğin her durumda bu dosyayı önce oku.

---

## 1. Manifest Temel Yapısı

```json
{
  "title": "Kısa başlık",
  "description": "Ne yaptığını açıklayan cümle",
  "version": "1.0.0",
  "category": "Doğrulama|Mimari|Yapısal|MEP|Maliyet|IFC|ETL",
  "transaction_policy": "none|per_step|atomic",
  "steps": [...],
  "tags": ["tag1", "tag2"]
}
```

**Zorunlu alanlar:** `title`, `description`, `steps`

---

## 2. transaction_policy Seçimi — KRİTİK

### `"atomic"` — NE ZAMAN KULLANILIR
- Tüm adımlar sadece okuma yapar (collect, filter, calculate)
- Hiçbir step `requires_transaction: true` olan op kullanmıyor
- Ya hep ya hiç garantisi isteniyor ve tüm op'lar bu garantiyi destekliyor

### `"per_step"` — NE ZAMAN KULLANILIR (bSDD dersi)
- Herhangi bir step `write_param`, `place_family`, `add_shared_params` gibi **kendi transaction'ını açan** op kullanıyorsa
- Birden fazla ayrı yazma işlemi art arda geliyorsa (bSDD'de: CreateParams tx1 → SetVaryBetweenGroups tx2 → SetParams tx3)
- IFC export, schedule roundtrip, DataStorage yazma içeren pipeline'larda
- `requires_transaction: true` olan op'lardan **biri bile varsa** → `per_step`

### `"none"` — NE ZAMAN KULLANILIR
- Sadece okuma + rapor/export (Revit modelini değiştirmiyor)
- Preview/analiz manifestleri

### HATALI PATTERN (asla yapma)
```json
// YANLIŞ: write_param atomic içinde
{
  "transaction_policy": "atomic",
  "steps": [
    {"op": "collect_walls"},
    {"op": "write_param_from_rows"}  // requires_transaction=true → ÇAKIŞIR
  ]
}

// DOĞRU
{
  "transaction_policy": "per_step",
  ...
}
```

**`requires_transaction: true` olan op'lar (önemli olanlar):**
add_shared_params, align_tags, arch_apply_view_template, arch_renumber_doors, arch_sheets_from_data,
assign_egbim_mark, assign_poz_number, column_setup_params, copy_param, create_beam_by_curve,
create_column_by_point, create_floor, create_grid, create_level, create_room, create_sheet,
delete_generated, elec_conduit_calc_iec, elec_setup_conduit_params, family_batch_load,
family_load_to_project, mep_lintel_place, mep_opening_detect, mep_opening_validate,
place_family, place_family_on_ceiling, place_family_on_wall, place_opening, place_view_on_sheet,
rename_element, room_finish_assign, room_naming_normalize, room_to_ifc_space,
schedule_roundtrip_apply, set_element_type, set_level, set_phase, set_workset,
structural_column_presizing, structural_tbdy_params, tag_elements, trace_write,
update_or_create_family, wall_type_from_csv, workset_by_level, write_param, write_param_from_rows,
write_row_param, xlsx_import_apply

---

## 3. Step Yapısı

```json
{
  "id": "benzersiz_id",         // zorunlu, snake_case
  "op": "op_adi",               // zorunlu, op_contracts.json'da olmalı
  "from": "onceki_step_id",     // tek kaynak
  "from_many": ["id1","id2"],   // fan-in (merge için)
  "params": {                   // op parametreleri (inputs değil!)
    "param_adi": "deger"
  },
  "required": false             // opsiyonel step için
}
```

**UYARI:** `from` hiçbir zaman `inputs` içine yazılmaz:
```json
// YANLIŞ
{"inputs": {"from": "prev_step"}}

// DOĞRU  
{"from": "prev_step", "params": {...}}
```

---

## 4. Domain Akışı — Köprü Kuralları (bSDD ExtensibleStorage dersi)

Revit API'de element koleksiyonları farklı tip döndürür. EGBIMOTO'da domain uyumu zorunlu.

### Temel domain'ler
| Domain | Açıklama | Örnek op'lar |
|--------|----------|--------------|
| `Elements` | Genel element listesi | collect_elements, collect_mep |
| `Structural` | Yapısal element | collect_walls, collect_columns, collect_beams |
| `Rows` | Dict listesi (tablo) | filter_rows, group_by, add_column |
| `Report` | Validation raporu | param_exists_check, merge_validation_reports |
| `PozData` | Maliyet/poz verisi | poz_match, load_poz_data |
| `Scalar` | Tek değer/özet | count_elements, show_count |

### KÖPRü KURALI — Elements/Structural → Rows
`collect_*` op'larının çıktısı **direkt** `filter_rows`, `show_table`, `export_xlsx` gibi op'lara bağlanamaz.
Arada `elements_to_rows` köprüsü gerekir:

```json
// YANLIŞ
{"id": "duvarlar", "op": "collect_walls"},
{"id": "tablo", "op": "show_table", "from": "duvarlar"}  // Elements → Rows: HATA

// DOĞRU
{"id": "duvarlar", "op": "collect_walls"},
{"id": "duvarlar_rows", "op": "elements_to_rows", "from": "duvarlar"},
{"id": "tablo", "op": "show_table", "from": "duvarlar_rows"}
```

### Validation zinciri doğru sırası (bSDD pipeline dersi)
```
collect_* 
  → param_exists_check / param_filled_check   (domain_out: Report)
  → merge_validation_reports                  (domain_out: Report, fan-in ile)
  → validation_summary                        (domain_out: Report)
  → validation_to_rows                        (domain_out: Rows)
  → export_xlsx / show_table
```

**validation_summary'ye direkt collect/Rows bağlama:**
```json
// YANLIŞ
{"id": "duvarlar", "op": "collect_walls"},
{"id": "ozet", "op": "validation_summary", "from": "duvarlar"}  // atlama!

// DOĞRU
{"id": "duvarlar", "op": "collect_walls"},
{"id": "qa", "op": "param_exists_check", "from": "duvarlar", "params": {"param_name": "TR_CSB_PozNo"}},
{"id": "rapor", "op": "merge_validation_reports", "from_many": ["qa"], "params": {"title": "..."}},
{"id": "ozet", "op": "validation_summary", "from": "rapor"}
```

### IFC Export pipeline sırası (bSDD IFC dersi)
```
collect → classify/validate → ifc_hazirlik → export_ifc
```
- IFC export kendi transaction yönetir → `per_step`
- Post-process ayrı step olmalı
- Geçici tx ve restore tx ayrı adımlar (bSDD: Store → Export → Restore)

---

## 5. Yaygın SEM-HATA Nedenleri ve Çözümleri

| Hata | Neden | Çözüm |
|------|-------|--------|
| `validation_summary ← Rows` | collect çıktısı direkt bağlanmış | param_check + merge_validation_reports ekle |
| `show_table ← Elements` | köprü eksik | elements_to_rows ara step ekle |
| `filter_rows ← Structural` | köprü eksik | elements_to_rows ara step ekle |
| `cost_summary ← Rows` | poz_match sonrası direkt bağlanmış | genellikle OK (patch ile çözüldü) |
| `assign_wbs_code ← Elements` | WbsData bekleniyor | ara dönüşüm veya op patch |
| `ATOMIC_TX_CONFLICT` | write op atomic içinde | transaction_policy → per_step |
| `INVALID_TX_POLICY` | preview/single yazılmış | preview→none, single→per_step |

---

## 6. Op Kullanım Kalıpları

### Kalıp A: Toplama → Filtre → Rapor
```json
[
  {"id": "topla", "op": "collect_elements", "params": {"category": "OST_Walls"}},
  {"id": "satir", "op": "elements_to_rows", "from": "topla"},
  {"id": "filtre", "op": "filter_rows", "from": "satir", "params": {"field": "durum", "value": "hata"}},
  {"id": "tablo", "op": "show_table", "from": "filtre"},
  {"id": "xlsx", "op": "export_xlsx", "from": "filtre", "params": {"sheet_name": "Hatalar"}, "required": false}
]
```

### Kalıp B: QA Validation (çoklu kategori)
```json
[
  {"id": "duvarlar", "op": "collect_walls"},
  {"id": "kolonlar", "op": "collect_columns"},
  {"id": "qa_d", "op": "param_exists_check", "from": "duvarlar", "params": {"param_name": "EGBIM_PozNo"}},
  {"id": "qa_k", "op": "param_exists_check", "from": "kolonlar", "params": {"param_name": "EGBIM_PozNo"}},
  {"id": "birlestir", "op": "merge_validation_reports", "from_many": ["qa_d","qa_k"], "params": {"title": "QA"}},
  {"id": "ozet", "op": "validation_summary", "from": "birlestir"},
  {"id": "satirlar", "op": "validation_to_rows", "from": "birlestir"},
  {"id": "xlsx", "op": "export_xlsx", "from": "satirlar", "required": false}
]
```

### Kalıp C: Yazma Pipeline (per_step zorunlu)
```json
{
  "transaction_policy": "per_step",
  "steps": [
    {"id": "topla", "op": "collect_elements", "params": {"category": "OST_Walls"}},
    {"id": "satir", "op": "elements_to_rows", "from": "topla"},
    {"id": "yaz", "op": "write_param_from_rows", "from": "satir", "params": {"param_name": "...", "field": "..."}},
    {"id": "ozet", "op": "show_count", "from": "yaz"}
  ]
}
```

### Kalıp D: Maliyet/Poz Pipeline
```json
[
  {"id": "poz_veri", "op": "load_poz_data"},
  {"id": "poz_map", "op": "load_poz_canonical_map"},
  {"id": "poz_kural", "op": "load_poz_section_rules"},
  {"id": "kalip", "op": "kalip_all"},
  {"id": "esleme", "op": "poz_match_keynote_aware", "from": "kalip"},
  {"id": "maliyet", "op": "calc_cost", "from": "esleme"},
  {"id": "xlsx", "op": "export_xlsx", "from": "maliyet"}
]
```

### Kalıp E: IFC Teslim (per_step)
```json
{
  "transaction_policy": "per_step",
  "steps": [
    {"id": "hazirlik", "op": "ifc_param_hazirlik"},
    {"id": "sinifla", "op": "room_to_ifc_space", "from": "hazirlik"},
    {"id": "export", "op": "export_ifc4_tr_bim", "from": "sinifla"},
    {"id": "rapor", "op": "show_table", "from": "export"}
  ]
}
```

---

## 7. Sık Yapılan Hatalar (kesinlikle yapma)

1. **`from` inputs içine yazma** → her zaman step seviyesinde
2. **collect_* çıktısını doğrudan show_table/filter_rows'a bağlama** → elements_to_rows köprüsü ekle
3. **requires_transaction op'u atomic içine koyma** → per_step kullan
4. **transaction_policy olarak "preview" veya "single" yazma** → none/per_step/atomic
5. **validation_summary'ye Structural/Elements direkt bağlama** → param_check zinciri kur
6. **from_many kullanırken from da yazmak** → sadece biri olacak
7. **Aynı from_id'yi birden fazla elements_to_rows'a bağlamak** → tek köprü yeterli, diğerleri köprüye bağlanır

---

## 8. Manifest Kalite Skoru (Browser'da görünen puan)

Puan düşürücü faktörler:
- SEM-HATA: domain uyumsuzluğu (-2 puan/hata)
- UYARI: gerekli param eksik (-1 puan)
- Gereksiz adım (validation_to_rows sonrası tekrar validation_to_rows)
- per_step yerine atomic (yazma op'u varsa)

Puan artırıcı:
- pre_checks bloğu (model hazır mı kontrolü)
- required: false ile opsiyonel export adımları
- Anlamlı id isimleri (s01 yerine duvarlar, kolonlar)
- tags dizisi dolu

---

## 9. Validation Öncesi Kontrol Listesi

Manifest yazmadan önce her adım için sor:

- [ ] Op `op_contracts.json`'da var mı?
- [ ] `requires_transaction: true` mu? → transaction_policy: per_step
- [ ] Önceki step'in `domain_out` ile bu step'in `domain_in_accepts` uyumlu mu?
- [ ] Elements/Structural → Rows geçişi var mı? → elements_to_rows ekle
- [ ] `from` step seviyesinde mi (inputs içinde değil)?
- [ ] Validation zinciri: collect → check → merge → summary sırası doğru mu?

---

## 10. Revit API Gerçek Davranışı — Çoklu Repo Analizi

Bu bölüm 10 farklı gerçek Revit plugin'inden çıkarılan kritik davranış kurallarını içerir.

### 10.1 Transaction Yönetimi (mason, revit-clean-virus, CMW_Electrical)

**Tek transaction = tek sorumluluk.** mason'un `AbsCommand` pattern'i:
```csharp
// autoTransaction=true ise tüm CommandBody tek tx içinde
// autoTransaction=false ise CommandBody kendi tx'larını yönetir
```
EGBIMOTO manifestlerinde bunun karşılığı:
- Tüm adımlar sadece okuyorsa → `atomic` (tek tx gibi)
- Adımlar birbirinden bağımsız yazıyorsa → `per_step` (her biri kendi tx'ı)
- Hiç yazma yoksa → `none`

**Try/Catch + RollBack zorunlu** (revit-clean-virus dersi):
```csharp
tx.Start("...");
try { doc.Delete(...); tx.Commit(); }
catch { tx.RollBack(); return Result.Failed; }
```
Manifest'te `transaction_policy: "atomic"` bu pattern'i taklit eder — bir adım başarısız olursa tümü geri alınır. **Ama sadece requires_transaction=false olan op'larla çalışır.**

### 10.2 FailureHandler — Warning Yutma (CMW_Electrical, FileUpgrader)

Revit bazı işlemlerde Warning üretir ve transaction'ı durdurur. Gerçek kod:
```csharp
// IFailuresPreprocessor ile Warning'ları sil
failureAccessor.DeleteWarning(currentMessage);
return FailureProcessingResult.Continue;
```
EGBIMOTO'da yazma op'ları (`place_family`, `create_wall` vs.) bu nedenle `per_step` ile çalışmalı — her step kendi failure handler'ını yönetir. `atomic` ile Warning oluştuğunda **tüm manifest iptal olur.**

**DialogBox olayları** (FileUpgrader dersi): Revit bazı işlemlerde dialog kutusu açar. EGBIMOTO batch işlemlerinde bu riski taşıyan op'lar: `family_batch_load`, `delete_generated`, `xlsx_import_apply` — bunlar `per_step` olmalı.

### 10.3 ElementId ve LinkedModel Farkı (ClashControl, ElementCache)

**ElementId, doküman bazında benzersizdir** — farklı dokümanlarda aynı IntegerValue farklı elemana işaret edebilir:
```csharp
// YANLIŞ: sadece elementId.Value ile lookup
// DOĞRU: docKey + elementId.Value birlikte kullan
public static string GetDocKey(Document doc) =>
    !string.IsNullOrEmpty(doc.PathName) ? doc.PathName : doc.Title;
```
Manifest'te linked model işlemleri için: `collect_elements` yerine link-aware op'lar (`collect_linked_elements` varsa) kullanılmalı.

**Koordinat dönüşümü** (ClashControl GeometryExporter dersi): Link model geometrisi link'in kendi koordinatında gelir — host modele transform uygulanmadan `from` zincirine bağlanamaz. Bu nedenle koordinasyon manifestlerinde:
```json
{"id": "linked", "op": "collect_linked_elements", "params": {"apply_transform": true}}
```
`apply_transform` parametresi olmadan linked element koordinatları yanlış olur.

### 10.4 Geometry — BoundingBox Clash Tespiti (mason)

Clash tespiti için BoundingBox AABB algoritması:
```csharp
// İki bbox çakışıyor mu?
return bbox1.Min.X <= bbox2.Max.X && bbox1.Max.X >= bbox2.Min.X &&
       bbox1.Min.Y <= bbox2.Max.Y && bbox1.Max.Y >= bbox2.Min.Y &&
       bbox1.Min.Z <= bbox2.Max.Z && bbox1.Max.Z >= bbox2.Min.Z;
```
EGBIMOTO'da `run_clash_check` op'u bu algoritmayı kullanır. Manifestte clash pipeline doğru sırası:
```json
{"id": "gr1", "op": "collect_elements", "params": {"category": "OST_StructuralColumns"}},
{"id": "gr2", "op": "collect_mep_elements"},
{"id": "clash", "op": "run_clash_check", "from": "gr1", "params": {"compare_with": "gr2"}},
{"id": "rapor", "op": "show_table", "from": "clash"}
```
**Önce BoundingBox → Geometry filter** (iki aşamalı): BBox hızlı, geometry yavaş. Op zaten bunu yapıyor ama manifest'te BBox pre-filter varsa performans artar.

### 10.5 ExternalEvent — Modeless UI Pattern (Revit_Nr)

Modeless window'dan Revit API'ye erişim doğrudan mümkün değil — `IExternalEventHandler` + `ExternalEvent.Raise()` gerekir:
```csharp
// UI thread'den güvenli Revit API çağrısı
_requestQueue.Enqueue(request);
_externalEvent.Raise(); // Revit API context'inde Execute() çağrılır
```
EGBIMOTO manifestlerinde bu pattern'in önemi: **interaktif manifest'ler** (`interaktif/` klasörü) kullanıcı seçimi beklediğinde `get_selection` → `pause_for_input` → devam zinciri kurmalı. Direkt collect yerine seçim bekleyen adımlar ayrı step olmalı.

### 10.6 View Filter ve OverrideGraphics (Revit_Nr ViewFilterHighlighter)

View'a filter uygulamak için:
1. `SelectionFilterElement.Create(doc, filterName)` — transaction gerektirir
2. `view.AddFilter(filterElement.Id)` — transaction gerektirir  
3. `view.SetFilterOverrides(filterId, ogs)` — transaction gerektirir

**View Template varsa filtre template'e uygulanır, view'a değil:**
```csharp
if (!view.AreGraphicsOverridesAllowed() && view.ViewTemplateId != InvalidElementId)
    filterTarget = template; // view değil template'e uygula
```
EGBIMOTO'da `create_view_filter` op'u bu kontrolü yapmalı. Manifestte view filter oluşturma:
```json
{"id": "filtre", "op": "create_view_filter", 
 "params": {"filter_name": "EGBIM_Hata", "color": "#FF0000", "apply_to_template": true}}
```
`apply_to_template: true` olmadan template'li view'larda filtre görünmez.

### 10.7 Compliance/QA Scan Pattern (Codeguardian)

Çok kategorili QA scan için doğru manifest pattern'i Codeguardian'dan öğrenildi:

**Önce genel context kontrolü, sonra kategori taraması:**
```json
[
  {"id": "ctx_kontrol", "op": "assert_model_context"},    // proje ayarları tam mı?
  {"id": "kapi_qa",    "op": "param_filled_check", ...},  // kapı taraması
  {"id": "merdiven_qa","op": "param_filled_check", ...},  // merdiven taraması
  {"id": "rampa_qa",   "op": "param_filled_check", ...},  // rampa taraması
  {"id": "oda_qa",     "op": "param_filled_check", ...},  // oda taraması
  {"id": "birles",     "op": "merge_validation_reports", "from_many": ["kapi_qa","merdiven_qa","rampa_qa","oda_qa"]},
  {"id": "ozet",       "op": "validation_summary", "from": "birles"},
  {"id": "html",       "op": "export_validation_report", "from": "birles", "required": false}
]
```

**Severity seviyeleri** (Codeguardian: High/Medium/Low):
```json
{"id": "kapi", "op": "param_exists_check", "params": {"param_name": "Kapı_Genişlik", "severity": "ERROR"}}
{"id": "etiket", "op": "param_filled_check", "params": {"param_name": "Mark", "severity": "WARNING"}}
```

### 10.8 Elektrik Devre Pipeline (CMW_Electrical)

Elektrik devre oluşturma sırası (CreateEquipmentCircuit'ten öğrenildi):
1. Önce mevcut devre var mı kontrol et (`GetElectricalSystems()`)
2. Varsa ve kaynak yanlışsa `DisconnectPanel()` sonra `SelectPanel()`
3. Yoksa `ConnectorSet`'ten `ElectricalSystem.Create()` + `SelectPanel()`

EGBIMOTO manifest karşılığı:
```json
{
  "transaction_policy": "per_step",
  "steps": [
    {"id": "pano_topla", "op": "collect_elements", "params": {"category": "OST_ElectricalEquipment"}},
    {"id": "devre_kontrol", "op": "elec_circuit_check", "from": "pano_topla"},
    {"id": "devre_uret", "op": "elec_assign_circuit", "from": "devre_kontrol"},
    {"id": "rapor", "op": "show_table", "from": "devre_uret"}
  ]
}
```
**Her elektrik yazma op'u `requires_transaction=true`** → `per_step` zorunlu.

### 10.9 Elementleri Yeniden Adlandırma Pattern (Renamer)

Toplu yeniden adlandırma sırası:
1. Önce tüm isimleri collect et
2. Yeni isimleri hesapla (prefix/suffix/find-replace)
3. Çakışma kontrolü yap
4. Toplu Transaction içinde yaz

Manifest:
```json
{
  "transaction_policy": "per_step",
  "steps": [
    {"id": "topla", "op": "collect_elements", "params": {"category": "OST_Views"}},
    {"id": "satirlar", "op": "elements_to_rows", "from": "topla"},
    {"id": "yeni_isim", "op": "add_column", "from": "satirlar", "params": {"field": "yeni_isim", "value": ""}},
    {"id": "yaz", "op": "rename_element", "from": "yeni_isim", "params": {"name_field": "yeni_isim"}},
    {"id": "ozet", "op": "show_count", "from": "yaz"}
  ]
}
```

### 10.10 Hata Güvenliği — Try/Catch Olmayan Manifestler

Codeguardian'da her helper `try/catch` ile sarılmış:
```csharp
private static bool SafeIsOrphaned(IndependentTag tag) {
    try { return tag.IsOrphaned; }
    catch { return true; } // güvenli default
}
```

EGBIMOTO manifestlerinde bu dersi uygula: **kritik olmayan adımlar `required: false` olmalı.**
```json
{"id": "xlsx",  "op": "export_xlsx", "from": "satirlar", "required": false},
{"id": "html",  "op": "export_validation_report", "from": "birles", "required": false},
{"id": "email", "op": "send_report", "from": "html", "required": false}
```
Export/raporlama adımları her zaman `required: false` — temel hesap başarılıysa rapor oluşturulamaması tüm manifest'i durdurmamalı.

---

## 11. Özet — Kaynaklar ve Kurallar

| Kaynak | Öğrenilen Kural | EGBIMOTO Kuralı |
|--------|----------------|-----------------|
| bSDD | Çoklu tx zinciri | `per_step` for write ops |
| bSDD | ExtensibleStorage schema | DataStorage ops → `per_step` |
| mason | `AbsCommand` auto-tx | `atomic` = tek sorumluluk |
| mason | BoundingBox AABB | clash pipeline 2 aşamalı |
| revit-clean-virus | RollBack pattern | `atomic` = try/catch + rollback |
| CMW_Electrical | FailureHandler | Warning üreten op'lar `per_step` |
| CMW_Electrical | Devre yaratma sırası | elektrik pipeline sırası |
| Codeguardian | Compliance scan | QA chain: context→scan→merge→summary |
| Codeguardian | Severity seviyeleri | severity param: ERROR/WARNING |
| Codeguardian | Safe helper pattern | export adımları `required: false` |
| ClashControl | ElementId per-doc | linked model `apply_transform: true` |
| ClashControl | Geometry Z-up→Y-up | clash: feet→meters dönüşüm |
| Revit_Nr | ExternalEvent queue | interaktif: `get_selection` ayrı step |
| Revit_Nr | ViewFilter+Template | view filter `apply_to_template` param |
| Renamer | Toplu rename sırası | collect→compute→check→write |
| FileUpgrader | DialogBox suppress | batch load op'ları `per_step` |

---

## 12. İkinci Batch Repo Analizi — 18 Plugin

### 12.1 MCP / Bridge Araç Dağıtımı (Transom BridgeTools)

Transom'un `BridgeTools.Handle()` — EGBIMOTO MCP sunucusunun yaptığına birebir benzer. Kritik pattern:

```csharp
return tool switch {
    "status"         => Status(doc),
    "list_schedules" => ListSchedules(doc),
    "set_parameter"  => SetParameter(doc, args),
    // ...
    _                => Err($"unknown tool '{tool}'"),
};
```

**EGBIMOTO manifest'te MCP araç çağrısı için kurallar:**
- Her araç çağrısı ayrı step olmalı
- `set_parameter` → `requires_transaction: true` → `per_step`
- Okuma araçları (`list_schedules`, `status`) → `none`
- **Parametre yazma doğrulama sırası:** Set → Re-read → Verify (eğer verify başarısız → RollBack)

```json
{"id": "yaz", "op": "write_param", "params": {"param_name": "...", "value": "..."}},
{"id": "dogrula", "op": "param_filled_check", "from": "yaz", "params": {"param_name": "..."}},
```

### 12.2 Parametre Okuma Hiyerarşisi (RevitMCPBOQ)

BuiltIn → İsim → Lokalize isim sırası ile fallback:
```csharp
// Uzunluk okuma sırası:
CURVE_ELEM_LENGTH → INSTANCE_LENGTH_PARAM → "Length" → "Longitud"
// Alan okuma sırası:
HOST_AREA_COMPUTED → "Area" → "Área"
// Hacim okuma sırası:
HOST_VOLUME_COMPUTED → "Volume" → "Volumen"
```

EGBIMOTO manifest'te metraj/maliyet için:
```json
{"id": "metraj", "op": "collect_elements", 
 "params": {"category": "OST_Walls", "read_params": ["HOST_AREA_COMPUTED", "Area", "HOST_VOLUME_COMPUTED", "Volume"]}}
```

**Sayı parse etme:** `AsDouble()` önce, `AsValueString()` → temizle → `double.TryParse()` sonra. BOQ manifestlerinde hesaplama op'ları bu sırayı uygular — ham `AsValueString()` kullanmak yanlış.

### 12.3 Penetrasyon / Delik Yerleştirme (RevitPenetrationPlugin)

Delik yerleştirme pipeline'ı — EGBIMOTO'nun `place_opening` op'u için referans:

```
Kesişim tespiti → Sembol aktif et → Level belirle → Instance yerleştir → 
XY rotasyon uygula → Parametreler yaz
```

**Her delik ayrı Transaction içinde** (toplu değil):
```csharp
using var txGroup = new TransactionGroup(_doc, "Place Penetrations");
txGroup.Start();
for each intersection:
    using var tx = new Transaction(_doc, $"Place [{i}]");
    tx.Start();
    // ... place + setParam ...
    tx.Commit(); // veya RollBack()
txGroup.Assimilate();
```

EGBIMOTO manifestine karşılığı:
```json
{
  "transaction_policy": "per_step",
  "steps": [
    {"id": "kesisim", "op": "mep_opening_detect", "params": {"scope": "EntireProject", "mep_categories": ["OST_DuctCurves","OST_PipeCurves"]}},
    {"id": "dogrula", "op": "mep_opening_validate", "from": "kesisim"},
    {"id": "yerles", "op": "place_opening", "from": "dogrula", "params": {"skip_existing": true, "clearance_mm": 50}},
    {"id": "rapor", "op": "show_table", "from": "yerles"}
  ]
}
```

**Rotasyon notu:** Yalnızca XY düzleminde (Z ekseni etrafında) döndür. 3D rotasyon `"Can't rotate into this position"` hatası verir. Bu, `place_opening` op'un kendi içinde yaptığı — manifest'te ekstra rotasyon step'i **ekleme**.

**`skip_existing: true`** olmadan aynı noktaya birden fazla delik yerleşir.

### 12.4 Donatı Modelleme — Karmaşık Pipeline (RevitRebarModeler)

Donatı yerleştirme — EGBIMOTO'nun `create_rebar_*` op'ları için:

```
JSON/CSV yükle → Global Origin ayarla → Host map oluştur → 
Longitudinal rebar topla (Mark regex ile) → CTC hesapla → 
Transverse CTC topla → Shear rebar hesapla → Transaction içinde Rebar.CreateFromCurves()
```

**Kritik:** Önce `longitudinal` barlar yerleştirilmeli, `shear` barlar bunların koordinatlarını okur:
```csharp
// Mark regex: "구조도(N)_longi_outer_M단"
var markRegex = new Regex(@"^(구조도\(\d+\))_longi_(outer|inner)_(\d+)단(_SD\d+)?$");
```

EGBIMOTO manifest sırası:
```json
{"id": "longi",  "op": "collect_rebar", "params": {"mark_pattern": "longi"}},
{"id": "ctc",    "op": "calc_rebar_ctc", "from": "longi"},
{"id": "shear",  "op": "create_shear_rebar", "from": "ctc", "params": {"bundle_count": 2}}
```

`create_shear_rebar` → `requires_transaction: true` → `per_step` zorunlu.

**FreeForm fallback:** `Rebar.CreateFromCurves(StirrupTie)` başarısız olursa FreeForm'a düş — op bunu otomatik yapar. Manifest'te `required: false` EKLEME — hata olursa raporda görünmeli.

### 12.5 RayScanning / Yapısal Tarama (sg-revit-addin StructureRayScanner)

MEP askı rod uzunluğu için üst yapıya ray scanning:

**3 kaynak:** Native ReferenceIntersector + DirectShape mesh index + CAD import raycaster

**Sorunlar ve çözümleri:**
1. `Phantom proximity` → Triangle geometry ile re-measure, yanlış olanı reject
2. `Fan slope bias` → Offset ray'ler değil center ray kullan
3. `Linked IFC / DirectShape pass-through` → Manuel Möller-Trumbore raycasting

EGBIMOTO manifest'te `mep_aski_yerlestirme` için:
```json
{"id": "scan", "op": "run_structure_scan", 
 "params": {
   "use_fan": true,
   "verify_geometry": true,
   "index_direct_shapes": true,
   "max_distance_ft": 120,
   "find_references_in_links": true
 }}
```

`find_references_in_links: true` olmadan linked model'deki yapısal elemanlar görünmez.

### 12.6 Section Box ve Zone Yönetimi (SectionBoxManager)

ExtensibleStorage'da zone kaydetme ve clash import:

**CommandGuard pattern** — her command'ı sarmala:
```csharp
internal static class CommandGuard {
    public static Result Run(string commandName, CommandBody body, ...) {
        try { return body(...); }
        catch (OperationCanceledException) { return Result.Cancelled; }
        catch (Exception ex) { Log.Error(...); message = ex.Message; return Result.Failed; }
    }
}
```

EGBIMOTO op'larının tamamı bu pattern ile çalışır. Manifest'te:
- `OperationCancelledException` → `Result.Cancelled` → manifest UYARI ile biter (hata değil)
- `Exception` → `Result.Failed` → manifest HATA ile biter

Clash import birimi dönüşümü:
```csharp
// Feet | Inches | Millimeters | Meters → Revit internal (feet)
```
Clash koordinasyonu manifestlerinde `source_unit` parametresi kritik:
```json
{"id": "import", "op": "import_clash_report", 
 "params": {"file_path": "...", "source_unit": "Millimeters"}}
```

### 12.7 Workset Renk Kodlaması (sg-revit-addin ColorizeByWorkset)

Workset bazlı renklendirme — Navisworks'e export için:

**Neden View/Filter override değil:** NWC exporter, view override'ları yok sayar. Renk **malzeme** üzerinde olmalı.

**Boru renklendirme sırası:**
1. Per-status pipe type duplicate oluştur (`per_step` transaction)
2. Pipe'ları yeni type'a değiştir (`ChangeTypeId`)
3. Family instance'lara material param yaz

**EditFamily → LoadFamily döngüsü kendi transaction'ını açar** → asla `atomic` içine koyma.

EGBIMOTO manifest:
```json
{
  "transaction_policy": "per_step",
  "steps": [
    {"id": "workset_topla", "op": "collect_worksets"},
    {"id": "dup_type", "op": "duplicate_pipe_types_by_workset", "from": "workset_topla"},
    {"id": "renkle", "op": "assign_workset_color", "from": "dup_type"},
    {"id": "rapor", "op": "show_count", "from": "renkle"}
  ]
}
```

### 12.8 Column Dokümentasyon (revit-main ColumnViewsEngine)

Kolon için otomatik görünüm oluşturma:

**Sıra:** Her kolon için TX → Rebar topla → BBox hesapla → Elevasyon oluştur → Plan oluştur → TX commit  
**Son pass:** Tüm kolonlar bittikten sonra section marker'ları gizle (başka TX)

```csharp
// Son pass — section marker temizlik
using var tx = new Transaction(_doc, "Column Views — hide foreign sections");
tx.Start();
_doc.Regenerate(); // ← ÖNEMLİ: Regenerate olmadan görünüm değişiklikleri tutarsız olabilir
foreach (...) HideForeignSectionMarkers(view, keep);
tx.Commit();
```

**`doc.Regenerate()` neden gerekli:** View'e ekleme/düzenleme sonrası Revit'in internal state'i güncellenmesi için. EGBIMOTO'da görünüm oluşturma pipeline'ında son adım:

```json
{"id": "view_uret", "op": "create_column_views", "from": "kolonlar"},
{"id": "regenerate", "op": "regenerate_doc"},  ← varsa ekle
{"id": "marker_gizle", "op": "hide_section_markers", "from": "view_uret"}
```

### 12.9 Delik Eğim Hesabı — Solid Geometry (RevitPlugins OpeningHandler)

Solid Geometry ile açıklık eğim hesabı:

```csharp
// Solid → BoundingBox dönüşümü:
BoundingBoxXYZ bbox = solid.GetBoundingBox();
_openingBoundingBox = new BoundingBoxXYZ() {
    Min = bbox.Transform.OfPoint(bbox.Min),
    Max = bbox.Transform.OfPoint(bbox.Max)
};
```

**Transform.OfPoint kullanılmazsa BBox yanlış koordinat sisteminde!**

EGBIMOTO'da geometri hesaplama manifestlerinde:
```json
{"id": "bbox", "op": "get_element_bbox", "params": {"apply_transform": true}}
```
`apply_transform: false` bırakılırsa angled/rotated elemanlarda yanlış BBox.

### 12.10 Sprinkler AutoConnect Pattern

Sprinkler bağlantı pipeline'ı: `collect → proximity_sort → connect_nearest → validate`

Her bağlantı işlemi kendi transaction'ında → `per_step`.

Bağlantı öncesi `EnsureSymbolActive` zorunlu (sprinkler family aktif değilse Place başarısız olur).

### 12.11 QAQC Scan Pattern (RevitQAQC)

Çok kategorili QA scan için en sağlam pattern:

```
pre_check (model hazır mı?) → 
multi_collect (paralel, fan-in) → 
rule_check per category → 
merge → 
severity_filter → 
export
```

```json
[
  {"id": "pre", "op": "assert_model_context", "params": {"min_elements": 1}},
  {"id": "cap", "op": "collect_elements", "params": {"category": "OST_Floors"}},
  {"id": "pon", "op": "param_filled_check", "from": "cap", "params": {"param_name": "Area", "severity": "ERROR"}},
  {"id": "birles", "op": "merge_validation_reports", "from_many": ["pon"], "params": {"title": "QAQC"}},
  {"id": "ozet", "op": "validation_summary", "from": "birles"},
  {"id": "yuksek", "op": "filter_rows", "from": "ozet", "params": {"field": "severity", "value": "ERROR"}},
  {"id": "xlsx", "op": "export_xlsx", "from": "yuksek", "required": false}
]
```

### 12.12 DXF / CAD Export (RVTuk DxfWriter)

DXF/CAD export için unit dönüşümü:
- Revit internal = feet
- DXF çoğunlukla mm veya cm
- **Dönüşüm hatası → tüm koordinatlar yanlış**

```csharp
// Feet → cm: * 30.48
// Feet → mm: * 304.8
// Feet → m:  * 0.3048
```

EGBIMOTO export manifestlerinde:
```json
{"id": "export", "op": "export_dxf", "params": {"unit": "mm", "scale": 1.0}}
```
`unit` parametresi eksikse default feet — Türk standartlarında her zaman `mm` belirt.

### 12.13 Logger Pattern (RevitLogger)

Revit plugin'de doğru log formatı:
```
2025-01-15 14:23:45.123 | INFO     | FileName.cs:42 | message
```

EGBIMOTO manifest yazarken trace/debug adımları:
```json
{"id": "log", "op": "trace_write", "params": {"message": "Step X tamamlandı", "level": "INFO"}}
```
`trace_write` → `requires_transaction: true` (log dosyasına yazar) → `per_step` pipeline'larda kullan.

---

## 13. Konsolide Kurallar — Tüm Repoların Özeti

### 13.1 Transaction Policy Karar Ağacı

```
Tüm step'ler sadece okuma?
  → transaction_policy: "none"

Herhangi bir step requires_transaction=true?
  → transaction_policy: "per_step"
  (atomic KESİNLİKLE kullanma)

Tüm step'ler okuma + en fazla 1 atomic yazma bloğu?
  → transaction_policy: "atomic"
  (tüm op'lar requires_transaction=false olmalı)
```

### 13.2 Domain Köprü Zorunluluğu

```
collect_* (domain_out=Structural/Elements)
    ↓ elements_to_rows ZORUNLU
filter_rows / show_table / export_xlsx / write_param_from_rows
```

### 13.3 Parametreli Op'larda Fallback Hiyerarşisi

```
1. BuiltInParameter (en güvenilir)
2. LookupParameter("English Name")
3. LookupParameter("Localized Name")
4. AsValueString() → parse → double
```

### 13.4 Linked Model İşlemleri

```
collect_linked_elements (apply_transform: true)
    ↓ 
clash / koordinasyon işlemleri
```
`apply_transform: false` → koordinatlar yanlış (flying elements).

### 13.5 Geometri Hesaplamaları

```
solid.GetBoundingBox().Transform.OfPoint() → doğru
solid.GetBoundingBox().Min/Max (transform uygulanmamış) → YANLIŞ
```

### 13.6 Export Manifestleri

```
her zaman: required: false
her zaman: unit belirt (mm, cm, m — asla feet)
her zaman: transaction_policy: "none" (export okuma'dır)
```

| Kaynak | Ana Öğrenim |
|--------|------------|
| Transom BridgeTools | MCP araç dispatch → per_step write, verify after write |
| RevitMCPBOQ | Param okuma hiyerarşisi: BuiltIn→Name→Localized |
| RevitPenetrationPlugin | Delik pipeline: detect→validate→place (per_step, XY-only rotate) |
| RevitRebarModeler | Donatı sırası: longi önce, shear sonra; FreeForm fallback otomatik |
| sg-revit StructureRay | Ray scan: 3 kaynak, phantom reject, linked model transform |
| SectionBoxManager | CommandGuard pattern; clash import unit dönüşümü |
| sg-revit ColorizeWorkset | Navisworks: view override değil material rengi; EditFamily kendi TX |
| revit-main ColumnViews | Regenerate() sonra marker temizlik |
| RevitPlugins OpeningHandler | solid.GetBoundingBox().Transform.OfPoint() zorunlu |
| RevitQAQC | pre_check → multi_collect → rule_check → merge → severity_filter |
| RVTuk DxfWriter | Export: unit her zaman mm belirt |
| RevitLogger | trace_write requires_transaction=true → per_step |

---

## 14. scaddins + Sheet-level Creator Analizi

### 14.1 Level + Sheet + View Yaratma Sırası (Sheet-level Creator)

Toplu kat/pafta oluşturma için doğru sıra ve kritik noktalar:

**Level oluşturma:**
```csharp
// 1. Mevcut kontrol: hem elevation hem name kontrol et
Level existing = AllLevels.FirstOrDefault(l =>
    Math.Abs(l.Elevation - elevFt) < 0.01 ||  // çok küçük tolerans!
    l.Name.Equals(levelName, StringComparison.OrdinalIgnoreCase));

// 2. Unit dönüşümü — proje birimini oku, ona göre çevir
ForgeTypeId units = doc.GetUnits().GetFormatOptions(SpecTypeId.Length).GetUnitTypeId();
double elevFt = UnitUtils.ConvertToInternalUnits(elevation, units);

// 3. Ad çakışmasında fallback: Id ekle
try { level.Name = levelName; }
catch { level.Name = levelName + $"_{level.Id.IntegerValue}"; }
```

**ViewPlan oluşturma sırası:**
```csharp
// ViewFamilyType önce bul (FloorPlan, CeilingPlan, StructuralPlan)
var floortype = new FilteredElementCollector(doc)
    .OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>()
    .FirstOrDefault(v => v.ViewFamily == ViewFamily.FloorPlan);

// Sonra ViewPlan.Create(doc, floortype.Id, level.Id)
ViewPlan floorplan = ViewPlan.Create(doc, floortype.Id, newLevel.Id);
```

**Viewport yerleştirme:**
```csharp
// Sheet outline'ın merkezini hesapla
XYZ center = new XYZ(
    (sheet.Outline.Min.U + sheet.Outline.Max.U) / 2,
    (sheet.Outline.Min.V + sheet.Outline.Max.V) / 2, 0);
Viewport.Create(doc, sheet.Id, viewId, center);
```

**EGBIMOTO manifest karşılığı:**
```json
{
  "transaction_policy": "per_step",
  "steps": [
    {"id": "katlar", "op": "create_level", 
     "params": {"name": "Kat", "start_elevation": 0, "increment": 3000, "count": 5, "unit": "mm"}},
    {"id": "planlar", "op": "create_floor_plan", "from": "katlar",
     "params": {"name_suffix": " Kat Planı", "view_family": "FloorPlan"}},
    {"id": "paftalar", "op": "create_sheet", 
     "params": {"prefix": "A", "count": 5, "title_block": "EGBIM_TitleBlock"}},
    {"id": "viewport", "op": "place_view_on_sheet", 
     "params": {"position": "center", "link_level_to_sheet": true}}
  ]
}
```

**Kritik:** `create_level` → `per_step` zorunlu (Level.Create kendi TX gerektirir). Ad çakışması durumunda `_{id}` suffix otomatik eklenir — manifestte buna güven.

### 14.2 Sheet Kopyalama Pipeline (scaddins SheetCopierManager)

Sheet kopyalama sırası:
```
1. Kaynak sheet'in viewport'larını topla (GetViewportDictionary)
2. Yeni boş sheet oluştur (ViewSheet.Create)
3. Her view için: view'ı kopyala veya bağımsız yap
4. Viewport'ları aynı konuma yerleştir (PlaceViewPortOnSheet)
5. Revision cloud'ları sil (opsiyonel)
6. Özet yaz
```

**Sheet numarası çakışma çözümü:**
```csharp
do {
    inc++;
} while (!SheetNumberAvailable(original + "-" + inc));
```

EGBIMOTO manifest:
```json
{"id": "kopyala", "op": "copy_sheet",
 "params": {"source_sheet_number": "A-01", "new_number": "A-02", 
            "copy_views": true, "delete_revision_clouds": true}}
```

### 14.3 PDF Export Pipeline (scaddins ExportManager)

PDF export sırası — `transaction_policy: "none"` (export sadece okuma):

```
1. PrintManager al
2. PrintSetting ata (by name)
3. Registry'e output path yaz (PDF printer için)
4. ValidExportName kontrol et
5. Directory.Exists kontrol et
6. Mevcut dosyayı sil (overwrite)
7. pm.SubmitPrint(sheet)
8. WaitForFileAccess (async tamamlanma için bekle)
9. PostExportHook çalıştır
10. Acrotray process'i öldür (Acrobat'ın askı sorunu)
```

**EGBIMOTO manifest:**
```json
{
  "transaction_policy": "none",
  "steps": [
    {"id": "paftalar", "op": "collect_sheets", "params": {"filter": "selected"}},
    {"id": "export", "op": "export_pdf", "from": "paftalar",
     "params": {
       "output_dir": "C:/Export",
       "naming_rule": "{SheetNumber}_{SheetName}_{RevisionDate}",
       "overwrite": true,
       "wait_for_file": true
     }, "required": false},
    {"id": "hook", "op": "run_post_export_hook", "from": "export", "required": false}
  ]
}
```

**Kritik:** `pm.SubmitPrint()` asenkron çalışır — WaitForFileAccess olmadan sonraki adım dosyaya erişemez.

### 14.4 Dosya İsmi Şeması (SegmentedSheetName)

SCaddins'in export dosya ismi şeması EGBIMOTO'nun naming_rule parametresiyle örtüşür:

| SCaddins token | EGBIMOTO karşılığı |
|---|---|
| `{SheetNumber}` | `{sheet_number}` |
| `{SheetName}` | `{sheet_name}` |
| `{RevisionDate}` | `{revision_date}` |
| `{RevisionDescription}` | `{revision_description}` |
| `{ProjectName}` | `{project_name}` |

Geçersiz karakter kontrolü (`ValidExportName`) manifestte naming_rule'da `\/:*?"<>|` karakterlerinden kaçın.

### 14.5 Destructive Purge Pattern (scaddins)

Toplu element silme:
```csharp
using (var t = new Transaction(doc)) {
    t.Start("Delete Elements");
    foreach (var item in elements) {
        // Birden fazla güvenlik kontrolü:
        if (item.Id == null) continue;
        if (!doc.GetElement(item.Id).IsValidObject) continue;  // geçersiz mi?
        if (doc.ActiveView.Id == item.Id) continue;            // aktif view mi?
        if (item.HasParent && item.ParentId == ElementId.InvalidElementId) continue; // parent geçersiz mi?
        doc.Delete(item.Id);  // try-catch ile
    }
    t.Commit();
}
```

**EGBIMOTO manifest:**
```json
{
  "transaction_policy": "atomic",  // tümü sil ya da hiç silme
  "steps": [
    {"id": "topla", "op": "collect_elements", "params": {"category": "OST_RasterImages"}},
    {"id": "filtre", "op": "filter_rows", "from": "topla", "params": {"field": "is_valid", "value": "true"}},
    {"id": "sil", "op": "delete_generated", "from": "filtre"}
  ]
}
```

**`delete_generated` → `requires_transaction: true`** → `per_step` veya `atomic` (sadece silme op'u varsa `atomic` OK).

### 14.6 RenameManager — Toplu Yeniden Adlandırma Komutları

scaddins RenameManager'ın komut listesi EGBIMOTO `rename_element` op'u için referans:

| Komut | İşlev |
|---|---|
| `RegexReplace` | Regex ile bul-değiştir |
| `Increment` | Sayı arttır |
| `IncrementLast` | Sondaki sayıyı arttır |
| `PadLeadingZeros` | Baştaki sıfırları ekle (örn. 1→001) |
| `Reverse` | Ters çevir |
| `SpacesToUnderscore` | Boşluk → `_` |
| `SpacesToHyphen` | Boşluk → `-` |
| `TitleCase` | Başlık harfleri |
| `UpperCase` | Büyük harf |

EGBIMOTO manifest:
```json
{"id": "yeniden_adlandir", "op": "rename_element",
 "params": {
   "mode": "regex_replace",
   "search": "^(\\d+)_",
   "replace": "EGBIM_$1_",
   "categories": ["OST_Views", "OST_Sheets"]
 }}
```

### 14.7 Grid Yönetimi — Bubble Toggle (scaddins GridManager)

Grid bubble yönünü view koordinatına göre belirle:

```csharp
// Grid yönü view'e göre hesapla
var direction = GetGridDirection(grid);
var leftDirection = activeView.RightDirection.Negate();
var crossProduct = direction.DotProduct(leftDirection);
// 0.707 = 45 derece eşiği
if (Math.Abs(crossProduct) >= 0.707) {
    var datumEnd = crossProduct < 0 ? DatumEnds.End1 : DatumEnds.End0;
    ToggleGridEnd(grid, enable, datumEnd, activeView);
}
```

EGBIMOTO manifest:
```json
{"id": "grid_bubble", "op": "toggle_grid_bubble",
 "params": {"side": "left", "enable": true, "view_id": "active"}}
```

**`toggle_grid_bubble` → `requires_transaction: true`** → `per_step`.

### 14.8 Element Numaralandırma — DismissDuplicate (scaddins Increment)

Numaralandırma sırasında Revit "Duplicate Number" dialog'u açar:

```csharp
// Dialog'u otomatik kapat
app.DialogBoxShowing += (o, e) => {
    if (e is MessageBoxShowingEventArgs msg &&
        msg.Message == "Elements have duplicate 'Number' values.")
        e.OverrideResult((int)TaskDialogResult.Ok);
};
```

EGBIMOTO manifestte `assign_egbim_mark` veya `door_number_by_room` op'ları bu dialog'u kendi içinde handle eder. **Dışarıdan ek bir adım gerekmez.**

---

## 15. Güncel Özet Tablo — Tüm Öğrenimler

| Kural | Kaynak | Manifest Etkisi |
|-------|--------|----------------|
| Level elevation toleransı < 0.01 ft | Sheet-level Creator | `create_level` mevcut kontrol yapar |
| Unit dönüşümü: proje biriminden feet'e | Sheet-level Creator | `unit` param her zaman belirt |
| Ad çakışması: `_{id}` suffix | Sheet-level Creator | otomatik — manifestte güven |
| Viewport: sheet outline merkezini hesapla | Sheet-level Creator | `position: "center"` default |
| Sheet kopyalama: viewport dict → copy → place | scaddins | `copy_sheet` op sırasını bilir |
| PDF export asenkron: WaitForFileAccess zorunlu | scaddins | `wait_for_file: true` |
| Export transaction_policy: none | scaddins | export sadece okuma |
| Naming: geçersiz karakter kaçınma | scaddins | `\/:*?"<>|` naming_rule'da yasak |
| Silme: IsValidObject + ActiveView kontrolü | scaddins DestructivePurge | `delete_generated` güvenli |
| Grid bubble: view koordinatına göre yön | scaddins GridManager | `side` param: left/right/top/bottom |
| Duplicate dialog: otomatik dismiss | scaddins Increment | `assign_mark` op handle eder |

---

## 16. AnalyzeTool + BatchIFC Exporter Analizi

### 16.1 MCP Bridge Mimarisi — TCP Transport (AnalyzeTool)

EGBIMOTO'nun MCP sunucusuyla aynı pattern: TCP localhost + JSON protocol.

**Önemli farklar ve öğrenimler:**

```
Protocol: { "id", "type":"invoke"|"list", "command", "payload" }
Response: { "id", "result": <any> } | { "id", "error": "message" }
```

- **Connect-per-request:** Her istek yeni bağlantı açar → persistent socket fragility yok
- **`IsCompleteJson` kontrol:** Byte'lar birikirken tam JSON oluşana kadar bekle (partial read koruması)
- **32 MB sanity cap:** Çok büyük payload'da null dön
- **Her exception yakalanır** — hiçbir şey Revit'i çökertmez

EGBIMOTO manifest'te büyük veri gönderirken:
```json
{"id": "export", "op": "export_xlsx", 
 "params": {"max_rows": 10000}}  ← payload cap koymak iyi practice
```

### 16.2 CommandDispatcher — Extension/Core Ayrımı (AnalyzeTool)

Op registration pattern — EGBIMOTO'nun op sistemi için referans:

```csharp
// Core op'lar: "op_name"
// Extension op'lar: "extension_id.op_name" (namespace collision önleme)
string name = string.IsNullOrEmpty(prefix) ? baseName : $"{prefix}.{baseName}";

// JSON Schema otomatik üretim:
string json = AIJsonUtilities.CreateJsonSchema(inputType).GetRawText();
if (json.Length > 4096) return permissive_schema; // şema çok büyükse basitleştir
```

**EGBIMOTO manifest'te op schema boyutu:** Op'ların input schema'sı 4096 karakter altında olmalı — çok karmaşık nested struct'lar AI'ı yanıltır. Parametre sayısı fazlaysa gruplayın.

**`ReadOnly` / `Destructive` flag'leri:**
```csharp
[RevitCommand(ReadOnly = false, Destructive = true)]
```

EGBIMOTO manifest'te:
```json
{"transaction_policy": "none"}   // → ReadOnly=true
{"transaction_policy": "atomic"} // → Destructive=false (rollback var)
{"transaction_policy": "per_step"} // → Destructive=true (kısmi yazma kalabilir)
```

### 16.3 AI + Revit Parametre Analizi (AnalyzeTool AiAnalysisService)

AI'a Revit verisi gönderme için öğrenilen kurallar:

**System prompt şeması** — AI'a gönderilecek element verisi:
```json
{
  "elementId": 123,
  "name": "parametre_adı",
  "value": "mevcut_değer",
  "level": "Kat 1",
  "storageType": "String|Integer|Double|ElementId",
  "isTypeParameter": true,
  "isReadOnly": false,
  "origin": "BuiltIn|Shared|Family"
}
```

**SetData yazma modları:**
```csharp
enum SetDataMode {
    Overwrite,     // her zaman yaz
    OnlyIfEmpty,   // sadece boşsa yaz
    SkipIfEqual    // mevcut değerle aynıysa atla
}
```

EGBIMOTO manifestlerde toplu parametre yazarken:
```json
{"id": "yaz", "op": "write_param_from_rows",
 "params": {
   "param_name": "TR_CSB_PozNo",
   "mode": "OnlyIfEmpty",  ← var olan değerleri korur
   "field": "poz_no"
 }}
```

**JSON parse fallback zinciri** (kısmi yanıt kurtarma):
1. `JsonSerializer.Deserialize<List<T>>(json)` — tam array
2. JSON içinde `[` bul, matching `]` bul, o kısmı parse et
3. Her `{...}` bloğunu ayrı ayrı parse et

EGBIMOTO'da AI manifest üretiminde de bu yaklaşım geçerli — AI kısmi JSON verirse yine de kurtarılabilir.

### 16.4 Element Collector — Token-Friendly Pattern (AnalyzeTool DataElementsCollectorService)

AI/MCP için verimli element toplama:

```csharp
// Kategori adından BuiltInCategory bul (case-insensitive)
Category? match = categories.FirstOrDefault(x =>
    x.Name.Equals(category, StringComparison.OrdinalIgnoreCase));
BuiltInCategory bic = match.BuiltInCategory;

// Hem instance hem type topla, birleştir
var instances = new FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType();
var types = new FilteredElementCollector(doc).OfCategory(bic).WhereElementIsElementType();
var all = instances.UnionWith(types);
```

**Parametre discovery:** Önce bir örnek element al, onun parametrelerini listele — AI hangi param'ların var olduğunu öğrenir:
```csharp
Element? sample = collector.OfCategory(bic).WhereElementIsNotElementType().FirstElement();
// sample'ın parametrelerini → CategoryParameterInfo listesi
```

EGBIMOTO manifest'te `search_parameters` op'u tam bunu yapıyor. Manifest'te parametreye erişmeden önce:
```json
{"id": "kesfet", "op": "search_parameters", 
 "params": {"category": "OST_Walls", "sample_only": true}}
```

### 16.5 Parametre Yazma — BuiltIn vs Shared vs Project (AnalyzeTool SetDataToParameters)

Parametre lookup sırası (kritik):

```csharp
if (ParameterUtils.IsBuiltInParameter(new ElementId(paramId))) {
    // 1. BuiltInParameter enum'ından direkt al
    parameter = element.get_Parameter((BuiltInParameter)paramId);
} else {
    // 2. Element.Parameters üzerinde Id eşleştir
    foreach (Parameter p in element.Parameters)
        if (p.Id.Value == paramId) { parameter = p; break; }
    
    // 3. ParameterElement'ten Definition al
    if (parameter == null) {
        var paramElem = doc.GetElement(new ElementId(paramId)) as ParameterElement;
        parameter = element.get_Parameter(paramElem.GetDefinition());
    }
}
```

EGBIMOTO `write_param` op'u bu sırayı takip eder. Manifest'te param_id her zaman sayısal Id ver:
```json
{"id": "yaz", "op": "write_param",
 "params": {"param_id": -1001040, "value": "TR_EGBIM_001"}} // BuiltIn: negatif
```
```json
{"id": "yaz", "op": "write_param",
 "params": {"param_id": 12345678, "value": "değer"}} // Shared/Project: pozitif
```

### 16.6 Batch IFC Export Pipeline (BatchIfcExporter)

Toplu IFC export için 2 aşamalı document açma:

**Aşama 1: Workset analizi**
```csharp
// Tüm workset'leri kapat, sadece metadata oku
openOptions.SetOpenWorksetsConfiguration(
    new WorksetConfiguration(WorksetConfigurationOption.CloseAllWorksets));
openOptions.DetachFromCentralOption = DetachFromCentralOption.DetachAndPreserveWorksets;
doc = App.OpenDocumentFile(modelPath, openOptions);
// → Workset listesini al, exclude pattern'e göre filtrele
doc.Close(false);
```

**Aşama 2: Seçili workset'lerle aç**
```csharp
var config = new WorksetConfiguration(WorksetConfigurationOption.CloseAllWorksets);
config.Open(worksetIdsToOpen); // sadece istenen workset'ler
openOptionsFinal.SetOpenWorksetsConfiguration(config);
doc = App.OpenDocumentFile(modelPath, openOptionsFinal);
```

**EGBIMOTO manifest:**
```json
{
  "transaction_policy": "none",
  "steps": [
    {"id": "dosyalar", "op": "find_rvt_files", "params": {"folder": "C:/Models"}},
    {"id": "export", "op": "export_ifc4_tr_bim", "from": "dosyalar",
     "params": {
       "workset_exclude_pattern": "Bağlantı",
       "view_name": "IFC Export",
       "output_folder": "C:/IFC_Output",
       "detach_from_central": true
     }, "required": false}
  ]
}
```

**Kritik hatırlatmalar:**
- `doc.Close(false)` → linked document ise ÇAĞIRMA (`doc.IsLinked` kontrol et)
- GC.Collect() + GC.WaitForPendingFinalizers() bellek temizler (batch işlemde önemli)
- `doc.IsValidObject` kullan, `IsClosed` değil (eski API)

### 16.7 IFC Mapping Guard — Autodesk Bug Workaround (BatchIfcExporter)

Revit 2026 IFC Exporter bug: İlk export'tan sonra mapping dosyasını değiştiriyor.

**Guard pattern:**
```csharp
// 1. MD5 hash al (orijinal)
var originalHash = ComputeFileHash(mappingFilePath);
// 2. Temp'e backup al
File.Copy(mappingFilePath, backupPath, overwrite: true);
// 3. Export yap
ExportIFC();
// 4. Hash kontrol et → değiştiyse restore
if (ComputeFileHash(mappingFilePath) != originalHash)
    File.Copy(backupPath, mappingFilePath, overwrite: true);
// 5. Dispose → backup sil
```

EGBIMOTO manifest'te IFC export öncesi mapping koruması:
```json
{"id": "guard", "op": "backup_mapping_file", 
 "params": {"mapping_path": "C:/EGBIM/mapping.txt"}},
{"id": "export", "op": "export_ifc4_tr_bim", "from": "topla"},
{"id": "restore", "op": "restore_mapping_file", "from": "guard", "required": false}
```

### 16.8 IFCExportConfiguration — Reflection ile Erişim (BatchIfcExporter)

`IFCExportConfiguration` public API'de yok — reflection gerekir:

```csharp
// Assembly yolu: <RevitDir>\AddIns\IFCExporterUI\Autodesk.IFC.Export.UI.dll
string expectedPath = Path.Combine(revitPath, @"AddIns\IFCExporterUI\Autodesk.IFC.Export.UI.dll");

// AppDomain'de ara, yoksa LoadFrom
Assembly loadedAssembly = AppDomain.CurrentDomain.GetAssemblies()
    .FirstOrDefault(a => a.Location == expectedPath)
    ?? Assembly.LoadFrom(expectedPath);

// CreateDefaultConfiguration → static method, reflection ile çağır
var method = configType.GetMethod("CreateDefaultConfiguration",
    BindingFlags.Public | BindingFlags.Static);
var config = method.Invoke(null, null);

// UpdateOptions → 2 overload var (yeni/eski Revit versiyonu)
// Önce yeni (Document, IFCExportOptions, ElementId, bool) dene
// Başarısız olursa eski (IFCExportOptions, ElementId) dene
```

EGBIMOTO'nun `export_ifc4_tr_bim` op'u bu reflection'ı kendi içinde yapıyor. Manifest'te ekstra adım gerekmez.

### 16.9 MSI Versiyon Kısıtlaması (BIM FamilyManager Installer)

Windows Installer MSI versiyon kuralı:
- Major < 256, Minor < 256, Build < 65536
- Revit versiyonu (örn. 2025) > 256 olduğu için `Major % 100` kullan

```csharp
return parsedVersion.Major > 256
    ? new Version(parsedVersion.Major % 100, parsedVersion.Minor, parsedVersion.Build)
    : parsedVersion;
// 2025.0.0 → 25.0.0
// 2026.1.0 → 26.1.0
```

EGBIMOTO dağıtım paketlerinde versiyon şeması: `26.x.x` formatı kullan, `2026.x.x` değil.

---

## 17. Güncel Özet Tablo — Tüm Repo Öğrenimleri

| Kural | Kaynak | EGBIMOTO Manifest/Op Etkisi |
|-------|--------|-----------------------------|
| TCP MCP: connect-per-request | AnalyzeTool | Bağlantı fragility yok |
| JSON parse: IsCompleteJson bekleme | AnalyzeTool | Partial read koruması |
| Op schema < 4096 char | AnalyzeTool | Karmaşık param'ları grupla |
| ReadOnly=none, Destructive=per_step | AnalyzeTool | TX policy ile flag ilişkisi |
| AI veri: storageType + origin + isReadOnly | AnalyzeTool | AI system prompt şeması |
| SetData mode: Overwrite/OnlyIfEmpty/SkipIfEqual | AnalyzeTool | write_param'a `mode` param |
| Param lookup: BuiltIn→Id→Definition | AnalyzeTool | param_id: negatif=BuiltIn |
| Element discovery: sample.Parameters | AnalyzeTool | search_parameters op'u |
| instances.UnionWith(types) | AnalyzeTool | hem instance hem type topla |
| Batch IFC: 2 aşamalı open | BatchIfcExporter | workset_exclude_pattern |
| doc.IsLinked → Close() çağırma | BatchIfcExporter | linked doc güvenli kapama |
| GC.Collect() batch sonrası | BatchIfcExporter | bellek temizleme |
| doc.IsValidObject (IsClosed değil) | BatchIfcExporter | geçerli doküman kontrolü |
| IFC Mapping Guard: hash + backup | BatchIfcExporter | mapping koruması |
| IFCExportConfig: reflection | BatchIfcExporter | op içinde yapılır, manifest'e gerek yok |
| MSI versiyon: Major % 100 | FamilyManager | 2026→26, 2025→25 |

---

## 18. BIMBotPlugin — AI + Revit Tam Entegrasyon Analizi

BIMBotPlugin, EGBIMOTO ile en yakın mimari benzerliktedir: MCP tabanlı, AI function calling, Revit komut dispatcher. Çok kritik öğrenimler içeriyor.

### 18.1 Pagination / Delta-Sync Pattern (CommandExecutor)

Büyük veri setlerini AI'a göndermek için zorunlu pattern:

```csharp
// Her collection çağrısında: offset + limit + hasMore
var allElements = collector.WhereElementIsNotElementType().ToElements();
var totalCount = allElements.Count;
var subset = offset > 0 ? allElements.Skip(offset) : elements;
if (limit > 0) subset = subset.Take(limit);

return new JObject {
    ["totalCount"] = totalCount,
    ["count"] = result.Count,
    ["offset"] = offset,
    ["limit"] = limit,
    ["hasMore"] = (offset + result.Count) < totalCount,
    ["elements"] = result
};
```

**Delta-sync için kullanılan parametreler:**
- `element.UniqueId` → GUID (modeller arası kararlı ID)
- `EDITED_BY` BuiltInParameter → workshared modelde kimin ne zaman düzenlediği
- `modifiedAfter` → ISO 8601 tarih filtresi

EGBIMOTO manifest'te büyük koleksiyonlar için:
```json
{"id": "topla", "op": "collect_elements",
 "params": {
   "category": "OST_Walls",
   "offset": 0,
   "limit": 100,
   "include_guid": true
 }}
```

**`hasMore: true` ise bir sonraki adım:**
```json
{"id": "topla2", "op": "collect_elements",
 "params": {"category": "OST_Walls", "offset": 100, "limit": 100}}
```

### 18.2 AI Function Calling Loop Kontrolü (ChatOrchestrator)

AI araç çağrısı sonsuz döngüye girebilir. Kritik guard pattern'leri:

```csharp
const int MaxToolCalls = 30;          // toplam araç çağrısı limiti
const int MaxSameToolCalls = 10;      // aynı araç için maksimum
const int MaxConsecutiveRepeats = 3;  // aynı imzayla art arda maksimum

// İmza: "araç_adı:argümanlar_json"
var currentSignature = $"{fc.Name}:{fc.Arguments?.ToString()}";
if (currentSignature == lastToolSignature) {
    consecutiveRepeats++;
    if (consecutiveRepeats >= MaxConsecutiveRepeats) {
        // AI'a düzeltici mesaj gönder
        var loopMsg = { "error": "Loop detected: ... Stop repeating." };
        response = await gemini.SendFunctionResultAsync(fc.Name, loopMsg);
        break;
    }
}
```

EGBIMOTO manifest tasarımında döngüden kaçınmak için:
- Collect op'ları `limit` ile sınırla
- Her adımda farklı `from` kullan
- `from_many` ile fan-in, tekrar eden collect'ten kaçın

### 18.3 Kapsamlı Komut Kataloğu — EGBIMOTO Op Haritası

BIMBotPlugin'in ~180 komutu EGBIMOTO op'larıyla örtüşüyor. Manifest yazarken kullanılacak op isimleri:

**Okuma (transaction_policy: "none"):**
```
get_current_view_info → collect_active_view
get_elements         → collect_elements (category, offset, limit)
get_parameters       → search_parameters (elementId)
get_views            → collect_views (viewType alias: "3D"→ThreeD, "Plan"→FloorPlan)
get_sheets           → collect_sheets
get_levels           → get_levels
get_rooms            → collect_rooms
get_warnings         → get_model_warnings
get_model_statistics → model_statistics
```

**View type alias'ları (BIMBotPlugin'den öğrenildi):**
| Alias | Gerçek ViewType |
|-------|----------------|
| `"3D"` | `ThreeD` |
| `"Plan"` | `FloorPlan` |
| `"RCP"` | `CeilingPlan` |
| `"Ceiling"` | `CeilingPlan` |

**Yazma (transaction_policy: "per_step"):**
```
create_wall           → create_wall (startX,startY,endX,endY,levelName,height)
create_level          → create_level (name,elevation) — duplicate kontrolü built-in
create_grid           → create_grid (startX,startY,endX,endY,name)
create_room           → create_room (x,y,levelName,roomName,roomNumber)
create_sheet          → create_sheet (sheetNumber,sheetName,titleBlockName)
create_floor          → create_floor (points:[{x,y}],levelName,floorType)
create_view           → create_view (viewType,levelName,viewName)
```

**Düzenleme (transaction_policy: "per_step"):**
```
modify_element        → write_param (parameterName,value) veya view properties
move_element          → move_element (deltaX,deltaY,deltaZ)
delete_elements       → delete_generated (elementIds)
copy_element          → copy_element (deltaX,deltaY,deltaZ,count)
rotate_element        → rotate_element (angle°, centerX,centerY)
mirror_element        → mirror_element (axisStartX/Y, axisEndX/Y, keepOriginal)
change_type           → set_element_type (newTypeName)
set_workset           → set_workset (elementIds, worksetName)
batch_modify_parameters → write_param_from_rows (elementIds,parameterName,value)
color_elements        → color_elements (category,parameterName) — 10 renk paleti
```

### 18.4 Wall Oluşturma — Minimum Mesafe Kontrolü (CommandExecutor)

```csharp
if (start.DistanceTo(end) < 0.001)
    throw new InvalidOperationException("Wall start and end points are too close (must be > 0.001 ft apart)");
```

EGBIMOTO `create_wall` op'u bu kontrolü yapar. Manifestte koordinatları her zaman feet cinsinden ver veya `unit` parametresiyle belirt.

### 18.5 Renk Kodlama — Solid Fill Pattern (CommandExecutor ColorElements)

Parametre değerine göre renk kodlama:

```csharp
// 10 renkli palet (Tomato, MediumSeaGreen, RoyalBlue, Orange, MediumOrchid, ...)
var colors = new[] { new Color(255,99,71), new Color(60,179,113), ... };

// Solid fill pattern bul
var solidFill = new FilteredElementCollector(doc)
    .OfClass(typeof(FillPatternElement))
    .Cast<FillPatternElement>()
    .FirstOrDefault(f => f.GetFillPattern().IsSolidFill);
if (solidFill != null)
    ogs.SetSurfaceForegroundPatternId(solidFill.Id);
```

EGBIMOTO manifest'te color_elements için solid fill pattern otomatik bulunur:
```json
{"id": "renkle", "op": "color_elements",
 "params": {
   "category": "OST_Rooms",
   "param_name": "Department",
   "use_solid_fill": true
 }}
```

### 18.6 Dinamik C# Kodu Çalıştırma — Roslyn (CodeExecutor)

AI tarafından üretilen C# kodunu runtime'da derleme ve çalıştırma:

```csharp
// Kod şablonu: AI sadece body yazar
var fullSource = $@"
using System; using System.Linq; using Autodesk.Revit.DB; ...
public class DynamicRevitCode {{
    public object Run(UIApplication __uiapp__, UIDocument __uidoc__, Document __doc__) {{
        var doc = __doc__; var uidoc = __uidoc__; // friendly aliases
        {codeBody}  // AI'ın yazdığı kod buraya
    }}
}}";
```

**.NET 8 izolasyon sorunu** (Revit 2025/2026):
```csharp
// Dynamo'nun Roslyn assembly'si çakışıyor → AssemblyLoadContext ile izole et
var context = new AssemblyLoadContext("BIMBotRoslyn", isCollectible: true);
rCSharp = context.LoadFromAssemblyPath(csharpDllPath);
```

**Hata mesajında hint:**
- Derleme hatası: `"Note: In Revit 2025+, use new ElementId((long)value) instead of new ElementId((int)value)"`
- Runtime hatası: Stack trace'in ilk 5 satırı

EGBIMOTO'da `execute_code` / `send_code_to_revit` op'u bu yapıyı kullanır. Manifest'te:
```json
{"id": "kod", "op": "execute_code",
 "params": {
   "code": "var walls = new FilteredElementCollector(doc).OfClass(typeof(Wall)).ToElements(); return walls.Count;",
   "description": "Duvar sayısını döndür"
 }}
```

### 18.7 Linked Model Seçimi — SetReferences (CommandExecutor SelectElements)

Linked model elemanlarını seçmek için `SetReferences` gerekli (`SetElementIds` sadece host):

```csharp
// Host elemanlar için normal Reference
selectionRefs.Add(new Reference(hostElement));

// Linked elemanlar için CreateLinkReference
var linkRef = new Reference(linkedElem).CreateLinkReference(linkInstance);
selectionRefs.Add(linkRef);

// SetReferences her ikisini de destekler
uidoc.Selection.SetReferences(selectionRefs);

// Fallback: sadece host'u seç
uidoc.Selection.SetElementIds(hostIds);
```

EGBIMOTO manifest:
```json
{"id": "sec", "op": "select_elements",
 "params": {
   "element_ids": [123, 456],
   "include_linked": true,
   "isolate": false
 }}
```

### 18.8 Workset'e Eleman Atama — ELEM_PARTITION_PARAM

```csharp
// Workset bul
var worksets = new FilteredWorksetCollector(doc)
    .OfKind(WorksetKind.UserWorkset).ToWorksets();
var target = worksets.FirstOrDefault(w => w.Name == worksetName);

// Eleman workset'ini değiştir
var wsParam = elem.get_Parameter(BuiltInParameter.ELEM_PARTITION_PARAM);
if (wsParam != null && !wsParam.IsReadOnly)
    wsParam.Set(target.Id.IntegerValue);
```

EGBIMOTO manifest:
```json
{"id": "workset", "op": "set_workset",
 "params": {
   "element_ids": [123, 456],
   "workset_name": "Structure"
 }}
```

`requires_transaction: true` → `per_step`.

### 18.9 Phase Atama — PHASE_CREATED

```csharp
var phCreated = elem.get_Parameter(BuiltInParameter.PHASE_CREATED);
if (phCreated != null && !phCreated.IsReadOnly)
    phCreated.Set(targetPhase.Id);
```

Phase adından Phase Id'ye çözüm:
```csharp
foreach (Phase ph in doc.Phases)
    if (ph.Name == phaseName) { targetPhase = ph; break; }
```

EGBIMOTO manifest:
```json
{"id": "faz", "op": "set_phase",
 "params": {"element_ids": [...], "phase_name": "Yeni İnşaat"}}
```

### 18.10 Chat Geçmişi — Proje Bazında Yönetim

```csharp
// Proje değiştiğinde: mevcut geçmişi kaydet, yeni projenin geçmişini yükle
if (_projectPath != projectPath) {
    SaveChatHistory();      // JSON'a yaz
    _projectPath = projectPath;
    _chatLog.Clear();
    _gemini.ClearHistory(); // AI konuşma geçmişini de sıfırla
    LoadChatHistory();      // Yeni projenin geçmişini yükle
}
```

EGBIMOTO'nun `observations/` sistemi buna benzer — her model için ayrı kalibrasyon verisi. Manifest yazarken aktif model `EG_OTEL_ERTUGAN_detached` için özelleştirilmiş zincirler gerekmez; genel op'lar yeterli.

---

## 19. Nihai Manifest Yazım Kılavuzu — Konsolide

Bu dosyayı okuduktan sonra manifest yazmak için:

### Adım 1: Amacı tanımla
```
QA/Doğrulama → transaction_policy: "none"
Yazma/Düzenleme → transaction_policy: "per_step"
Karma (collect+write) → per_step
Export → none
```

### Adım 2: Step sırası
```
pre_check → collect → filter/transform → validate/compute → write/export
```

### Adım 3: Domain köprüsü kontrol
```
collect_* → Structural/Elements
  → elements_to_rows → filter_rows/show_table/export
```

### Adım 4: Op listesi kontrol
- Op `op_contracts.json`'da var mı?
- `requires_transaction: true` mu? → per_step
- `domain_out` → sonraki adımın `domain_in_accepts` ile uyumlu mu?

### Adım 5: Güvenlik
```json
{"required": false}  // Export/rapor adımlarına
{"limit": 100}       // Büyük koleksiyonlara
```

---

## 20. BIMaestro — Fransız Revit Plugin Paketi Analizi

### 20.1 Element Geçmişi Takibi — Snapshot + Delta (ElementHistoryTracker)

Element değişikliklerini izleme — EGBIMOTO'nun `trace_write` / `observations` sistemine benzer:

```csharp
class ElementSnapshot {
    public string UniqueId { get; set; }    // kararlı ID
    public string Category { get; set; }
    public string Family { get; set; }
    public string TypeName { get; set; }
    public XYZ Location { get; set; }
    public BoundingBoxXYZ BBox { get; set; }
    public Dictionary<string, string> Parameters { get; set; }
    public DateTime LastLogged { get; set; }
}

class ElementHistoryEvent {
    public string Action { get; set; }  // "Created"|"Modified"|"Deleted"
    public string User { get; set; }
    public string Tx { get; set; }      // Transaction adı
    public Dictionary<string, object> Delta { get; set; }  // değişen parametreler
}
```

**Ghost Mesh (silinmiş elemanlarda görsel iz):** En büyük yüzeyli 500 triangle sakla, önizleme için 100'e indir. Triangle deduplication için vertex key hash kullan.

EGBIMOTO manifest'te:
```json
{"id": "snap", "op": "trace_write",
 "params": {
   "include_parameters": true,
   "include_geometry": false,
   "delta_only": true
 }}
```

### 20.2 Boru Ağı Otomatik Bağlantı — A* Routing (ConnectPipesCommand)

Boru bağlantı algoritması — EGBIMOTO'nun `connect_mep_elements` op'u için referans:

**DN'ye bağlı dinamik parametreler:**
```csharp
double clearMm = Math.Max(25, dnMm * 0.5 + Clamp(dnMm * 0.05, 15, 50)); // clearance
double snapTolMm = Clamp(dnMm * 0.06, 20, 60);  // snap tolerance
double minSegMm = Math.Max(120, dnMm * 1.5);      // min segment uzunluğu
double gridFastMm = Clamp(dnMm * 0.9, 250, 450);  // A* hızlı grid
double gridFineMm = Clamp(dnMm * 0.65, 180, 320); // A* ince grid
```

**4 route candidate + preview:**
1. Ortogonal X→Y→Z
2. Ortogonal Y→X→Z
3. A* hızlı grid
4. A* ince grid
5. Duvar çevresinden dolaşma

**Önizleme → Kullanıcı seçimi → Gerçek boru oluşturma:**
```csharp
// Önizleme (geçici ModelCurves ile):
using (var tPrev = new Transaction(doc, "Aperçu")) {
    for (int i = 0; i < routes.Count && i < 4; i++)
        CreatePreviewModelCurves(doc, routes[i].Points, colors[i], activeView);
}

// Kullanıcı seçimi
int chosen = PickPreviewRouteIndex(uidoc, previews);

// Gerçek boru + raccordlar (tek transaction)
using (var t = new Transaction(doc, "Connecter")) {
    // Delete preview + create real pipes + create fittings
}
```

**Té yerleştirme — BreakCurve:**
```csharp
ElementId partId = PlumbingUtils.BreakCurve(doc, main.Id, foot);
doc.Regenerate(); // zorunlu
// main → 2 parça (mainA, mainB)
doc.Create.NewTeeFitting(cA, cB, branchEnd);
```

EGBIMOTO manifest:
```json
{
  "transaction_policy": "per_step",
  "steps": [
    {"id": "borular", "op": "collect_elements", "params": {"category": "OST_PipeCurves"}},
    {"id": "rota", "op": "calc_pipe_route", "from": "borular",
     "params": {"algorithm": "astar", "grid_mm": 300, "clear_mm": 50}},
    {"id": "bagla", "op": "connect_mep_elements", "from": "rota",
     "params": {"create_fittings": true, "allow_tee": true}}
  ]
}
```

### 20.3 MEP Traversée Rezervasyon — AutoConfig (ReservationAutoV3Command)

MEP geçiş rezervasyonu — EGBIMOTO'nun `place_opening` + `mep_opening_detect` kombinasyonu:

**Aile otomatik konfigürasyonu (mevcut projeden çözümleme):**
```csharp
// Aile adı prefix'ini temizle
string current = RemoveCmlPrefix(familyName); // "CML_" prefix'ini sil
// OrdinalIgnoreCase karşılaştırma
bool match = current.IndexOf(expected, StringComparison.OrdinalIgnoreCase) >= 0;
```

**Parametre otomatik haritalama:**
```csharp
// Family symbol'ün tüm parametre adlarını oku
var names = sym.Parameters.Cast<Parameter>()
    .Select(x => x.Definition?.Name)
    .Where(n => !string.IsNullOrWhiteSpace(n))
    .ToList();
// Aday isim listesiyle eşleştir (Largeur/Width/Larg → genişlik parametresi)
```

**Host tipleri:**
- `Wall` → dikey rezervasyon (dikdörtgen/dairesel)
- `Floor` → yatay rezervasyon (dikdörtgen/dairesel)

**Dynamo entegrasyonu:**
```csharp
if (win.DynamoAutoEnabled && !string.IsNullOrWhiteSpace(cfg.DynamoPath))
    TryRunDynamo(data, cfg.DynamoPath);
```

EGBIMOTO manifest:
```json
{
  "transaction_policy": "per_step",
  "steps": [
    {"id": "kesisim", "op": "mep_opening_detect",
     "params": {"scope": "EntireProject", "host_categories": ["OST_Walls","OST_Floors"]}},
    {"id": "rez", "op": "place_opening", "from": "kesisim",
     "params": {
       "family_name_candidates": ["CML_Réservation", "Réservation murale", "EGBIM_Rezervasyon"],
       "auto_map_params": true,
       "skip_existing": true
     }}
  ]
}
```

### 20.4 Model Ağırlık Analizi — Disk Arama (CommandAnalysePoids)

Revit dosya ağırlığı analizi — dosya boyutunu sınırlı sürede bul:

**Arama limitleri:**
```csharp
TimeSpan FileSearchTimeLimit = TimeSpan.FromSeconds(20);  // 20 sn max
int FileSearchMaxVisitedFiles = 60000;                     // 60K dosya max
```

**Import tiplerine göre dosya adı toplama:**
```csharp
// 1. DWG/CAD → ImportInstance → IMPORT_SYMBOL_NAME
// 2. PDF/Image → ImageInstance → GetTypeId → RASTER_SYMBOL_FILENAME
// 3. RevitLink → GetExternalFileReference() → reflection ile
// 4. PointCloud → PointCloudInstance → "Point Cloud File Path" | "Chemin du fichier"
```

**Nokta bulutu parametre adları (Türkçe/Fransızca/İngilizce fallback):**
```csharp
var pcParamKeys = new[] {
    "Point Cloud File Path",
    "Source File Path",
    "Chemin du fichier nuage de points",  // Fransızca
    "Chemin du fichier source",
};
```

EGBIMOTO manifest'te import analizi:
```json
{"id": "analiz", "op": "collect_elements",
 "params": {
   "categories": ["OST_ImportSymbol", "OST_RasterImages", "OST_RvtLinks"],
   "include_file_path": true
 }}
```

### 20.5 Bağlantıcı Eleman Pin (PinScope) — Geçici Kilit

Bride yerleştirme sırasında elemanı geçici kilitle:

```csharp
internal sealed class PinScope : IDisposable {
    private readonly FamilyInstance _fi;
    private readonly bool _prev;    // önceki pin durumu
    private readonly bool _changed;

    public PinScope(Element e) {
        _fi = e as FamilyInstance;
        if (_fi == null) return;
        _prev = _fi.Pinned;
        if (!_fi.Pinned) { _fi.Pinned = true; _changed = true; }
    }

    public void Dispose() {
        if (_fi == null || !_changed) return;
        _fi.Pinned = _prev;  // orijinal durumu geri yükle
    }
}

// Kullanım:
using (var pin = new PinScope(element)) {
    // element pinliyken işlem yap
}  // dispose → orijinal pin durumu geri yüklenir
```

EGBIMOTO'da `place_family` veya `place_opening` sırasında hedef eleman geçici olarak pinlenir. Manifest'te ayrıca belirtmeye gerek yok — op içinde yapılır.

### 20.6 MEP Connectör Tespiti — Domain Filtresi

MEP elemanlarında sadece Piping connectörlerini filtrele:

```csharp
// Bir elemanın Piping connectörü var mı?
bool HasPipingConnectors(FamilyInstance fi) {
    var cm = fi.MEPModel?.ConnectorManager;
    if (cm == null) return false;
    foreach (Connector c in cm.Connectors)
        if (c.Domain == Domain.DomainPiping) return true;
    return false;
}

// Kategori + Domain çift filtresi
int cat = e.Category.Id.GetIdValue();
bool okCat = cat == (int)BuiltInCategory.OST_PipeAccessory ||
             cat == (int)BuiltInCategory.OST_MechanicalEquipment;
if (!okCat) return false;
// + DomainPiping kontrol
```

EGBIMOTO manifest'te MEP toplarken:
```json
{"id": "mep", "op": "collect_mep_elements",
 "params": {
   "categories": ["OST_PipeAccessory", "OST_MechanicalEquipment"],
   "domain_filter": "DomainPiping"
 }}
```

### 20.7 Schedule Excel IO — BuiltIn Enum Compat (ScheduleExcelIO)

Revit 2023/2025 arası BuiltInParameter enum uyumluluğu:

```csharp
internal static class EnumCompat {
    // BIP int ID → enum güvenli dönüşüm
    public static bool IsDefinedBip(int rawId) {
        var underlying = Enum.GetUnderlyingType(typeof(BuiltInParameter));
        object boxed = Convert.ChangeType(rawId, underlying);
        return Enum.IsDefined(typeof(BuiltInParameter), boxed);
    }

    public static BuiltInParameter ToBip(int rawId) {
        object boxed = Convert.ChangeType(rawId, Enum.GetUnderlyingType(typeof(BuiltInParameter)));
        return (BuiltInParameter)Enum.ToObject(typeof(BuiltInParameter), boxed);
    }
}
```

**Parametre lookup sırası (en güvenilir):**
```csharp
// 1. BuiltInParameter → get_Parameter(bip)
// 2. ParameterElement → GetDefinition() → get_Parameter(def)
// 3. İsimle → LookupParameter(name)
// Her birini önce instance, sonra type'ta dene
```

**UnitFormatUtils.TryParse — reflection ile versiyon uyumu:**
```csharp
// Revit 2025: TryParse(units, specId, text, null, out double) → 5 param
// Revit 2023: TryParse(units, specId, text, out double) → 4 param
// Reflection ile ikisini de dene
```

### 20.8 Çift Tıklama Tespiti — Timer ile (ColoringStateManager)

Tek/çift tıklama ayrımı — ExternalCommand içinde:

```csharp
const int DoubleClickThresholdMs = 300;
static bool _waitingForDoubleClick = false;
static Timer _singleClickTimer = null;

// İlk tıklama: timer başlat
_singleClickTimer = new Timer(SingleClickAction, commandData, 300, Timeout.Infinite);

// İkinci tıklama 300ms içinde gelirse:
_singleClickTimer?.Dispose();
DoDoubleClick(commandData);  // çift tık eylemi
```

EGBIMOTO'da bu pattern kullanılmaz — manifest adımları sıralı çalışır. Ancak `interaktif/` manifest'lerde kullanıcı seçimini bekleme için `pause_for_input` op'u benzer amaç taşır.

### 20.9 Zaman Takibi — Activity Monitor (ExcelLogger)

Revit kullanım süresi takibi:

```csharp
// Document key: PathName veya Title (benzersizliği sağla)
string BuildDocumentKey(Document doc) =>
    !string.IsNullOrEmpty(doc.PathName) ? doc.PathName : doc.Title;

// Olaylar: DocumentOpened, DocumentClosing, ViewActivated, OnIdling
// Idling'de ActivityMonitor güncellenir: BecameInactive/BecameActive

// Snapshot: her dakika (heartbeat)
TimeSpan SnapshotHeartbeatInterval = TimeSpan.FromMinutes(1);
// Crash recovery: temp dosyadan snapshot geri yükle

// Mutex ile çoklu Revit process güvenliği:
const string StorageMutexName = "BIMaestro_TimeLogger_Storage_v2";
```

EGBIMOTO'da model açık tutma süresi takibi için benzer bir event subscription zinciri:
```csharp
// Application.DocumentOpened += OnOpened
// Application.DocumentClosing += OnClosing
// Application.ViewActivated += OnViewActivated
// Application.Idling += OnIdling (Activity Monitor)
```

### 20.10 Metin Düzeltme — AI Chunk Pipeline (CorrectionResultWindow)

Büyük veri setini AI'ya chunk'lar halinde gönderme:

```csharp
// "Aucune correction nécessaire" yanıtlarını filtrele
bool isNoCorrection =
    expl.Contains("aucune correction nécessaire") ||
    expl.Contains("texte correct") ||
    string.Equals(origTrim, corrTrim, StringComparison.OrdinalIgnoreCase);

// Deduplication key:
string uniqueKey = $"{elementId}||{originalText}||{correctedText}";

// Progressif display: her chunk geldiğinde UI güncelle
UpdateProgressBar(percent);
AddPartialResults(key, corrections);
```

EGBIMOTO'da AI destekli parametre analizi için:
```json
{"id": "metin", "op": "collect_text_notes"},
{"id": "kontrol", "op": "ai_text_check", "from": "metin",
 "params": {
   "chunk_size": 50,
   "filter_no_change": true,
   "deduplicate": true
 }}
```

---

## 21. Nihai Tablo — BIMaestro Özet

| Öğrenim | EGBIMOTO Manifestine Etkisi |
|---------|---------------------------|
| Ghost mesh: büyük→küçük triangle decimation | Görsel iz trace: geometry=false varsayılan |
| A* routing: DN'ye bağlı dinamik grid | connect_mep_elements: clearance DN'den hesaplanır |
| Preview route → kullanıcı seçimi → gerçek boru | Interaktif manifest: pause_for_input |
| BreakCurve + Regenerate → NewTeeFitting | place_opening: per_step + regenerate_doc |
| PinScope: geçici pin/unpin | Op içinde otomatik yönetilir |
| HasPipingConnectors: Domain.DomainPiping filtresi | collect_mep_elements: domain_filter param |
| BIP enum compat: reflection ile TryParse | search_parameters: internal compat |
| Çift tıklama: 300ms Timer | Interaktif manifest: pause_for_input |
| Activity monitor: Idling + heartbeat | trace_write: requires_transaction=true → per_step |
| AI chunk pipeline: filtre + dedup | ai_text_check: chunk_size + filter_no_change |

---

# 22. V18 PRO1 DENETİMİ — YENİ ÖĞRENİLEN KURALLAR (2026-07)

Bu bölüm, V18 skill/manifest tam denetiminde C# kaynak kodu okunarak doğrulanan
kuralları içerir. Bunlar op_contracts.json'daki inferred bilgilerin ÜZERİNDE otoritedir.

## 22.1 KRİTİK — Step parametreleri "inputs" alanına yazılır, "params" DEĞİL

ManifestModel.cs gerçeği:
```csharp
[JsonPropertyName("inputs")]
public Dictionary<string, object?>? Params { get; set; }     // ← ANA ALAN

[JsonPropertyName("params")]
public Dictionary<string, object?>? ParamsLegacy              // ← sadece inputs YOKSA
{
    get => null;
    set { if (Params == null && value != null) Params = value; }
}
```

**KURAL:** Manifest step'lerinde parametre HER ZAMAN `"inputs": {...}` içine yazılır.
`"params"` legacy fallback'tir. İkisi birlikte yazılırsa `params` SESSIZCE YOK SAYILIR.

```json
// DOĞRU
{"id": "xlsx", "op": "export_xlsx", "from": "satirlar",
 "inputs": {"file_path": "C:\\rapor.xlsx", "sheet_name": "Rapor"}}

// YANLIŞ — params ignore edilir, export Desktop'a varsayılan adla gider
{"id": "xlsx", "op": "export_xlsx", "inputs": {},
 "params": {"file_path": "C:\\rapor.xlsx"}}
```

## 22.2 KRİTİK — Export op'larının GERÇEK parametre adları

| Op | Yol parametresi | Diğer parametreler | Not |
|----|----------------|--------------------|----|
| export_xlsx | **file_path** (output_path DEĞİL) | sheet_name, title | boş=Desktop |
| export_html_report | **YOK** — otomatik kaydet+aç | title | dosya yolu verilemez |
| export_validation_report | **file_path** | title | Report domain alır |
| export_csv | file_path | — | |
| csv_write | file_path* (zorunlu) | delimiter, encoding | utf-8-sig TR desteği |
| ifc_export | **output_dir + file_name** (output_folder DEĞİL) | export_linked_files | |
| kalip_export_xlsx | **filename + out_dir** | — | 3 sekmeli BOQ |
| kalip_report | **out_dir** | open_browser | KalipResult domain |
| mep_opening_bcf_export | output_path* (zorunlu) | sadece_kritik, durum_filtresi | BCF 2.1 |
| facade_export_schedule | output_path* | — | |

**Genel kural:** Skill/manifest yazmadan önce op_contracts.json'dan `params` listesini OKU.
Aynı kavram farklı op'larda farklı isimde: file_path / output_path / output_dir / out_dir / filename.

## 22.3 KRİTİK — calc_cost quantity_field

`calc_cost` varsayılanı `quantity_field: "hacim_m3"`.
Kalıp zincirinde kalip_all/kalip_wall çıktısı **kalip_m2** alanı üretir.

```json
// Kalıp maliyeti — quantity_field verilmezse 0 TL döner!
{"id": "maliyet", "op": "calc_cost", "from": "poz",
 "inputs": {"quantity_field": "kalip_m2"}}
```

Beton metrajı → hacim_m3 (varsayılan yeter). Kalıp → kalip_m2 ZORUNLU.

## 22.4 validate_rebar_ts500 parametresi "fck", "fc" DEĞİL

```json
{"id": "kontrol", "op": "validate_rebar_ts500", "from": "donati",
 "inputs": {"fck": 30, "fyk": 420, "cover_mm": 30}}
```

## 22.5 op_contracts.json inference hataları — kaynak kod otoritedir

generate_op_contracts.py bazı domain'leri yanlış çıkarır. Doğrulanmış düzeltmeler:

| Op | Contracts (yanlış) | Kaynak kod (doğru) |
|----|--------------------|--------------------|
| filter_by_level | domain_out: Rows | List\<Element\> → **Elements** |
| structural_ts500_section | Scalar | List\<Dictionary\> → **Rows** |
| structural_continuity_check | Scalar | **Rows** |
| structural_level_summary | Scalar | **Rows** |
| structural_material_check | Scalar | **Rows** |
| selection_to_elements | (eksik) | **Elements** |

**Kural:** SEM-HATA gördüğünde önce C#'taki dönüş tipine bak (`public static List<Dictionary...`),
contracts'a körü körüne güvenme. Gerçek dönüş tipi Rows ise zincir çalışır.

## 22.6 Attribute'lu op'lar contracts'ta eksik olabilir

`translate_params` — TranslateParamsOp.cs'te `[EgOp("translate_params")]` ile kayıtlı,
runtime'da ÇALIŞIR, ama op_contracts.json'da yok (generate script Addin assembly'sindeki
yeni dosyaları taramamış). Linter "op tanımsız" der ama DagExecutor sorunsuz çalıştırır.

**Kural:** "OP TANIMSIZ" linter hatası alırsan önce `grep -rn 'EgOp("op_adi"' src/` yap.
Attribute varsa manifest çalışır; contracts'ı yeniden generate et.

## 22.7 Gerçek op adları — yanlış isim tablosu

| Yanlış (hayal edilen) | Doğru (kayıtlı) |
|----------------------|------------------|
| struct_ts500_section | structural_ts500_section |
| collect_mep_elements | collect_electrical_equipment / collect_pipes / collect_ducts (spesifik) |
| kalip_merge | merge_rows (KalipResult=List\<Dict\> olduğu için çalışır) |
| kalip_beam | YOK — kirişler kalip_all içinde hesaplanır |

## 22.8 4D yazma pipeline'ı — schedule_gate + condition zorunlu

```json
{"transaction_policy": "per_step",
 "steps": [
   {"id": "elemanlar", "op": "collect_elements"},
   {"id": "schedule",  "op": "schedule_collect_4d", "from": "elemanlar"},
   {"id": "gate",      "op": "schedule_gate", "from": "schedule"},
   {"id": "yaz",       "op": "set_param_from_schedule", "from": "elemanlar",
    "condition": "$gate == confirmed",
    "inputs": {"schedule_step": "schedule"}}
 ]}
```
- `set_param_from_schedule` elemanları `from`'dan, schedule DTO'sunu `inputs.schedule_step`
  (step ID referansı) üzerinden vars'tan alır.
- Gate onaysız yazma YAPILMAZ → condition şart.

## 22.9 Rapor kalitesi standardı — her analitik skill'de 3 çıktı

1. `show_table` — WPF anlık tablo ('Modelde Göster' + CSV butonlu), max_rows: 500
2. `export_validation_report` (Report domain) VEYA `export_html_report` (Rows domain) — HTML
3. `export_xlsx` — arşiv/paylaşım, sheet_name + title ver

Hepsi `required: false` — export başarısızlığı hesabı durdurmaz.

## 22.10 Report → HTML yolu ikilidir

- ValidationReport → **export_validation_report** (file_path, title) — DOĞRU
- Rows → **export_html_report** (sadece title, yol verilemez) — DOĞRU
- ValidationReport → export_html_report — SEM-HATA (Report ≠ Rows)
- Araya validation_to_rows koyarsan Rows yoluna geçebilirsin.
