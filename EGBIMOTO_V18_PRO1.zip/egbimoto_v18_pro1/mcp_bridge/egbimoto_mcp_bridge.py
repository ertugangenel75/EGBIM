#!/usr/bin/env python3
"""
EGBIMOTO MCP Köprüsü — V17
============================
Claude Desktop ↔ EGBIMOTO Revit Server (HTTP :5577)

V17: +3 araç (list_skills, get_skill, run_skill) = 16 araç toplam

AKIŞ (V17 önerilen):
  1. egbimoto_list_skills()          → hangi skill var?
  2. egbimoto_get_skill("skill_id")  → parametreler neler?
  3. egbimoto_run_skill(...)         → preview=True → kullanıcı onayı → preview=False
"""
import os, sys, json, asyncio
from typing import Any
import httpx

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
except ImportError:
    sys.stderr.write("HATA: pip install mcp httpx\n"); sys.exit(1)

EGBIMOTO_HOST  = os.environ.get("EGBIMOTO_HOST",  "127.0.0.1")
EGBIMOTO_PORT  = os.environ.get("EGBIMOTO_PORT",  "5577")
EGBIMOTO_TOKEN = os.environ.get("EGBIMOTO_TOKEN", "")
BASE_URL       = f"http://{EGBIMOTO_HOST}:{EGBIMOTO_PORT}"
HTTP_TIMEOUT   = float(os.environ.get("EGBIMOTO_TIMEOUT", "180"))
app = Server("egbimoto")

def _headers():
    h = {"Content-Type": "application/json"}
    if EGBIMOTO_TOKEN: h["X-EGBIMOTO-Token"] = EGBIMOTO_TOKEN
    return h

async def _get(path, params=None):
    async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as c:
        r = await c.get(f"{BASE_URL}{path}", headers=_headers(), params=params)
        return r.status_code, r.text

async def _post(path, body):
    payload = json.dumps(body, ensure_ascii=False) if not isinstance(body, str) else body
    async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as c:
        r = await c.post(f"{BASE_URL}{path}", headers=_headers(), content=payload.encode())
        return r.status_code, r.text

@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        # ── Temel (V15.1) ─────────────────────────────────────────────────────
        Tool(name="egbimoto_health",
             description="EGBIMOTO server durumu ve aktif Revit dokümanı.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="egbimoto_list_ops",
             description="480 op katalogu. Oturum başında bir kez çağır. V17'de genellikle list_skills yeter.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="egbimoto_run_manifest",
             description="Ham manifest çalıştırır. Önce preview_manifest ile kontrol et.",
             inputSchema={"type":"object","properties":{"manifest":{"type":"object"}},"required":["manifest"]}),
        # ── V16 Tier 1 ────────────────────────────────────────────────────────
        Tool(name="egbimoto_preview_manifest",
             description="Manifest etki raporu — çalıştırmaz. ZORUNLU: run'dan önce çağır.",
             inputSchema={"type":"object","properties":{"manifest":{"type":"object"}},"required":["manifest"]}),
        Tool(name="egbimoto_get_document",
             description="Aktif Revit modeli bağlamı: proje, phase'ler, birimler, sayımlar.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="egbimoto_get_selection",
             description="Şu an Revit'te seçili elemanlar ve kategori dağılımı.",
             inputSchema={"type":"object","properties":{}}),
        # ── V16 Tier 2 ────────────────────────────────────────────────────────
        Tool(name="egbimoto_get_levels",
             description="Modeldeki katlar (ad + yükseklik). Manifest'te level_name gerektiğinde kullan.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="egbimoto_get_rooms",
             description="Oda listesi. Filtreler: q, phase, level, max.",
             inputSchema={"type":"object","properties":{"q":{"type":"string"},"phase":{"type":"string"},"level":{"type":"string"},"max":{"type":"integer"}}}),
        Tool(name="egbimoto_get_families",
             description="Family listesi. Filtreler: q, category, with_types, max.",
             inputSchema={"type":"object","properties":{"q":{"type":"string"},"category":{"type":"string"},"with_types":{"type":"boolean"},"max":{"type":"integer"}}}),
        Tool(name="egbimoto_search_parameters",
             description="Parametre arama (min 2 karakter). GUID, tip, kategori döner.",
             inputSchema={"type":"object","properties":{"q":{"type":"string"},"max":{"type":"integer"}},"required":["q"]}),
        # ── V16 Tier 3 ────────────────────────────────────────────────────────
        Tool(name="egbimoto_undo_last",
             description="Son işlemi geri al. Kullanıcı onayıyla kullan.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="egbimoto_explain_failure",
             description="Hata analizi ve düzeltme önerileri.",
             inputSchema={"type":"object","properties":{"error":{"type":"string"},"step":{"type":"string"},"op":{"type":"string"}},"required":["error"]}),
        Tool(name="egbimoto_generate_manifest",
             description="Hazır pattern'den manifest üret (5 pattern).",
             inputSchema={"type":"object","properties":{"pattern":{"type":"string","enum":["kalip_chain","cost_export","qa_check","room_param_fill","ifc_export"]}},"required":["pattern"]}),
        # ── V17 Skill ─────────────────────────────────────────────────────────
        Tool(name="egbimoto_list_skills",
             description=(
                 "EGBIMOTO skill kütüphanesini listeler (15 skill, ~2K token). "
                 "V17 ÖNERİLEN AKIŞ: list_skills → get_skill → run_skill(preview=true) → kullanıcı onayı → run_skill. "
                 "list_ops yerine bu aracı kullan — çok daha hafif. "
                 "Filtreler: category (Maliyet|QA|Yapısal|MEP|Oda|Export|Cephe|4D/5D), tag."
             ),
             inputSchema={"type":"object","properties":{
                 "category":{"type":"string","description":"Kategori filtresi"},
                 "tag":{"type":"string","description":"Etiket filtresi"},
             }}),
        Tool(name="egbimoto_get_skill",
             description=(
                 "Tek skill'in detaylarını döndürür: açıklama, parametreler, SKILL.md rehberi, manifest şablonu. "
                 "run_skill'den önce parametreleri öğrenmek için çağır."
             ),
             inputSchema={"type":"object","properties":{
                 "skill_id":{"type":"string","description":"Skill ID (list_skills'ten al)"},
             },"required":["skill_id"]}),

        Tool(name="egbimoto_translate",
             description=(
                 "BIM parametre adları için çeviri: EN/RU/ES/PT → TR. "
                 "src=auto ile dil otomatik tespit edilir. "
                 "translate_params op'unu çalıştırmadan önce tek bir adı test etmek için kullan."
             ),
             inputSchema={"type":"object","properties":{
                 "text":{"type":"string","description":"Çevrilecek metin (örn: Wall Height)"},
                 "src": {"type":"string","description":"auto|en|ru|es|pt (varsayılan: auto)"},
                 "tgt": {"type":"string","description":"Hedef dil (varsayılan: tr)"},
             },"required":["text"]}),
        Tool(name="egbimoto_translate_batch",
             description="Birden fazla parametre adını tek seferde çevir. Liste gönder, liste al.",
             inputSchema={"type":"object","properties":{
                 "texts":{"type":"array","items":{"type":"string"}},
                 "src":  {"type":"string","description":"Kaynak dil (auto|en|ru|es|pt)"},
                 "tgt":  {"type":"string","description":"Hedef dil (varsayılan: tr)"},
             },"required":["texts"]}),
        Tool(name="egbimoto_best_param",
             description=(
                 "Yabancı dil parametre adı için en uygun TR shared param adını önerir. "
                 "poz_match başarısız olduğunda veya manifest'te parametre adı yazarken kullan."
             ),
             inputSchema={"type":"object","properties":{
                 "name":    {"type":"string","description":"Parametre adı"},
                 "category":{"type":"string","description":"Revit kategori adı (Doors, Walls vb.)"},
             },"required":["name"]}),
        Tool(name="egbimoto_run_skill",
             description=(
                 "Skill ID + parametrelerle manifest otomatik üretir ve çalıştırır. "
                 "preview_only=true → sadece etki raporu döner (kullanıcıya göster). "
                 "preview_only=false → gerçekten çalıştırır. "
                 "AKIŞ: run_skill(preview=true) → göster → onay → run_skill(preview=false)."
             ),
             inputSchema={"type":"object","properties":{
                 "skill":       {"type":"string","description":"Skill ID"},
                 "params":      {"type":"object","description":"Skill parametreleri (get_skill ile öğren)"},
                 "preview_only":{"type":"boolean","description":"True=sadece etki raporu, False=çalıştır"},
             },"required":["skill"]}),
    ]

@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    try:
        # GET basit
        if name == "egbimoto_health":           s, t = await _get("/health")
        elif name == "egbimoto_list_ops":        s, t = await _get("/ops")
        elif name == "egbimoto_get_document":    s, t = await _get("/document")
        elif name == "egbimoto_get_selection":   s, t = await _get("/selection")
        elif name == "egbimoto_get_levels":      s, t = await _get("/levels")
        elif name == "egbimoto_undo_last":       s, t = await _post("/undo", {})
        # GET parametreli
        elif name in ("egbimoto_get_rooms","egbimoto_get_families","egbimoto_search_parameters"):
            endpoint = {"egbimoto_get_rooms":"/rooms","egbimoto_get_families":"/families","egbimoto_search_parameters":"/parameters"}[name]
            s, t = await _get(endpoint, params={k:v for k,v in arguments.items() if v is not None} or None)
        # POST manifest
        elif name == "egbimoto_run_manifest":
            m = arguments.get("manifest")
            if not m: return [TextContent(type="text", text="HATA: 'manifest' gerekli.")]
            s, t = await _post("/run", m)
        elif name == "egbimoto_preview_manifest":
            m = arguments.get("manifest")
            if not m: return [TextContent(type="text", text="HATA: 'manifest' gerekli.")]
            s, t = await _post("/preview", m)
        # POST diğer
        elif name == "egbimoto_explain_failure": s, t = await _post("/explain", arguments)
        elif name == "egbimoto_generate_manifest": s, t = await _post("/generate", arguments)
        # V17 Skill
        elif name == "egbimoto_list_skills":
            params = {k:v for k,v in arguments.items() if v is not None}
            s, t = await _get("/skills", params=params or None)
        elif name == "egbimoto_get_skill":
            skill_id = arguments.get("skill_id","")
            s, t = await _get(f"/skills/{skill_id}")
        elif name == "egbimoto_run_skill":
            s, t = await _post("/run-skill", arguments)
        # V18 Translation
        elif name == "egbimoto_translate":
            params = {k:v for k,v in arguments.items() if v is not None}
            s, t = await _get("/translate", params=params)
        elif name == "egbimoto_translate_batch":
            s, t = await _post("/translate/batch", arguments)
        elif name == "egbimoto_best_param":
            params = {k:v for k,v in arguments.items() if v is not None}
            s, t = await _get("/translate/best-param", params=params)
        else:
            return [TextContent(type="text", text=f"HATA: Bilinmeyen araç '{name}'.")]

        return [TextContent(type="text", text=t if s == 200 else f"[HTTP {s}] {t}")]

    except httpx.ConnectError:
        return [TextContent(type="text", text=f"HATA: EGBIMOTO bağlantısı yok ({BASE_URL}). Revit+EGBIMOTO açık mı?")]
    except httpx.TimeoutException:
        return [TextContent(type="text", text=f"HATA: Zaman aşımı ({HTTP_TIMEOUT}s).")]
    except Exception as e:
        return [TextContent(type="text", text=f"HATA: {e}")]

async def _main():
    async with stdio_server() as (r, w):
        await app.run(r, w, app.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(_main())
