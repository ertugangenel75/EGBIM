#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
op_contracts.json -> pattern_zincir_kurucu.html içindeki `const OPS = {...}`
bloğunu üretir/günceller.

Bu script HTML'in domain veri kaynağını op_contracts.json ile SENKRON tutar.
Elle iki yerde ayrı ayrı OPS güncellemek yerine:

    python3 deploy/generate_op_contracts.py .        # 1) kod+observations -> op_contracts.json
    python3 deploy/export_ops_for_html.py .           # 2) op_contracts.json -> HTML

HTML'deki OPS formatı (mevcut alan adları korunur):
    {"op_adi": {"out": domain_out, "accepts": domain_in_accepts,
                 "cat": category, "src": domain_source}}

Kullanım: python3 deploy/export_ops_for_html.py [repo_kökü] [html_dosya_yolu]
"""
import json, os, re, sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTRACTS = os.path.join(ROOT, "op_contracts.json")
HTML_PATH = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, "pattern_zincir_kurucu.html")

OPS_LINE_RE = re.compile(r'const OPS = (\{.*?\});', re.S)


def build_ops_dict(contracts):
    ops = {}
    for name, entry in contracts.items():
        ops[name] = {
            "out": entry.get("domain_out", "Any"),
            "accepts": entry.get("domain_in_accepts", [entry.get("domain_in", "Any")]),
            "cat": entry.get("category", "Genel"),
            "src": entry.get("domain_source", "default"),
        }
    return dict(sorted(ops.items()))


def main():
    if not os.path.exists(CONTRACTS):
        print(f"[HATA] {CONTRACTS} bulunamadı. Önce generate_op_contracts.py çalıştır.")
        sys.exit(1)
    if not os.path.exists(HTML_PATH):
        print(f"[HATA] {HTML_PATH} bulunamadı.")
        sys.exit(1)

    contracts = json.load(open(CONTRACTS, encoding="utf-8"))
    ops = build_ops_dict(contracts)
    ops_json = json.dumps(ops, ensure_ascii=False, separators=(",", ":"))

    html = open(HTML_PATH, encoding="utf-8").read()
    new_line = f"const OPS = {ops_json};"

    if OPS_LINE_RE.search(html):
        html_new = OPS_LINE_RE.sub(new_line.replace("\\", "\\\\"), html, count=1)
    else:
        print("[HATA] HTML içinde 'const OPS = {...};' bloğu bulunamadı — elle kontrol et.")
        sys.exit(1)

    with open(HTML_PATH, "w", encoding="utf-8") as f:
        f.write(html_new)

    # kaynak dağılımı raporu (HTML'e neyin gittiğini gör)
    from collections import Counter
    src_counts = Counter(v["src"] for v in ops.values())
    print(f"HTML güncellendi: {HTML_PATH}")
    print(f"  {len(ops)} op yazıldı")
    print(f"  kaynak dağılımı: {dict(src_counts)}")
    observed = sum(1 for v in ops.values() if "+observed" in v["src"])
    print(f"  gerçek Revit gözlemiyle kalibre edilmiş: {observed} op")


if __name__ == "__main__":
    main()
