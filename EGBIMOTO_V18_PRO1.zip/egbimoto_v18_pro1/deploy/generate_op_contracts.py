#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EGBIMOTO v13 — op_contracts.json üretici (SSoT: kod)

'required' semantiği ayrıştırması:
  presence = "required"     → op gövdesinde ctx.RequireX("key") — çalışma zamanında zorunlu
  presence = "optional"     → ctx.GetX("key", default)          — default kontrata yazılır
  presence = "recommended"  → ctx.GetX("key")                   — yokluğu tolere edilir
Geriye dönük uyumluluk: "required" bool alanı korunur (presence=="required").

Ek çıktılar:
  - Korpus istatistiği: her param için manifest'lerde veriliş oranı (usage_rate)
  - deploy/required_migration_onerisi.md: korpusta %100 verilen 'recommended'
    paramlar için GetX→RequireX migrasyon adayları

Kullanım:  python3 deploy/generate_op_contracts.py [repo_kökü]
"""
import json, os, re, sys
from collections import OrderedDict, defaultdict

ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")
MANIFESTS = os.path.join(ROOT, "manifests")
OBSERVATIONS = os.path.join(ROOT, "observations")
CONTRACTS = os.path.join(ROOT, "op_contracts.json")
LINTER = os.path.join(SRC, "EGBIMOTO.Core", "Manifest", "ManifestLinter.cs")

# ── DOMAIN KATMANI (v15) ─────────────────────────────────────────────────────
# op_contracts.json her op'a domain_in / domain_out ekler. Öncelik (SSoT sırası):
#   A. [OpDomain(In=..., Out=...)] C# attribute'u   (en yüksek — yeni oplar için)
#   B. ManifestLinter.OpDomains tablosu             (mevcut 150 op — otorite)
#   C. input_type/returns + isim heuristiği          (kalan ~300 op — çıkarım)
#   -. Hiçbiri → (Any, Any)                          (gerçekten jenerik utility)
# domain_source alanı hangi katmandan geldiğini işaretler: "attribute|linter|inferred|default"

DOMAINS = {"Any", "Structural", "MEP", "Architectural", "Report", "Rows",
           "Scalar", "PozData", "KalipResult", "WbsData", "IfcData"}

# Katman A: attribute — [OpDomain(In = Domain.Structural, Out = Domain.KalipResult)]
OPDOMAIN_ATTR_RE = re.compile(
    r'\[OpDomain\(\s*In\s*=\s*(?:[\w.]+\.)?(?P<in>\w+)\s*,\s*Out\s*=\s*(?:[\w.]+\.)?(?P<out>\w+)\s*\)\]',
    re.I)


def load_linter_domains(path):
    """Katman B: ManifestLinter.cs içindeki OpDomains sözlüğünü parse eder."""
    if not os.path.exists(path):
        return {}
    src = open(path, encoding="utf-8", errors="replace").read()
    if "OpDomains =" not in src:
        return {}
    block = src.split("OpDomains =", 1)[1].split("};", 1)[0]
    pairs = re.findall(
        r'\[\s*"([^"]+)"\s*\]\s*=\s*\(\s*Domain\.(\w+)\s*,\s*Domain\.(\w+)\s*\)', block)
    return {name: (din, dout) for name, din, dout in pairs}


def _norm_type(t):
    return re.sub(r"\s+", "", (t or "")).lower()


def infer_domains(op_name, input_type, returns):
    """Katman C: tip imzası + isim önekinden domain çıkarımı.

    NOT: C# tipi domain'i tek başına belirleyemez (kalip_all, poz_match, calc_cost
    hepsi List<Dictionary> döner ama domainleri farklıdır). Bu yüzden isim öneki
    semantik ayrımı sağlar; tip yalnızca Scalar/Rows kaba ayrımı için kullanılır.
    """
    it, rt = _norm_type(input_type), _norm_type(returns)
    name = op_name.lower()

    # ── OUTPUT domain: önce kaba tip, sonra isim override ──
    out = "Any"
    if rt in ("string", "int32", "int", "double", "bool", "boolean", "void",
              "object?", "object") or rt.startswith("int") or rt.startswith("double"):
        out = "Scalar"
    elif "dictionary" in rt:
        out = "Rows"
    elif "list<element" in rt:
        out = "Any"  # eleman listesi — disiplin isimden gelir

    if name.startswith("kalip_"):
        out = "KalipResult"
    elif name.startswith("poz_"):
        out = "PozData"
    elif name.startswith("cost_") or name == "calc_cost":
        out = "Rows"
    elif re.match(r"^(validate|check|qa_|mep_validate|elec_|plumbing_|fa_|fp_|"
                  r"coord_|arch_validate|door_|pm_validate|struct_validate)", name):
        out = "Report"
    elif name.startswith(("export_", "rows_to_", "write_", "set_param",
                          "rename_", "tag_", "place_")):
        out = "Scalar"
    elif name.startswith("map_to_ifc") or (name.startswith("ifc_") and "export" not in name):
        out = "IfcData"
    elif "wbs" in name:
        out = "WbsData"
    elif name.startswith(("show_", "display_")) or name == "validation_summary":
        out = "Report"
    elif name.startswith(("group_", "pivot", "aggregate", "merge_rows",
                          "elements_to_rows", "list_", "filter_")):
        out = "Rows"

    if name.startswith("collect_"):
        if re.search(r"wall|column|beam|floor|foundation|rebar|struct", name):
            out = "Structural"
        elif re.search(r"pipe|duct|cable|conduit|light|sprinkler|fire|mep|"
                       r"mechanical|plumb|elec", name):
            out = "MEP"
        elif re.search(r"room|door|window|ceiling|stair|arch", name):
            out = "Architectural"
        else:
            out = "Any"

    # ── INPUT domain ──
    inp = "Any"
    if "dictionary" in it:
        inp = "Rows"
    if name in ("kalip_summary", "kalip_write_back"):
        inp = "KalipResult"
    if name == "calc_cost" or name.startswith("cost_"):
        inp = "PozData"
    if re.match(r"^(merge_validation|validation_to_rows|display_report|"
                r"export_validation)", name):
        inp = "Report"

    if out not in DOMAINS:
        out = "Any"
    if inp not in DOMAINS:
        inp = "Any"
    return inp, out


def resolve_domains(op_name, attr_region, input_type, returns, linter_map):
    """Üç katmanı öncelik sırasıyla birleştirir. (in, out, source) döndürür."""
    # A. attribute — [OpDomain(In=..., Out=...)]
    if attr_region:
        am = OPDOMAIN_ATTR_RE.search(attr_region)
        if am:
            din = _canon_domain(am.group("in"))
            dout = _canon_domain(am.group("out"))
            if din in DOMAINS and dout in DOMAINS:
                return din, dout, "attribute"
    # B. linter tablosu
    if op_name in linter_map:
        din, dout = linter_map[op_name]
        return din, dout, "linter"
    # C. heuristik
    din, dout = infer_domains(op_name, input_type, returns)
    if (din, dout) != ("Any", "Any"):
        return din, dout, "inferred"
    return "Any", "Any", "default"


def _canon_domain(raw):
    """'kalipresult' → 'KalipResult' gibi enum ismini kanonikleştirir."""
    low = raw.lower()
    for d in DOMAINS:
        if d.lower() == low:
            return d
    return raw


# Rows üst-tür hiyerarşisi (C# DomainCompatible ile birebir)
ROWS_SUBTYPES = {"Rows", "PozData", "KalipResult", "Report", "WbsData"}


def _domain_compatible(producer_out, consumer_in):
    if producer_out == "Any" or consumer_in == "Any":
        return True
    if producer_out == consumer_in:
        return True
    if consumer_in == "Rows" and producer_out in ROWS_SUBTYPES:
        return True
    return False


def load_observations(path):
    """observations/ klasöründeki DOĞRULANMIŞ zincir kayıtlarını okur.

    Eski calibrate_from_corpus 357 manifest'i (Claude tarafından tahminle
    yazılmış, hiç Revit'te çalıştırılmamış) yer-gerçeği sayıyordu — bu
    sirkülerdi (Claude'un tahmini Claude'un tahminini doğruluyordu).

    Yeni model: SADECE observations/*.json içindeki, 'verified_by' alanı
    olan ve gerçek Revit modelinde çalıştırılmış zincirler kalibrasyon
    girdisidir. Doğrulanmamış her şey (manifests/, legacy backup) bilgi
    olarak dahi bu fonksiyona girmez.
    """
    docs = []
    if not os.path.isdir(path):
        return docs
    for fn in sorted(os.listdir(path)):
        if not fn.endswith(".json"):
            continue
        try:
            d = json.load(open(os.path.join(path, fn), encoding="utf-8"))
        except Exception:
            continue
        if not d.get("verified_by"):
            print(f"  [UYARI] {fn}: 'verified_by' alanı yok — atlanıyor (doğrulanmamış)")
            continue
        if not d.get("chain"):
            continue
        docs.append((fn, d))
    return docs


def calibrate_from_observations(result, observation_docs):
    """Katman D — SADECE doğrulanmış runtime gözlemlerinden kalibrasyon.

    Kabul-listesi modeli: domain_in tekil "birincil" domain olarak korunur,
    observations/'da gözlemlenmiş gerçek girdi domain'leri ile birleştirilir.
    Kaynak etiketi 'attribute+observed' / 'linter+observed' / ... olur —
    'corpus' kelimesi bilerek kullanılmıyor çünkü artık kaynak tahmin değil,
    gerçek Revit oturumu.
    """
    observed_in = defaultdict(set)
    observed_out = defaultdict(set)
    for fn, doc in observation_docs:
        chain = doc["chain"]
        out_by_id = {}
        for step in chain:
            op = step.get("op")
            sid = step.get("step_id") or step.get("id")
            if not op:
                continue
            # gözlemde açıkça belirtilmiş domain'i önceliklendir
            explicit_out = step.get("domain_out_observed")
            do = explicit_out or (result[op]["domain_out"] if op in result else "Any")
            explicit_in = step.get("domain_in_observed")
            if explicit_in:
                observed_in[op].add(explicit_in)
            srcs = ([step["from"]] if step.get("from") else []) + (step.get("from_many") or [])
            for src in srcs:
                if src in out_by_id:
                    observed_in[op].add(out_by_id[src])
            if sid:
                out_by_id[sid] = do
            if explicit_out:
                observed_out[op].add(explicit_out)

    calibrated = 0
    for op, entry in result.items():
        din = entry["domain_in"]
        accepts = {din}
        obs = observed_in.get(op, set())
        added = False
        for o in obs:
            if not _domain_compatible(o, din):
                accepts.add(o)
                added = True
        if "Any" in accepts:
            accepts = {"Any"}
        entry["domain_in_accepts"] = sorted(accepts)
        if op in observed_out:
            entry["domain_out_observed"] = sorted(observed_out[op])
        if added:
            src = entry.get("domain_source", "")
            if "+observed" not in src:
                entry["domain_source"] = src + "+observed"
            calibrated += 1
        entry.setdefault("domain_in_accepts", sorted(accepts))
    return calibrated

# ── 1. Kod tarama ────────────────────────────────────────────────────────────

EGOP_RE = re.compile(r'\[EgOp\(\s*"(?P<name>[a-z0-9_]+)"', re.I)
METHOD_RE = re.compile(
    r'(?:public|internal)\s+static\s+(?P<ret>[\w<>,\s\?\.\(\)]+?)\s+(?P<mname>\w+)\s*\(\s*OpContext\s+\w+\s*\)')

# param okuma kalıpları — (regex, tip, presence_kuralı)
READ_PATTERNS = [
    # Require ailesi → required
    (re.compile(r'\.Require(String|Int|Double)\(\s*"(?P<k>[^"]+)"\s*\)'), None, "required"),
    (re.compile(r'\.RequireList<(?P<t>[\w<>,\s]+)>\(\s*"(?P<k>[^"]+)"\s*\)'), "List", "required"),
    (re.compile(r'\.RequireStringList\(\s*"(?P<k>[^"]+)"\s*\)'), "List<String>", "required"),
    # Get ailesi — default'lu → optional, default'suz → recommended
    (re.compile(r'\.Get(String|Int|Double|Bool)\(\s*"(?P<k>[^"]+)"\s*(?:,\s*(?P<def>[^)]+?))?\s*\)'), None, None),
    (re.compile(r'\.GetParam<(?P<t>[\w<>,\s\?\.]+)>\(\s*"(?P<k>[^"]+)"\s*(?:,\s*(?P<def>[^)]+?))?\s*\)'), "Param", None),
    (re.compile(r'\.GetList<(?P<t>[\w<>,\s]+)>\(\s*"(?P<k>[^"]+)"\s*\)'), "List", "recommended"),
    (re.compile(r'\.GetStringList\(\s*"(?P<k>[^"]+)"\s*\)'), "List<String>", "recommended"),
    # Ham Params erişimi → optional (op kendi kontrolünü yapıyor)
    (re.compile(r'Params\.(?:TryGetValue|ContainsKey)\(\s*"(?P<k>[^"]+)"'), "Object", "optional"),
]

TYPE_MAP = {"String": "String", "Int": "Int32", "Double": "Double", "Bool": "Boolean"}
PRESENCE_RANK = {"required": 3, "recommended": 2, "optional": 1}


def extract_attribute_text(text, egop_start):
    """[EgOp("op", ...)] bloğunun tam metnini döndürür — Category gibi
    isimli alanları okumak için (parantez derinliği takip edilir)."""
    i = text.find("(", egop_start)
    if i == -1:
        return ""
    depth, j = 0, i
    while j < len(text):
        if text[j] == "(":
            depth += 1
        elif text[j] == ")":
            depth -= 1
            if depth == 0:
                return text[egop_start:j + 1]
        j += 1
    return text[egop_start:]


def extract_body(text, method_start):
    """method_start'tan itibaren gövdeyi döndürür (blok veya expression-bodied)."""
    i = method_start
    while i < len(text) and text[i] not in "{;=":
        if text[i] == "=" and i + 1 < len(text) and text[i + 1] == ">":
            # expression-bodied:  => Expr;
            j = text.find(";", i)
            return text[i:j + 1] if j != -1 else text[i:i + 200]
        i += 1
    if i >= len(text) or text[i] != "{":
        j = text.find(";", method_start)
        return text[method_start:j + 1] if j != -1 else ""
    depth, j = 0, i
    while j < len(text):
        c = text[j]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return text[i:j + 1]
        j += 1
    return text[i:]


def parse_literal(expr):
    """C# default ifadesini JSON değerine çevirmeye çalışır."""
    if expr is None:
        return None
    e = expr.strip()
    if e.startswith('"') and e.endswith('"'):
        return e[1:-1]
    if e in ("true", "false"):
        return e == "true"
    if re.fullmatch(r"-?\d+", e):
        return int(e)
    if re.fullmatch(r"-?\d*\.\d+[dDfF]?", e):
        return float(e.rstrip("dDfF"))
    return e  # ifade — string olarak sakla ("<expr>" niteliğinde)


def scan_params(body):
    """Gövdeden {key: (type, presence, default)} çıkarır; çakışmada en katı presence kazanır."""
    found = OrderedDict()
    for rx, kind, forced in READ_PATTERNS:
        for m in rx.finditer(body):
            key = m.group("k")
            gd = m.groupdict()
            if kind is None:  # Require(String|...) / Get(String|...)
                base = m.group(1)
                ptype = TYPE_MAP.get(base, base)
            elif kind == "List":
                ptype = f"List<{gd.get('t','Object').strip()}>"
            elif kind == "Param":
                ptype = gd.get("t", "Object").strip()
            else:
                ptype = kind
            if forced:
                presence, default = forced, None
            else:
                has_def = gd.get("def") is not None
                presence = "optional" if has_def else "recommended"
                default = parse_literal(gd.get("def")) if has_def else None
            prev = found.get(key)
            if prev is None or PRESENCE_RANK[presence] > PRESENCE_RANK[prev[1]]:
                found[key] = (ptype, presence, default)
            elif prev and presence == prev[1] == "optional" and prev[2] is None:
                found[key] = (ptype, presence, default)
    return found


def scan_registry(body):
    reads = sorted(set(re.findall(r'Reg(?:istry)?\.Get\w*\(\s*"([^"]+)"', body)))
    writes = sorted(set(re.findall(r'Reg(?:istry)?\.Set\w*\(\s*"([^"]+)"', body)))
    return reads, writes


def scan_input_type(body):
    m = re.search(r'\.InputAs(?:OrDefault)?<([\w<>,\s\?\.]+)>', body)
    return m.group(1).strip().replace(" ", "") if m else None


ops_code = OrderedDict()          # op_name -> dict
method_bodies = {}                # (file, method_name) -> body
delegations = {}                  # op_name -> delegated method name

for dirpath, _, files in os.walk(SRC):
    for fn in sorted(files):
        if not fn.endswith(".cs"):
            continue
        path = os.path.join(dirpath, fn)
        raw = open(path, encoding="utf-8", errors="replace").read()
        # Yorumlari soy — doc ornekleri (/// [EgOp("...")]) hayalet op uretmesin.
        # Satir/blok yorumlar bosluga cevrilir ki offset'ler kaymasin.
        text = re.sub(r"//[^\n]*", lambda m: " " * len(m.group(0)), raw)
        text = re.sub(r"/\*.*?\*/", lambda m: re.sub(r"[^\n]", " ", m.group(0)), text, flags=re.S)
        for am in EGOP_RE.finditer(text):
            op_name = am.group("name")
            mm = METHOD_RE.search(text, am.end())
            if not mm:
                continue
            body = extract_body(text, mm.end())
            method_bodies[(fn, mm.group("mname"))] = body
            # tek seviye delegasyon:  => DigerMetot(ctx);
            dm = re.fullmatch(r'\s*=>\s*(\w+)\(\s*\w+\s*\)\s*;\s*', body)
            if dm:
                delegations[op_name] = (fn, dm.group(1))

            attr_text = extract_attribute_text(text, am.start())
            cat_m = re.search(r'Category\s*=\s*"([^"]+)"', attr_text)
            tx_m = re.search(r'RequiresTransaction\s*=\s*(true|false)', attr_text, re.I)

            desc = None
            desc_m = re.search(r'Description\s*=\s*(".*?"(?:\s*\+\s*".*?")*)', attr_text, re.S)
            if desc_m:
                parts = re.findall(r'"((?:[^"\\]|\\.)*)"', desc_m.group(1))
                desc = "".join(parts).replace('\\n', ' ').replace('\\"', '"')
                desc = re.sub(r'\s+', ' ', desc).strip()

            # OpDomain attribute'u EgOp ile aynı bölgede (attribute yığını) durur.
            # EgOp başından metot gövdesi başına kadar olan aralığı tara.
            attr_region = text[max(0, am.start() - 300):mm.end()]

            ops_code[op_name] = {
                "file": fn,
                "returns": re.sub(r"\s+", " ", mm.group("ret")).strip(),
                "body": body,
                "attr_region": attr_region,
                "category": cat_m.group(1) if cat_m else None,
                "description": desc,
                "requires_transaction": (tx_m.group(1).lower() == "true") if tx_m else None,
            }

# delegasyonları çöz
for op, (fn, target) in delegations.items():
    tb = method_bodies.get((fn, target))
    if tb:
        ops_code[op]["body"] = tb

# ── 2. Korpus istatistiği (SADECE param usage_rate için — domain kalibrasyonu
#       için KULLANILMAZ; bkz. calibrate_from_observations) ──────────────────
# manifests/ klasörü doğrulanmamış/taslak manifestler içerebilir. Buradan
# çıkan usage_rate sadece "bu param genelde hangi manifestlerde veriliyor"
# bilgisidir — required/optional migrasyon önerisi için kullanılır, domain
# doğruluğu iddiası taşımaz.

usage = defaultdict(lambda: defaultdict(int))  # op -> param -> supplied_count
op_uses = defaultdict(int)                      # op -> step count
manifest_docs = []                              # sadece param istatistiği için

for dirpath, _, files in os.walk(MANIFESTS):
    for fn in files:
        if not fn.endswith(".json"):
            continue
        try:
            m = json.load(open(os.path.join(dirpath, fn), encoding="utf-8"))
        except Exception:
            continue
        manifest_docs.append(m)
        for s in (m.get("steps") or m.get("nodes") or []):
            op = s.get("op")
            if not op:
                continue
            op_uses[op] += 1
            for k in (s.get("inputs") or s.get("params") or {}):
                usage[op][k] += 1

# ── 3. Mevcut kontratla birleştir ────────────────────────────────────────────

legacy = json.load(open(CONTRACTS, encoding="utf-8"), object_pairs_hook=OrderedDict)

# Katman B kaynağı: Linter domain tablosu
linter_domains = load_linter_domains(LINTER)

result = OrderedDict()
migration_candidates = []  # (op, param, type, uses)
stats = defaultdict(int)
domain_stats = defaultdict(int)  # source -> count

for op_name in sorted(set(list(legacy.keys()) + list(ops_code.keys()))):
    old = legacy.get(op_name, OrderedDict())
    code = ops_code.get(op_name)

    entry = OrderedDict()
    entry["file"] = (code or {}).get("file") or old.get("file", "")
    entry["returns"] = old.get("returns") or (code or {}).get("returns", "")
    if code:
        it = scan_input_type(code["body"])
        entry["input_type"] = old.get("input_type") or it or ""
    else:
        entry["input_type"] = old.get("input_type", "")

    old_params = OrderedDict((p["key"], p) for p in old.get("params", []))
    code_params = scan_params(code["body"]) if code else OrderedDict()

    params_out = []
    for key in list(code_params.keys()) + [k for k in old_params if k not in code_params]:
        if key in code_params:
            ptype, presence, default = code_params[key]
            src = "code"
        else:
            op_ = old_params[key]
            ptype = op_.get("type", "Object")
            presence = "recommended"  # kod tarafından doğrulanamadı — legacy
            default = op_.get("default")
            src = "legacy"
        uses = op_uses.get(op_name, 0)
        supplied = usage.get(op_name, {}).get(key, 0)
        rate = round(supplied / uses, 3) if uses else None

        p = OrderedDict()
        p["key"] = key
        p["type"] = ptype
        p["presence"] = presence
        p["required"] = presence == "required"      # geriye dönük uyumluluk
        p["default"] = "" if default is None and presence != "required" else default
        if presence == "required":
            p.pop("default")
        if rate is not None:
            p["usage_rate"] = rate
        if src == "legacy":
            p["derived"] = "legacy"
        params_out.append(p)
        stats[presence] += 1

        # migrasyon adayı: recommended + korpusta her kullanımda verilmiş (≥3 kullanım)
        if presence == "recommended" and uses >= 3 and supplied == uses:
            migration_candidates.append((op_name, key, ptype, uses))

    entry["params"] = params_out
    if code:
        rr, rw = scan_registry(code["body"])
        entry["reg_reads"] = sorted(set(old.get("reg_reads", []) + rr))
        entry["reg_writes"] = sorted(set(old.get("reg_writes", []) + rw))
    else:
        entry["reg_reads"] = old.get("reg_reads", [])
        entry["reg_writes"] = old.get("reg_writes", [])
    entry["out_fields"] = old.get("out_fields", [])

    # ── Domain katmanı (v15) ──
    attr_region = (code or {}).get("attr_region", "")
    d_in, d_out, d_src = resolve_domains(
        op_name, attr_region, entry["input_type"], entry["returns"], linter_domains)
    entry["domain_in"] = d_in
    entry["domain_out"] = d_out
    entry["domain_source"] = d_src
    domain_stats[d_src] += 1

    entry["category"] = old.get("category") or (code or {}).get("category") or "Genel"
    desc = old.get("description") or (code or {}).get("description")
    if desc:
        entry["description"] = desc
    rt = old.get("requires_transaction")
    if rt is None and code is not None:
        rt = code.get("requires_transaction")
    if rt is not None:
        entry["requires_transaction"] = rt
    result[op_name] = entry

# ── 3.5 Doğrulanmış gözlem kalibrasyonu (Katman D) ───────────────────────────
# ÖNEMLİ: manifests/ klasörü BURADA KULLANILMAZ. Sadece observations/*.json
# içindeki, gerçek Revit modelinde çalıştırılıp 'verified_by' ile onaylanmış
# zincirler domain_in_accepts'i genişletebilir.

print("\n--- observations/ okunuyor (domain kalibrasyonu için TEK otorite) ---")
observation_docs = load_observations(OBSERVATIONS)
print(f"  {len(observation_docs)} doğrulanmış gözlem dosyası bulundu")
relaxed_count = calibrate_from_observations(result, observation_docs)

# ── 4. Yaz ───────────────────────────────────────────────────────────────────

with open(CONTRACTS, "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=1)
    f.write("\n")

mig_path = os.path.join(ROOT, "deploy", "required_migration_onerisi.md")
with open(mig_path, "w", encoding="utf-8") as f:
    f.write("# GetX → RequireX Migrasyon Adayları\n\n")
    f.write("Kodda default'suz okunan (`presence: recommended`) VE 356 manifest korpusunda\n")
    f.write("kullanıldığı her adımda açıkça verilen paramlar. RequireX'e geçiş mevcut\n")
    f.write("manifestleri KIRMAZ (korpusta %100 veriliyor) ve eksik girdide net hata sağlar.\n\n")
    f.write("| Op | Param | Tip | Korpus kullanımı |\n|---|---|---|---|\n")
    for op, key, t, uses in sorted(migration_candidates):
        f.write(f"| `{op}` | `{key}` | {t} | {uses}/{uses} |\n")

print(f"op sayısı: {len(result)}  (kodda bulunan: {len(ops_code)}, legacy-only: {len(result)-len(ops_code)})")
print(f"param presence dağılımı: {dict(stats)}")
print(f"migrasyon adayı: {len(migration_candidates)} → {mig_path}")

# ── Domain kapsam raporu ──
ds = dict(domain_stats)
labeled = len(result) - ds.get("default", 0)
print(f"\ndomain kaynak dağılımı: {ds}")
print(f"domain kapsamı: {labeled}/{len(result)} = %{100*labeled//len(result)} "
      f"(attribute:{ds.get('attribute',0)} linter:{ds.get('linter',0)} "
      f"inferred:{ds.get('inferred',0)} default/Any:{ds.get('default',0)})")
print(f"doğrulanmış gözlem kalibrasyonu: {relaxed_count} op'un kabul-listesi (domain_in_accepts) "
      f"gerçek Revit oturumu kanıtıyla genişletildi (manifests/ klasörü kullanılmadı)")
