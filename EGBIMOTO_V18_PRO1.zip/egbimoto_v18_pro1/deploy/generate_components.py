#!/usr/bin/env python3
"""
generate_components.py — manifests/ ve data/ klasörlerindeki dosyalar için
WiX v5 component listesi üretir (HarvestedFiles.wxs).

WiX'in HeatWave harvest aracı CI'da her zaman bulunmayabilir; bu script saf
Python ile aynı işi yapar: her dosya için bir <Component> + <File>, doğru
<Directory> ağacıyla.

Kullanım:
    python3 generate_components.py <stage_app_dir> <revit_short>
    python3 generate_components.py stage/R26/app 26

Çıktı: stdout'a WiX Fragment (stage.sh bunu HarvestedFiles.wxs'e yönlendirir)

Üretilen ComponentGroup'lar:
    EngineManifestsHarvested → manifests/ ağacı
    EngineDataHarvested      → data/ ağacı

NOT: Bu üretilen dosya, EGBIMOTO.Installer.wxs'teki placeholder ComponentGroup'lar
yerine kullanılmalı. Tam otomasyon için wxs'te şu referanslar açılır:
    <ComponentGroupRef Id="EngineManifestsHarvested" />
    <ComponentGroupRef Id="EngineDataHarvested" />
"""
import sys
import os
import hashlib

def safe_id(prefix, path):
    """WiX ID: harf/rakam/alt çizgi, 72 karakter sınırı. Hash ile benzersizlik."""
    h = hashlib.md5(path.encode("utf-8")).hexdigest()[:8]
    clean = "".join(c if c.isalnum() else "_" for c in os.path.basename(path))
    clean = clean[:40]
    return f"{prefix}_{clean}_{h}"

def walk_tree(root_dir, sub, dir_id_base, group_id):
    """sub klasörü (manifests veya data) için Directory ağacı + Component'ler üret."""
    base_path = os.path.join(root_dir, sub)
    if not os.path.isdir(base_path):
        return "", ""

    dir_fragments = []   # <Directory> tanımları
    components = []       # <Component> tanımları
    dir_id_map = {}       # gerçek yol → WiX Directory Id

    # Kök dizin id'si installer.wxs'te tanımlı (EngineManifestsDir / EngineDataDir)
    dir_id_map[base_path] = dir_id_base

    for cur, dirs, files in os.walk(base_path):
        cur_id = dir_id_map[cur]

        # Alt dizinler
        child_dirs = []
        for d in sorted(dirs):
            full = os.path.join(cur, d)
            did = safe_id("Dir", os.path.relpath(full, root_dir))
            dir_id_map[full] = did
            child_dirs.append(f'<Directory Id="{did}" Name="{d}">')

        # Bu dizindeki dosyalar
        for f in sorted(files):
            full = os.path.join(cur, f)
            rel = os.path.relpath(full, root_dir)
            cid = safe_id("Cmp", rel)
            fid = safe_id("Fil", rel)
            components.append(
                f'    <Component Id="{cid}" Directory="{cur_id}" Guid="*">\n'
                f'      <File Id="{fid}" Source="$(StageDir)\\app\\{rel.replace("/", chr(92))}" KeyPath="yes" />\n'
                f'    </Component>'
            )

    # Directory ağacını yeniden kur (nested)
    def build_dir_xml(path):
        children = sorted(
            [os.path.join(path, d) for d in os.listdir(path)
             if os.path.isdir(os.path.join(path, d))]
        )
        inner = ""
        for c in children:
            did = dir_id_map[c]
            name = os.path.basename(c)
            inner += f'<Directory Id="{did}" Name="{name}">{build_dir_xml(c)}</Directory>'
        return inner

    dir_xml = build_dir_xml(base_path)

    comp_group = (
        f'  <ComponentGroup Id="{group_id}">\n'
        + "\n".join(components)
        + f'\n  </ComponentGroup>'
    )

    return dir_xml, comp_group

def main():
    if len(sys.argv) < 3:
        print("Kullanım: generate_components.py <stage_app_dir> <revit_short>", file=sys.stderr)
        sys.exit(1)

    app_dir = sys.argv[1]
    short = sys.argv[2]

    man_dirs, man_comps = walk_tree(app_dir, "manifests", "EngineManifestsDir", "EngineManifestsHarvested")
    data_dirs, data_comps = walk_tree(app_dir, "data", "EngineDataDir", "EngineDataHarvested")

    print('<?xml version="1.0" encoding="UTF-8"?>')
    print('<!-- OTOMATIK ÜRETİLDİ — generate_components.py. Elle düzenlemeyin. -->')
    print('<Wix xmlns="http://wixtoolset.org/schemas/v4/wxs">')

    # Directory ağaçları — installer.wxs'teki EngineManifestsDir/EngineDataDir altına eklenir
    print('  <Fragment>')
    print(f'    <DirectoryRef Id="EngineManifestsDir">{man_dirs}</DirectoryRef>')
    if data_dirs:
        print(f'    <DirectoryRef Id="EngineDataDir">{data_dirs}</DirectoryRef>')
    print('  </Fragment>')

    print('  <Fragment>')
    print(man_comps)
    print('  </Fragment>')

    if data_comps:
        print('  <Fragment>')
        print(data_comps)
        print('  </Fragment>')

    print('</Wix>')

if __name__ == "__main__":
    main()
