#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
#  stage.sh — EGBIMOTO build çıktısını MSI installer için dizer.
#
#  Kullanım:
#    ./deploy/stage.sh 2026
#
#  Ne yapar:
#    1. Bootstrap + Engine projelerini Release derler (verilen Revit sürümü için)
#    2. Çıktıları stage/R<short>/ altına iki gruba ayırır:
#         addin/  → Bootstrap.dll + .addin       (Revit add-in dizinine gidecek)
#         app/    → engine + bağımlılıklar + manifests/data/json  (engine dizini)
#    3. WiX harvest için manifests/ ve data/ component listesi üretir
#
#  Çıktı sonrası MSI derleme:
#    dotnet build deploy/installer/EGBIMOTO.Installer.wixproj -p:RevitVersion=2026
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

REVIT_VERSION="${1:-2026}"
SHORT="${REVIT_VERSION: -2}"          # 2026 → 26
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAGE="$ROOT/stage/R$SHORT"
CONFIG="Release"

echo "═══════════════════════════════════════════════════"
echo " EGBIMOTO stage — Revit $REVIT_VERSION (R$SHORT)"
echo "═══════════════════════════════════════════════════"

# ── 1. Temiz stage dizini ──────────────────────────────────────────────────
rm -rf "$STAGE"
mkdir -p "$STAGE/addin" "$STAGE/app"

# ── 2. Projeleri derle ─────────────────────────────────────────────────────
echo "▶ Bootstrap derleniyor..."
dotnet build "$ROOT/src/EGBIMOTO.Bootstrap/EGBIMOTO.Bootstrap.csproj" \
    -c "$CONFIG" -p:RevitVersion="$REVIT_VERSION" --nologo

echo "▶ Engine (Addin) derleniyor..."
dotnet build "$ROOT/src/EGBIMOTO.Addin/EGBIMOTO.Addin.csproj" \
    -c "$CONFIG" -p:RevitVersion="$REVIT_VERSION" --nologo

BOOT_OUT="$ROOT/src/EGBIMOTO.Bootstrap/bin/$CONFIG/net8.0-windows"
ADDIN_OUT="$ROOT/src/EGBIMOTO.Addin/bin/$CONFIG/net8.0-windows"

# ── 3. Bootstrap → addin/ ──────────────────────────────────────────────────
echo "▶ Bootstrap dosyaları diziliyor (addin/)..."
cp "$BOOT_OUT/EGBIMOTO.Bootstrap.dll" "$STAGE/addin/"
cp "$ROOT/deploy/addins/EGBIMOTO.Bootstrap.addin" "$STAGE/addin/"

# ── 4. Engine → app/ ───────────────────────────────────────────────────────
echo "▶ Engine dosyaları diziliyor (app/)..."
# Tüm DLL, deps.json, runtimeconfig — Bootstrap.dll hariç (o addin/'de)
for f in "$ADDIN_OUT"/*.dll "$ADDIN_OUT"/*.json; do
    base="$(basename "$f")"
    [ "$base" = "EGBIMOTO.Bootstrap.dll" ] && continue
    cp "$f" "$STAGE/app/"
done

# native bağımlılıklar (WebView2 vb. runtimes/ alt klasörü)
if [ -d "$ADDIN_OUT/runtimes" ]; then
    cp -r "$ADDIN_OUT/runtimes" "$STAGE/app/"
fi

# manifests + data + contracts + categories
cp -r "$ROOT/manifests"          "$STAGE/app/"
cp -r "$ROOT/data"               "$STAGE/app/" 2>/dev/null || echo "  (data/ yok, atlandı)"
cp    "$ROOT/op_contracts.json"  "$STAGE/app/"
cp    "$ROOT/categories.json"    "$STAGE/app/"

# ── 5. WiX harvest component listesi üret ──────────────────────────────────
echo "▶ Harvest component listesi üretiliyor..."
python3 "$ROOT/deploy/generate_components.py" "$STAGE/app" "$SHORT" \
    > "$ROOT/deploy/installer/HarvestedFiles.wxs" 2>/dev/null \
    && echo "  → deploy/installer/HarvestedFiles.wxs" \
    || echo "  (generate_components.py yok — manuel harvest gerekli)"

# ── Özet ───────────────────────────────────────────────────────────────────
echo ""
echo "✅ Stage tamamlandı: $STAGE"
echo "   addin/ dosya: $(ls "$STAGE/addin" | wc -l)"
echo "   app/   dosya: $(find "$STAGE/app" -maxdepth 1 -type f | wc -l) (kök) + manifests/data"
echo ""
echo "Sıradaki adım — MSI derle:"
echo "   dotnet build deploy/installer/EGBIMOTO.Installer.wixproj -p:RevitVersion=$REVIT_VERSION"
