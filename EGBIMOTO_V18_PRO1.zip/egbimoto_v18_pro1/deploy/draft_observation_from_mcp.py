#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
egbimoto_run_manifest'in MCP session çıktısından observations/ TASLAĞI üretir.

ÖNEMLİ: Bu script hiçbir zaman observations/ klasörüne otomatik yazmaz.
Sadece observations/_draft_<isim>.json üretir — 'verified_by' alanı BOŞ.
Ertugan gerçek modelde sonucu gördükten sonra:
  1. Dosyayı observations/ altına taşı (_draft_ önekini kaldır)
  2. verified_by alanını doldur (örn. "ertugan_mcp_session_2026-07-04")
  3. gerekirse domain_in_observed/domain_out_observed satırlarını düzelt
ancak generate_op_contracts.py kalibrasyona dahil eder.

Kullanım:
  1) MCP'den (egbimoto_run_manifest) dönen JSON'u bir dosyaya kaydet, örn. run_result.json
  2) python3 deploy/draft_observation_from_mcp.py run_result.json manifest_used.json
"""
import json, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OBS_DIR = os.path.join(ROOT, "observations")


def shape_to_domain_guess(shape):
    """OutputShape string'inden kaba bir domain tahmini üretir (öneri amaçlı,
    kesin değil — kişi elle doğrulamalı)."""
    if not shape:
        return None
    if shape.startswith("List<Dictionary>"):
        return "Rows"  # spesifik alt-domain (PozData/KalipResult/Report) elle karar verilmeli
    if shape in ("Int32", "Double", "String", "Boolean", "Scalar"):
        return "Scalar"
    return None


def main():
    if len(sys.argv) < 3:
        print("Kullanım: draft_observation_from_mcp.py <run_result.json> <manifest_used.json>")
        sys.exit(1)

    run_result = json.load(open(sys.argv[1], encoding="utf-8"))
    manifest = json.load(open(sys.argv[2], encoding="utf-8"))

    steps_by_id = {s["id"]: s for s in run_result.get("steps", [])}
    manifest_steps = manifest.get("steps") or manifest.get("nodes") or []

    chain = []
    for ms in manifest_steps:
        sid = ms.get("id")
        rr = steps_by_id.get(sid, {})
        entry = {
            "step_id": sid,
            "op": ms.get("op"),
        }
        if ms.get("from"):
            entry["from"] = ms["from"]
        if ms.get("from_many"):
            entry["from_many"] = ms["from_many"]
        guess = shape_to_domain_guess(rr.get("output_shape"))
        if guess:
            entry["domain_out_observed"] = guess
            entry["_raw_output_shape"] = rr.get("output_shape")  # ham kanıt, kontrol için
        entry["_success"] = rr.get("success")
        chain.append(entry)

    draft = {
        "chain": chain,
        "verified_by": "",  # BİLEREK BOŞ — Ertugan doldurmadan kalibrasyona girmez
        "notes": "TASLAK — MCP çalıştırmasından otomatik üretildi. domain_out_observed alanları "
                 "kaba tahmindir (List<Dictionary> -> Rows), gerçek alt-domain (PozData/KalipResult/"
                 "Report/WbsData) senin bilginle düzeltilmeli. _raw_output_shape kanıt olarak kalsın.",
        "revit_model": manifest.get("_revit_model", ""),
        "date": "",
    }

    title = (manifest.get("title") or manifest.get("Title") or "manifest").lower()
    safe = "".join(c if c.isalnum() else "_" for c in title)[:40]
    out_path = os.path.join(OBS_DIR, f"_draft_{safe}.json")
    os.makedirs(OBS_DIR, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(draft, f, ensure_ascii=False, indent=2)

    print(f"Taslak yazıldı: {out_path}")
    print("Bu dosya generate_op_contracts.py tarafından OKUNMAZ (verified_by boş).")
    print("Gözden geçir, verified_by'ı doldur, _draft_ önekini kaldırıp observations/'a taşı.")


if __name__ == "__main__":
    main()
