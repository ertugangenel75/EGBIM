#!/usr/bin/env python3
"""
generate_op_referansi.py — docs/OP_REFERANSI.md'yi op_contracts.json'dan üretir.

op_contracts.json, koddaki [EgOp] attribute'larından türetilen tek doğruluk
kaynağıdır (SSoT). Bu script onu okuyup kategoriye göre gruplanmış, içindekiler
tablolu bir Markdown referansı yazar. 🔒 işareti transaction gerektiren op'ları
belirtir.

Kullanım (repo kökünden):
    python3 deploy/generate_op_referansi.py

Çıktı: docs/OP_REFERANSI.md (üzerine yazar)

Op kategorileri kodda değiştiğinde önce op_contracts.json güncellenmeli,
sonra bu script çalıştırılmalıdır.
"""
import json
import os
from collections import defaultdict

# Repo kökünü script konumundan bul (deploy/ -> kök)
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
CONTRACTS = os.path.join(ROOT, "op_contracts.json")
OUTPUT = os.path.join(ROOT, "docs", "OP_REFERANSI.md")


def slug(s: str) -> str:
    """Markdown başlık anchor'ı: Türkçe karakterleri sadeleştirip slug üretir."""
    tr = str.maketrans("çğıöşüÇĞİÖŞÜ", "cgiosucgiosu")
    s2 = s.translate(tr).lower()
    out = "".join(c if c.isalnum() else "-" for c in s2)
    while "--" in out:
        out = out.replace("--", "-")
    return out.strip("-")


def fmt_ret(r: str) -> str:
    if not r:
        return "object"
    return r.replace("System.Collections.Generic.", "")


def main():
    d = json.load(open(CONTRACTS, encoding="utf-8"))

    by_cat = defaultdict(list)
    for name, meta in d.items():
        if not isinstance(meta, dict):
            continue
        by_cat[meta.get("category", "Genel")].append((name, meta))

    total = sum(len(v) for v in by_cat.values())
    ncat = len(by_cat)

    L = []
    L.append("# EGBIMOTO — Op Referansı")
    L.append("")
    L.append(f"Toplam **{total} operasyon**, {ncat} kategori.")
    L.append("")
    L.append(
        'Bu dosya `op_contracts.json`\'dan otomatik üretilmiştir '
        "(`deploy/generate_op_referansi.py`). Her op bir manifest adımında "
        '`"op": "<isim>"` olarak kullanılır. 🔒 işareti yazma (transaction '
        "gerektiren) op'ları belirtir."
    )
    L.append("")
    L.append("---")
    L.append("")
    L.append("## İçindekiler")
    L.append("")
    for cat in sorted(by_cat, key=lambda c: c.lower()):
        L.append(f"- [{cat}](#{slug(cat)}) — {len(by_cat[cat])} op")
    L.append("")

    for cat in sorted(by_cat, key=lambda c: c.lower()):
        L.append("")
        L.append(f"## {cat}")
        L.append("")
        for name, meta in sorted(by_cat[cat], key=lambda x: x[0]):
            lock = " 🔒" if meta.get("requires_transaction") else ""
            L.append(f"### `{name}`{lock}")
            L.append("")
            desc = (meta.get("note") or meta.get("description") or "").strip()
            if desc:
                L.append(desc)
                L.append("")
            L.append(f"- **Çıktı:** `{fmt_ret(meta.get('returns'))}`")
            it = meta.get("input_type")
            if it and it not in ("object", "object?", ""):
                L.append(f"- **Girdi:** `{it}`")
            params = meta.get("params") or []
            if params:
                parts = []
                for p in params:
                    presence = p.get("presence") or ("required" if p.get("required") else "optional")
                    if presence == "required":
                        req = "zorunlu"
                    elif presence == "recommended":
                        req = "önerilen"
                    else:
                        req = f"varsayılan: {p.get('default','')!r}"
                    parts.append(f"`{p.get('key')}` ({p.get('type','?')}, {req})")
                L.append(f"- **Parametreler:** {', '.join(parts)}")
            else:
                L.append("- **Parametreler:** yok")
            rr = meta.get("reg_reads") or []
            rw = meta.get("reg_writes") or []
            if rr:
                L.append(f"- **Okur:** {', '.join('`'+x+'`' for x in rr)}")
            if rw:
                L.append(f"- **Yazar:** {', '.join('`'+x+'`' for x in rw)}")
            of = meta.get("out_fields") or []
            if of:
                L.append(f"- **Çıktı alanları:** {', '.join('`'+x+'`' for x in of)}")
            L.append("")

    content = "\n".join(L)
    open(OUTPUT, "w", encoding="utf-8").write(content)
    print(f"OP_REFERANSI.md yazıldı: {total} op, {ncat} kategori, {len(content)} karakter")


if __name__ == "__main__":
    main()
