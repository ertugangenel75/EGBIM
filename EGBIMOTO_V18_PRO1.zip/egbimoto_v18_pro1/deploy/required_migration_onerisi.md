# GetX → RequireX Migrasyon Adayları

Kodda default'suz okunan (`presence: recommended`) VE 356 manifest korpusunda
kullanıldığı her adımda açıkça verilen paramlar. RequireX'e geçiş mevcut
manifestleri KIRMAZ (korpusta %100 veriliyor) ve eksik girdide net hata sağlar.

| Op | Param | Tip | Korpus kullanımı |
|---|---|---|---|
