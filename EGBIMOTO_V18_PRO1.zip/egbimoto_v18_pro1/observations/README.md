# observations/ — Doğrulanmış Runtime Gözlemleri

Bu klasördeki dosyalar **op_contracts.json domain kalibrasyonunun tek girdisi**dir.

## Kural
Bir gözlem buraya girebilmesi için:
1. Gerçek Revit modelinde (MCP session veya add-in üzerinden) çalıştırılmış olmalı
2. Ertugan tarafından sonucu görülüp doğrulanmış olmalı ("evet bu doğru" onayı)
3. `verified_by` alanı zorunlu — kim/nasıl doğrulandığını belirtir

## Eski 356 manifest ile farkı
`_manifests_legacy_backup/` klasöründeki 357 dosya Claude tarafından
**tahminle** yazılmıştı, hiçbiri gerçek modelde test edilmedi. Bu yüzden
domain kalibrasyonunda KULLANILMAZ. Sadece kategori/isim referansı olarak
gerektiğinde manuel bakılabilir — otorite değildir.

## Format
Her dosya bir gözlem kaydı:
```json
{
  "chain": [
    {"step_id": "s1", "op": "kalip_all", "domain_out_observed": "KalipResult"},
    {"step_id": "s2", "op": "poz_match_keynote_aware", "from": "s1", "domain_in_observed": "KalipResult"},
    {"step_id": "s3", "op": "calc_cost", "from": "s2", "domain_in_observed": "PozData"},
    {"step_id": "s4", "op": "export_xlsx", "from": "s3"}
  ],
  "verified_by": "ertugan_mcp_session_2026-06",
  "notes": "EG_OTEL_ERTUGAN_detached modelinde çalıştırıldı, sonuç doğru.",
  "revit_model": "EG_OTEL_ERTUGAN_detached",
  "date": "2026-06-15"
}
```
