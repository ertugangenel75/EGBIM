# EGBIMOTO v15.1 — Domain Kalibrasyonu Dürüstleştirmesi

## Neden bu sürüm çıktı
v15'te op_contracts.json'daki domain_in_accepts listeleri "korpus kalibrasyonu"
(357 manifest) ile genişletiliyordu. Bu 357 manifestin TAMAMI Claude tarafından
tahminle yazılmıştı — hiçbiri gerçek Revit modelinde çalıştırılıp doğrulanmadı.
Yani sistem kendi tahminini kendi tahminiyle doğruluyordu (sirküler, otorite değil).

## Ne değişti

### 1. manifests/ boşaltıldı
- 357 dosya `_manifests_legacy_backup/` içine taşındı (silinmedi, referans için duruyor)
- Aktif `manifests/` klasörü boş — sıfırdan, tek tek doğrulanarak yeniden dolacak

### 2. observations/ klasörü — yeni tek otorite
- Domain kalibrasyonu SADECE buradan besleniyor
- Her dosya `verified_by` alanı zorunlu — gerçek Revit/MCP session'da görülüp
  onaylanmış olmalı
- `verified_by` boş/yok → generate_op_contracts.py otomatik atlar, uyarı basar
- İlk gerçek gözlem eklendi: `kalip_all → poz_match_keynote_aware → calc_cost →
  export_xlsx` zinciri (EG_OTEL_ERTUGAN_detached modelinde doğrulanmış)

### 3. deploy/generate_op_contracts.py
- `calibrate_from_corpus()` → `calibrate_from_observations()`: manifests/ artık
  domain kalibrasyonunda hiç kullanılmıyor (sadece param usage_rate istatistiği
  için, o da artık "taslak" olarak işaretli)
- `[OpDomain(...)]` attribute regex bug'ı düzeltildi: tam nitelenmiş namespace
  (`EGBIMOTO.Core.Ops.Domain.X`) artık doğru yakalanıyor. Önceden attribute
  katmanı fiilen çalışmıyordu (attribute:0 idi, olması gereken en az 1).
- domain_source'ta "+corpus" etiketi tamamen kalktı (25 op'ta vardı → 0)

### 4. deploy/export_ops_for_html.py (YENİ)
- op_contracts.json → pattern_zincir_kurucu.html içindeki `const OPS` bloğunu
  otomatik senkronlar. HTML artık ayrı bir veri kopyası değil, tek SSoT'nin
  export'u.

### 5. deploy/draft_observation_from_mcp.py (YENİ)
- MCP session çıktısından observations/ TASLAĞI üretir (_draft_ önekiyle)
- verified_by BİLEREK BOŞ bırakılır — Ertugan onaylamadan kalibrasyona giremez

### 6. C# — runtime gözlem altyapısı
- `DagTraceRow.OutputShape` eklendi: her başarılı adımın gerçek çalışma zamanı
  çıkış imzasını taşır (örn. `List<Dictionary>[kategori,tip,kat,poz_no,...]`)
  Bilgi amaçlıdır, ManifestLinter/DomainCompatible bunu OTORİTE olarak kullanmaz.
- `McpManifestRunner.StepResult.output_shape` eklendi — MCP'den dönen JSON'da
  artık her adımın gerçek çıkış şekli görünüyor, draft_observation_from_mcp.py
  bunu okuyor.

## Yeni iş akışı (test döngüsü)
1. MCP session'da manifest çalıştır (Revit'e bağlı)
2. Sonucu gör, doğru mu karar ver
3. `python3 deploy/draft_observation_from_mcp.py run_result.json manifest.json`
4. Taslağı gözden geçir, `verified_by` alanını doldur, `_draft_` önekini kaldır,
   `observations/`'a taşı
5. `python3 deploy/generate_op_contracts.py .`
6. `python3 deploy/export_ops_for_html.py .`
7. HTML ve op_contracts.json artık bu gerçek gözlemle kalibre

## Bilinen durum
- domain kapsamı: 436/480 (%90) — attribute:1 linter:132 inferred:303 default:44
- doğrulanmış gözlem sayısı: 1 (kalip_all zinciri)
- Bu sayı arttıkça domain_in_accepts listeleri GERÇEK kanıtla büyüyecek
