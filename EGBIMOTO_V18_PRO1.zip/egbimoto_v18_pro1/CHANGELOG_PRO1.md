# EGBIMOTO V18 PRO1 — Değişiklik Günlüğü (2026-07-06)

## Kritik Düzeltmeler

### 1. inputs/params çakışması (16/16 skill)
ManifestModel.cs'te "inputs" → Params, "params" → sadece inputs yoksa fallback.
Tüm skill template'lerinde hem inputs:{} hem params:{...} vardı → params SESSIZCE ignore ediliyordu.
Fix: tüm parametreler "inputs" alanına taşındı, params alanı kaldırıldı.

### 2. Yanlış parametre adları (exportların çalışmama nedeni)
- export_xlsx: output_path → **file_path**
- ifc_export: output_folder → **output_dir + file_name**
- kalip raporları: **filename + out_dir**
- validate_rebar_ts500: fc → **fck**

### 3. calc_cost 0 TL sorunu (2. neden)
calc_cost varsayılan quantity_field="hacim_m3". Kalıp zincirlerine
**quantity_field: "kalip_m2"** eklendi (kalip_all çıktı alanı).

### 4. op_contracts.json domain inference düzeltmeleri (C# kaynak doğrulamalı)
- filter_by_level: Rows → Elements (List<Element> döndürüyor)
- structural_ts500_section/continuity_check/level_summary/material_check: Scalar → Rows
- kalip_* domain_in: [Structural, Elements] (filter sonrası zincir için)
- selection_to_elements: Elements

### 5. Transaction policy düzeltmeleri
- 4d_program_atama: atomic → per_step (+schedule_gate ile kullanıcı onayı)
- oda_kaplama_atama: atomic → per_step
- mep_aciklik_kontrolu: none → per_step (self-tx op'lar)
- ifc_export_csb2026: none → per_step

### 6. Kopuk zincirler tamir
- ifc_export_csb2026: ifc_map→classify→qa→ifc from zinciri kuruldu + IDS doğrulama eklendi
- qa_trbim_csb2026: merge_validation_reports + validation_summary bağlandı
- elektrik_gerilim_dususu: collect_electrical_equipment + merge eklendi
- kalip_kat_bazli: poz 3'lüsü + merge_rows + doğru quantity_field
- Yanlış op adı: struct_ts500_section → structural_ts500_section

### 7. Profesyonel export standardı (tüm analitik skill'ler)
Her skill 3 çıktı verir: show_table (WPF anlık) + HTML rapor + xlsx (arşiv).
Tüm export adımları required:false — export hatası hesabı durdurmaz.
Kalıp zincirinde kalip_export_xlsx (3 sekmeli BOQ) + kalip_report (pro HTML).

### 8. deploy_2026.ps1
data/, manifest_skills/, op_contracts.json, categories.json artık deploy'a kopyalanıyor.
Hedef: %APPDATA%\Autodesk\Revit\Addins\2026\EGBIMOTO\

## Bilinen Konu
- translate_params: TranslateParamsOp.cs'te EgOp attribute ile kayıtlı, runtime'da ÇALIŞIR
  ama op_contracts.json'da yok. generate_op_contracts.py yeniden çalıştırılınca eklenecek.

## Doğrulama
16/16 skill: 0 domain hatası, 0 TX çakışması, 0 tanımsız op, 0 yanlış parametre.
Tüm param adları C# kaynak kodundan doğrulandı.
