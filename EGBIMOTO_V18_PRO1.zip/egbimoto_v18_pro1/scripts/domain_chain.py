#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EGBIMOTO v15 — Domain Zincir Motoru (Pattern Üret altyapısı)

op_contracts.json'daki domain_in / domain_out alanlarını bir yönlü grafik
olarak okur ve:
  1. validate_chain(ops)   → verilen op dizisinin domain uyumunu denetler
  2. suggest_next(op)      → bir op'un çıktısına bağlanabilecek geçerli op'lar
  3. build_chain(goal)     → hedef domain'e (ör. Scalar=export) ulaşan zincir önerir
  4. producers(domain)     → belirli bir domain'i ÜRETEN op'lar
  5. consumers(domain)     → belirli bir domain'i TÜKETEN op'lar

Kural: "Any" joker — hem üretici hem tüketici olarak her domain'le uyumludur.

Bu modül UI (Pattern Üret penceresi) ve MCP server tarafından çağrılır.
Deterministiktir, LLM gerektirmez.

Kullanım:
    python3 scripts/domain_chain.py suggest kalip_all
    python3 scripts/domain_chain.py chain Structural Scalar
    python3 scripts/domain_chain.py validate collect_walls kalip_all kalip_summary show_result
"""
import json
import os
import sys
from collections import defaultdict, deque

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTRACTS = os.path.join(ROOT, "op_contracts.json")


def load():
    c = json.load(open(CONTRACTS, encoding="utf-8"))
    ops = {}
    for name, meta in c.items():
        # domain_in_accepts varsa onu kullan; yoksa domain_in'e düş
        accepts = meta.get("domain_in_accepts") or [meta.get("domain_in", "Any")]
        ops[name] = (meta.get("domain_in", "Any"), meta.get("domain_out", "Any"),
                     meta.get("category", "Genel"), tuple(accepts))
    return ops


# Domain hiyerarşisi: özel tabular domainler "Rows" üst-türünün alt-türleridir.
# Hepsi altta List<Dictionary> taşır; bu yüzden bir üretici PozData/KalipResult/
# Report verdiğinde, Rows bekleyen bir tüketici (show_table, export_*, filter_rows)
# bunu kabul eder. Ters yön (Rows → PozData bekleyen) uyumsuzdur: genel veri özel
# semantik yerine geçemez. Bu, 357 manifestlik korpustan kalibre edilmiştir.
_ROWS_SUBTYPES = {"Rows", "PozData", "KalipResult", "Report", "WbsData"}


def _pair_ok(producer_out, consumer_in):
    """Tek çift uyumu (hiyerarşi dahil)."""
    if producer_out == "Any" or consumer_in == "Any":
        return True
    if producer_out == consumer_in:
        return True
    if consumer_in == "Rows" and producer_out in _ROWS_SUBTYPES:
        return True
    return False


def compatible(producer_out, consumer_in_or_accepts):
    """Yukarı akış çıktısı, aşağı akış girdisiyle uyumlu mu?

    consumer_in_or_accepts:
      - str  → tekil domain (geriye dönük uyum)
      - list/tuple → kabul-listesi; herhangi biriyle uyum yeterli

    Kurallar:
      1. Any her iki yönde joker.
      2. Aynı domain → uyumlu.
      3. Alt-tür → üst-tür (Rows): özel tabular domain, Rows bekleyeni besler.
      4. Kabul-listesi: producer_out listedeki herhangi bir domainle uyumluysa OK.
    """
    if isinstance(consumer_in_or_accepts, (list, tuple)):
        return any(_pair_ok(producer_out, ci) for ci in consumer_in_or_accepts)
    return _pair_ok(producer_out, consumer_in_or_accepts)


def producers(ops, domain):
    """domain'i üreten (domain_out == domain veya Any) op'lar."""
    return sorted(n for n, (di, do, cat, acc) in ops.items()
                  if do == domain or do == "Any")


def consumers(ops, domain):
    """domain'i tüketebilen op'lar (kabul-listesi üzerinden)."""
    return sorted(n for n, (di, do, cat, acc) in ops.items()
                  if compatible(domain, list(acc)))


def suggest_next(ops, op_name, limit=40):
    """op_name'in çıktısına bağlanabilecek geçerli op'ları döndürür.

    Sıralama: domain'e ÖZEL eşleşen op'lar (domain_in == out) önce,
    Any-jenerik op'lar (domain_in == Any) sonra. Böylece Pattern Üret UI
    en anlamlı devamları üstte gösterir. Her grup kendi içinde alfabetik."""
    if op_name not in ops:
        return None
    _, out, _ = ops[op_name]
    specific, generic = [], []
    for n, (di, do, cat, acc) in ops.items():
        if n == op_name or not compatible(out, list(acc)):
            continue
        # "özel": op çıktımızı tam (Any olmayan) domain olarak kabul ediyorsa
        if out != "Any" and out in acc and "Any" not in acc:
            specific.append(n)
        else:
            generic.append(n)
    ranked = sorted(specific) + sorted(generic)
    return out, ranked[:limit]


def validate_chain(ops, chain):
    """Bir op dizisinin ardışık domain uyumunu denetler.
    (ok, errors) döndürür; errors = [(index, msg), ...]"""
    errors = []
    for i in range(1, len(chain)):
        prev, cur = chain[i - 1], chain[i]
        if prev not in ops:
            errors.append((i - 1, f"'{prev}' op_contracts'ta yok"))
            continue
        if cur not in ops:
            errors.append((i, f"'{cur}' op_contracts'ta yok"))
            continue
        prev_out = ops[prev][1]
        cur_acc = list(ops[cur][3])
        if not compatible(prev_out, cur_acc):
            errors.append((i,
                f"zincir kopuk: '{prev}'→{prev_out} ama '{cur}' {cur_acc} bekliyor"))
    return len(errors) == 0, errors


def build_chain(ops, start_domain, goal_domain, max_depth=6):
    """start_domain'den goal_domain'e ulaşan en kısa op zincirini BFS ile bulur.
    Domain düğümleri üzerinde yürür; her kenar bir op'tur.
    Sadeleştirme: her (in,out) çifti için tek temsilci op seçilir."""
    # domain → [(op, out_domain)] kenarları
    edges = defaultdict(list)
    for n, (di, do, cat, acc) in ops.items():
        edges[di].append((n, do))
        if di != "Any":
            edges["Any"].append((n, do))  # Any-girişli op her domain'den bağlanabilir

    # BFS
    q = deque([(start_domain, [])])
    seen = {start_domain}
    while q:
        dom, path = q.popleft()
        if len(path) > max_depth:
            continue
        if dom == goal_domain and path:
            return path
        for op, out in edges.get(dom, []) + edges.get("Any", []):
            eff_out = goal_domain if out == "Any" and dom != goal_domain else out
            key = eff_out
            if key in seen:
                continue
            seen.add(key)
            q.append((eff_out, path + [op]))
    return None


def _fmt(ops, name):
    di, do, cat, acc = ops[name]
    return f"{name}  [{di} → {do}]  ({cat})"


def main():
    ops = load()
    if len(sys.argv) < 2:
        print(__doc__)
        # özet istatistik
        by_out = defaultdict(int)
        for _, (di, do, _c, _a) in ops.items():
            by_out[do] += 1
        print("\nÇıktı domain dağılımı:")
        for d, n in sorted(by_out.items(), key=lambda x: -x[1]):
            print(f"  {d:14} {n}")
        return

    cmd = sys.argv[1]
    if cmd == "suggest":
        op = sys.argv[2]
        r = suggest_next(ops, op)
        if r is None:
            print(f"'{op}' bulunamadı"); return
        out, nxt = r
        print(f"{op} çıktısı: {out}")
        print(f"Bağlanabilecek {len(nxt)} op (ilk 40):")
        for n in nxt:
            print("  " + _fmt(ops, n))
    elif cmd == "chain":
        start, goal = sys.argv[2], sys.argv[3]
        path = build_chain(ops, start, goal)
        if path is None:
            print(f"{start} → {goal}: zincir bulunamadı")
        else:
            print(f"{start} → {goal} ({len(path)} adım):")
            for n in path:
                print("  " + _fmt(ops, n))
    elif cmd == "validate":
        chain = sys.argv[2:]
        ok, errs = validate_chain(ops, chain)
        print("Zincir:", " → ".join(chain))
        if ok:
            print("✓ Domain uyumlu")
        else:
            print("✗ Uyumsuz:")
            for i, m in errs:
                print(f"  [adım {i}] {m}")
    elif cmd == "producers":
        for n in producers(ops, sys.argv[2]):
            print("  " + _fmt(ops, n))
    elif cmd == "consumers":
        for n in consumers(ops, sys.argv[2]):
            print("  " + _fmt(ops, n))
    else:
        print(f"bilinmeyen komut: {cmd}")


if __name__ == "__main__":
    main()
