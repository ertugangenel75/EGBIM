@echo off
call "%~dp0deploy_2026.bat" %*
