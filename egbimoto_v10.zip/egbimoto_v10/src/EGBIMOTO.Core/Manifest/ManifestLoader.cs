using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace EGBIMOTO.Core.Manifest
{
    public static class ManifestLoader
    {
        private static readonly JsonSerializerOptions _opts = new()
        {
            PropertyNameCaseInsensitive  = true,
            ReadCommentHandling          = JsonCommentHandling.Skip,
            AllowTrailingCommas          = true,
            DefaultIgnoreCondition       = JsonIgnoreCondition.WhenWritingNull,
        };

        // ── Tek dosya yükle ────────────────────────────────────────────────────

        public static EgManifest Load(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException($"Manifest bulunamadı: {filePath}");

            var json = File.ReadAllText(filePath, System.Text.Encoding.UTF8);
            var manifest = JsonSerializer.Deserialize<EgManifest>(json, _opts)
                ?? throw new InvalidOperationException($"Manifest parse edilemedi: {filePath}");

            // Runtime meta
            manifest.FilePath   = filePath;
            manifest.FolderName = Path.GetFileName(Path.GetDirectoryName(filePath) ?? "");

            // Category yoksa klasörden türet
            if (string.IsNullOrWhiteSpace(manifest.Category))
                manifest.Category = manifest.FolderName;

            // Step params içindeki JsonElement'leri unwrap et
            foreach (var step in manifest.Steps)
                if (step.Params is not null)
                    step.Params = UnwrapDict(step.Params);

            return manifest;
        }


        // ── JSON string'ten yükle (AI generator için) ─────────────────────────

        public static EgManifest LoadFromJson(string jsonText)
        {
            var manifest = JsonSerializer.Deserialize<EgManifest>(jsonText, _opts)
                ?? throw new InvalidOperationException("Manifest parse edilemedi");

            foreach (var step in manifest.Steps)
                if (step.Params is not null)
                    step.Params = UnwrapDict(step.Params);

            return manifest;
        }

        // ── Klasör tara ────────────────────────────────────────────────────────

        /// <summary>
        /// Belirtilen klasördeki tüm *.json dosyalarını özyinelemeli tarar.
        /// Browser bu listeyi kullanır.
        ///
        /// Gizleme kuralları (öncelik sırası):
        ///   1. Klasör adı "_" ile başlıyorsa → atlanır  (_draft, _archive)
        ///   2. Klasör adı ".disabled" ile bitiyorsa → atlanır
        ///   3. excludeFolders listesinde varsa → atlanır ("legacy_samples" default)
        ///
        /// Default excludeFolders = ["legacy_samples"] — geliştirme örnekleri gizlenir.
        /// Tümünü görmek için: LoadFolder(root, excludeFolders: null)
        /// </summary>
        public static List<EgManifest> LoadFolder(
            string rootPath,
            IEnumerable<string>? excludeFolders = null)
        {
            if (!Directory.Exists(rootPath)) return new();

            // Varsayılan: legacy_samples gizli
            var excluded = new HashSet<string>(
                excludeFolders ?? new[] { "legacy_samples" },
                StringComparer.OrdinalIgnoreCase);

            return Directory
                .GetFiles(rootPath, "*.json", SearchOption.AllDirectories)
                .Where(f =>
                {
                    // Dosya yolundaki TÜM segment'leri kontrol et
                    var parts = f.Split(Path.DirectorySeparatorChar,
                                        Path.AltDirectorySeparatorChar);
                    foreach (var part in parts)
                    {
                        if (part.StartsWith("_"))             return false; // _draft klasörü
                        if (part.EndsWith(".disabled"))       return false; // klasör.disabled
                        if (excluded.Contains(part))          return false; // legacy_samples
                    }
                    return true;
                })
                .OrderBy(f => f)
                .Select(f =>
                {
                    try   { return Load(f); }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine(
                            $"[ManifestLoader] Parse hatası: {Path.GetFileName(f)}\n{ex.Message}");
                        return null;
                    }
                })
                .Where(m => m is not null)
                .Cast<EgManifest>()
                .ToList();
        }

        // ── JsonElement → native C# ────────────────────────────────────────────

        private static Dictionary<string, object?> UnwrapDict(Dictionary<string, object?> dict)
            => dict.ToDictionary(kv => kv.Key, kv => Unwrap(kv.Value));

        private static object? Unwrap(object? val)
        {
            if (val is not JsonElement je) return val;

            return je.ValueKind switch
            {
                JsonValueKind.String => je.GetString(),
                JsonValueKind.Number => je.TryGetInt64(out var l)  ? (object?)l
                                      : je.TryGetDouble(out var d) ? d
                                      : je.GetRawText(),
                JsonValueKind.True   => true,
                JsonValueKind.False  => false,
                JsonValueKind.Null   => null,
                JsonValueKind.Array  => je.EnumerateArray()
                                          .Select(e => Unwrap(e))
                                          .ToList(),
                JsonValueKind.Object => je.EnumerateObject()
                                          .ToDictionary(p => p.Name, p => Unwrap(p.Value)),
                _                   => null
            };
        }
    }
}
