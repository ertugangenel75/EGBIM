using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace EGBIMOTO.Core.Manifest
{
    public sealed class EgManifest
    {
        [JsonPropertyName("title")]
        public string Title { get; set; } = "";

        [JsonPropertyName("description")]
        public string Description { get; set; } = "";

        [JsonPropertyName("category")]
        public string Category { get; set; } = "";

        [JsonPropertyName("version")]
        public string? Version { get; set; }

        [JsonPropertyName("tags")]
        public List<string> Tags { get; set; } = new();

        [JsonPropertyName("pre_checks")]
        public List<EgPreCheck>? PreChecks { get; set; }

        [JsonPropertyName("steps")]
        public List<EgStep> Steps { get; set; } = new();

        [JsonPropertyName("transaction_policy")]
        public string TransactionPolicy { get; set; } = "none";

        [JsonIgnore] public bool IsAtomic
            => TransactionPolicy.Equals("atomic", StringComparison.OrdinalIgnoreCase);

        [JsonIgnore] public bool IsPreview
            => TransactionPolicy.Equals("preview", StringComparison.OrdinalIgnoreCase);

        [JsonIgnore] public string FilePath   { get; set; } = "";
        [JsonIgnore] public string FolderName { get; set; } = "";
    }

    public sealed class EgPreCheck
    {
        [JsonPropertyName("type")]
        public string Type { get; set; } = "";

        [JsonPropertyName("categories")]
        public List<string>? Categories { get; set; }

        [JsonPropertyName("key")]
        public string? Key { get; set; }

        [JsonPropertyName("min_count")]
        public int MinCount { get; set; } = 1;

        [JsonPropertyName("on_fail")]
        public string OnFail { get; set; } = "ABORT";

        [JsonPropertyName("message")]
        public string? Message { get; set; }
    }

    public sealed class EgStep
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = "";

        [JsonPropertyName("op")]
        public string Op { get; set; } = "";

        [JsonPropertyName("from")]
        public string? From { get; set; }

        [JsonPropertyName("from_many")]
        public List<string>? FromMany { get; set; }

        [JsonPropertyName("inputs")]
        public Dictionary<string, object?>? Params { get; set; }

        [JsonPropertyName("params")]
        public Dictionary<string, object?>? ParamsLegacy
        {
            get => null;
            set { if (Params == null && value != null) Params = value; }
        }

        [JsonPropertyName("required")]
        public bool Required { get; set; } = true;

        [JsonPropertyName("cache")]
        public bool? Cache { get; set; }

        [JsonPropertyName("depends_on")]
        public List<string>? DependsOn { get; set; }

        [JsonPropertyName("condition")]
        public string? Condition { get; set; }
    }
}
