using System;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using EGBIMOTO.Addin.Server;

namespace EGBIMOTO.Addin.Commands
{
    /// <summary>
    /// EGBIMOTO MCP Server'ı başlatıp durduran ribbon komutu.
    ///
    /// Çalışıyorsa durdurur, durmuşsa başlatır (toggle). Başlatıldığında Claude Desktop
    /// (veya başka bir MCP ajanı) Python köprüsü üzerinden EGBIMOTO'ya bağlanabilir.
    ///
    /// ExternalEvent.Create ana thread gerektirdiğinden, bu komut (Revit tarafından ana
    /// thread'de çalıştırılır) doğru başlatma noktasıdır.
    /// </summary>
    [Transaction(TransactionMode.Manual)]
    public sealed class McpServerToggleCommand : IExternalCommand
    {
        // Sabit port — Claude Desktop config ile eşleşmeli (claude_desktop_config.example.json)
        private const int DefaultPort = 5577;

        public Result Execute(ExternalCommandData data, ref string msg, ElementSet els)
        {
            try
            {
                var mgr = McpServerManager.Instance;

                if (mgr.IsRunning)
                {
                    mgr.Stop();
                    TaskDialog.Show("EGBIMOTO MCP Server",
                        "MCP Server durduruldu.\n\nClaude Desktop artık Revit'e bağlanamaz.");
                    return Result.Succeeded;
                }

                // Başlat — EgbimotoApp.Registry ve ContractsPath ile bağla
                mgr.Start(
                    EgbimotoApp.Registry,
                    () => EgbimotoApp.ContractsPath,
                    DefaultPort,
                    token: null); // İsteğe bağlı token; kurumsal ortamda doldurulabilir

                TaskDialog.Show("EGBIMOTO MCP Server",
                    $"MCP Server başlatıldı (port {DefaultPort}).\n\n" +
                    "Claude Desktop artık bu Revit modeline bağlanabilir.\n\n" +
                    "• Katalog:  http://127.0.0.1:" + DefaultPort + "/ops\n" +
                    "• Durum:    http://127.0.0.1:" + DefaultPort + "/health\n\n" +
                    "Claude Desktop'ta 'egbimoto' bağlandıysa, doğrudan Türkçe komut " +
                    "verebilirsiniz (örn. 'tüm kapıları say ve rapor çıkar').");

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                msg = $"MCP Server başlatılamadı: {ex.Message}";
                TaskDialog.Show("EGBIMOTO MCP Server — Hata", msg);
                return Result.Failed;
            }
        }
    }
}
