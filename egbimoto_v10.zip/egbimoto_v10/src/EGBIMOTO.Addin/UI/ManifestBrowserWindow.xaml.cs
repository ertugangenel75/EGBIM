using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using Autodesk.Revit.UI;
using EGBIMOTO.Core.Manifest;

namespace EGBIMOTO.Addin.UI
{
    public partial class ManifestBrowserWindow : Window
    {
        private readonly ExternalCommandData _commandData;
        private List<EgManifest>             _allManifests = new();
        private EgManifest?                  _selected;
        private string?                      _activeCategory;     // A: seçili kategori (null = tümü)
        private string?                      _lastReportPath;     // D: son üretilen rapor dosyası
        private readonly List<StepVm>        _liveSteps = new();  // C: çalışırken güncellenen adım VM'leri

        // ── View Model ────────────────────────────────────────────────────────

        private sealed class ManifestVm
        {
            public EgManifest  Manifest   { get; init; } = null!;
            public LintResult  Lint       { get; init; } = null!;
            public string      Title      => Manifest.Title;
            public string      Category   => Manifest.Category;
            public string      TagText    => Lint.TagText;
            public string      ScoreText  => $"{Lint.Score}/10 · {Lint.Pattern} · {Lint.StepCount} adım";
            public SolidColorBrush TagBrush => new(ColorFromHex(Lint.TagColor));

            private static Color ColorFromHex(string hex)
            {
                hex = hex.TrimStart('#');
                return Color.FromRgb(
                    Convert.ToByte(hex[..2], 16),
                    Convert.ToByte(hex[2..4], 16),
                    Convert.ToByte(hex[4..6], 16));
            }
        }

        // C: adım VM'i — çalışma sırasında StatusIcon/StatusBrush/RightText güncellenir
        private sealed class StepVm : System.ComponentModel.INotifyPropertyChanged
        {
            public string  Id  { get; init; } = "";
            public string  Op  { get; init; } = "";
            public string? From { get; init; }

            private string _statusIcon = "○";
            public string StatusIcon { get => _statusIcon; set { _statusIcon = value; Raise(nameof(StatusIcon)); } }

            private Brush _statusBrush = new SolidColorBrush(Color.FromRgb(0x90, 0x90, 0xA8));
            public Brush StatusBrush { get => _statusBrush; set { _statusBrush = value; Raise(nameof(StatusBrush)); } }

            private Brush _rowBg = new SolidColorBrush(Color.FromRgb(0x31, 0x31, 0x50));
            public Brush RowBg { get => _rowBg; set { _rowBg = value; Raise(nameof(RowBg)); } }

            private string _rightText = "";
            public string RightText
            {
                get => _rightText.Length > 0 ? _rightText
                     : (string.IsNullOrEmpty(From) ? "" : $"← {From}");
                set { _rightText = value; Raise(nameof(RightText)); }
            }

            public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
            private void Raise(string n) => PropertyChanged?.Invoke(this, new(n));
        }

        // ── Ctor ──────────────────────────────────────────────────────────────

        public ManifestBrowserWindow(ExternalCommandData commandData)
        {
            InitializeComponent();
            _commandData = commandData;
            Loaded += (_, _) => LoadManifests();
        }

        // ── Yükleme ───────────────────────────────────────────────────────────

        private void LoadManifests()
        {
            try
            {
                _allManifests = ManifestLoader.LoadFolder(EgbimotoApp.ManifestRoot);
                txtManifestCount.Text = $"{_allManifests.Count} manifest yüklendi";
                BuildCategoryChips();      // A
                ApplyFilter();
            }
            catch (Exception ex) { AppendLog($"Yükleme hatası: {ex.Message}"); }
        }

        // ── A: Kategori çipleri ───────────────────────────────────────────────

        private void BuildCategoryChips()
        {
            pnlCategories.Children.Clear();

            // "Tümü" + manifest sayısına göre azalan sıralı kategoriler
            var cats = _allManifests
                .GroupBy(m => string.IsNullOrWhiteSpace(m.Category) ? "genel" : m.Category)
                .OrderByDescending(g => g.Count())
                .Select(g => (Name: g.Key, Count: g.Count()))
                .ToList();

            AddChip($"Tümü ({_allManifests.Count})", null, isActive: true);
            foreach (var (name, count) in cats)
                AddChip($"{name} ({count})", name, isActive: false);
        }

        private void AddChip(string label, string? category, bool isActive)
        {
            var chip = new ToggleButton
            {
                Content   = label,
                Style     = (Style)FindResource("CategoryChip"),
                IsChecked = isActive,
                Tag       = category,
            };
            chip.Checked += (s, _) =>
            {
                // Tek seçim: diğer çipleri kapat
                foreach (var c in pnlCategories.Children.OfType<ToggleButton>())
                    if (!ReferenceEquals(c, s)) c.IsChecked = false;
                _activeCategory = category;
                ApplyFilter();
            };
            chip.Unchecked += (s, _) =>
            {
                // Hiçbiri seçili değilse "Tümü"e dön
                if (!pnlCategories.Children.OfType<ToggleButton>().Any(c => c.IsChecked == true))
                {
                    if (pnlCategories.Children.Count > 0 && pnlCategories.Children[0] is ToggleButton first)
                        first.IsChecked = true;
                }
            };
            pnlCategories.Children.Add(chip);
        }

        // ── Filtre (arama + kategori birlikte) ────────────────────────────────

        private void ApplyFilter()
        {
            var search = txtSearch.Text ?? "";

            IEnumerable<EgManifest> q = _allManifests;

            // A: kategori filtresi
            if (!string.IsNullOrWhiteSpace(_activeCategory))
                q = q.Where(m => string.Equals(m.Category, _activeCategory, StringComparison.OrdinalIgnoreCase));

            // Arama filtresi (başlık + kategori + açıklama + etiket)
            if (!string.IsNullOrWhiteSpace(search))
                q = q.Where(m =>
                    m.Title.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                    m.Category.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                    m.Description.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                    m.Tags.Any(t => t.Contains(search, StringComparison.OrdinalIgnoreCase)));

            var filtered = q.ToList();

            var vms = filtered.Select(m => new ManifestVm
            {
                Manifest = m,
                Lint     = ManifestLinter.Lint(m, EgbimotoApp.Registry)
            }).ToList();

            lstManifests.ItemsSource = vms;
            txtManifestCount.Text    = $"{filtered.Count} / {_allManifests.Count} manifest";
        }

        // ── Seçim ─────────────────────────────────────────────────────────────

        private void LstManifests_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var vm = lstManifests.SelectedItem as ManifestVm;
            _selected = vm?.Manifest;

            // Yeni seçimde önceki çalıştırma sonuçlarını temizle
            ResetRunUi();

            if (_selected is null)
            {
                pnlDetail.Visibility      = Visibility.Collapsed;
                txtNoSelection.Visibility = Visibility.Visible;
                btnRun.IsEnabled          = false;
                return;
            }

            pnlDetail.Visibility      = Visibility.Visible;
            txtNoSelection.Visibility = Visibility.Collapsed;
            btnRun.IsEnabled          = true;

            txtDetailTitle.Text = _selected.Title;
            txtDetailDesc.Text  = string.IsNullOrWhiteSpace(_selected.Description) ? "(Açıklama yok)" : _selected.Description;
            txtFilePath.Text    = _selected.FilePath;

            // Skor rozeti
            var lint = vm!.Lint;
            scoreBadge.Background = ColorFromHexBrush(lint.TagColor);
            txtScore.Text         = $"{lint.Score}/10";

            // B: Tag çipleri
            RenderTagChips(_selected.Tags);

            // Faz göstergeleri
            RenderPhaseIcons(lint);

            // Hata/uyarı listesi
            var issues = lint.Errors.Concat(lint.Warnings).ToList();
            if (issues.Count > 0)
            {
                lstLintIssues.ItemsSource   = issues;
                scrollLintIssues.Visibility = Visibility.Visible;
            }
            else scrollLintIssues.Visibility = Visibility.Collapsed;

            // Adım listesi (C: StepVm — çalışırken güncellenecek)
            _liveSteps.Clear();
            foreach (var s in _selected.Steps)
                _liveSteps.Add(new StepVm { Id = s.Id, Op = s.Op, From = s.From });
            lstSteps.ItemsSource = _liveSteps;

            txtStatus.Text = lint.Summary;
        }

        // ── B: Tag çipleri ────────────────────────────────────────────────────

        private void RenderTagChips(List<string> tags)
        {
            pnlTags.Children.Clear();
            if (tags == null || tags.Count == 0)
            {
                pnlTagsSection.Visibility = Visibility.Collapsed;
                return;
            }
            pnlTagsSection.Visibility = Visibility.Visible;

            foreach (var tag in tags)
            {
                var border = new Border
                {
                    Background      = new SolidColorBrush(Color.FromRgb(0x3A, 0x32, 0x52)),
                    BorderBrush     = new SolidColorBrush(Color.FromRgb(0xBD, 0x93, 0xF9)),
                    BorderThickness = new Thickness(1),
                    CornerRadius    = new CornerRadius(10),
                    Padding         = new Thickness(8, 2, 8, 2),
                    Margin          = new Thickness(0, 0, 5, 4),
                    Cursor          = System.Windows.Input.Cursors.Hand,
                };
                border.Child = new TextBlock
                {
                    Text       = "#" + tag,
                    FontSize   = 10,
                    Foreground = new SolidColorBrush(Color.FromRgb(0xBD, 0x93, 0xF9))
                };
                // B: çipe tıkla → o tag'le ara
                var captured = tag;
                border.MouseLeftButtonUp += (_, _) =>
                {
                    txtSearch.Text = captured;  // TextChanged → ApplyFilter tetiklenir
                };
                pnlTags.Children.Add(border);
            }
        }

        private void RenderPhaseIcons(LintResult lint)
        {
            pnlPhases.Children.Clear();

            void AddPhase(string label, bool present)
            {
                var border = new Border
                {
                    CornerRadius = new CornerRadius(3),
                    Padding      = new Thickness(5, 2, 5, 2),
                    Margin       = new Thickness(0, 0, 4, 3),
                    Background   = present
                        ? new SolidColorBrush(Color.FromRgb(0x28, 0x6B, 0x3F))
                        : new SolidColorBrush(Color.FromRgb(0x5A, 0x28, 0x28)),
                };
                border.Child = new TextBlock
                {
                    Text       = (present ? "✓ " : "✗ ") + label,
                    FontSize   = 9,
                    FontWeight = FontWeights.Bold,
                    Foreground = present
                        ? new SolidColorBrush(Color.FromRgb(0x50, 0xFA, 0x7B))
                        : new SolidColorBrush(Color.FromRgb(0xFF, 0x55, 0x55))
                };
                pnlPhases.Children.Add(border);
            }

            AddPhase("PRECHECK",  lint.HasPrecheck);
            AddPhase("COLLECT",   lint.HasCollect);
            AddPhase("VALIDATE",  lint.HasValidate);
            AddPhase("AGGREGATE", lint.HasAggregate);
            AddPhase("SUMMARY",   lint.HasSummary);
            AddPhase("ROWS",      lint.HasRows);
            AddPhase("EXPORT",    lint.HasExport);

            var patternBorder = new Border
            {
                CornerRadius    = new CornerRadius(3),
                Padding         = new Thickness(5, 2, 5, 2),
                Margin          = new Thickness(8, 0, 0, 3),
                Background      = new SolidColorBrush(Color.FromRgb(0x28, 0x2A, 0x4A)),
                BorderBrush     = new SolidColorBrush(Color.FromRgb(0x6C, 0x63, 0xFF)),
                BorderThickness = new Thickness(1)
            };
            patternBorder.Child = new TextBlock
            {
                Text       = lint.Pattern,
                FontSize   = 9,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(0xBD, 0x93, 0xF9))
            };
            pnlPhases.Children.Add(patternBorder);
        }

        // ── Arama ─────────────────────────────────────────────────────────────

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
            => ApplyFilter();

        // ── Çalıştır (C + D) ──────────────────────────────────────────────────

        private async void BtnRun_Click(object sender, RoutedEventArgs e)
        {
            if (_selected is null) return;

            ResetRunUi();
            btnRun.IsEnabled = false;
            txtStatus.Text   = $"Çalışıyor: {_selected.Title}...";
            txtLog.Text      = "";

            var manifest    = _selected;
            var commandData = _commandData;
            var sw          = System.Diagnostics.Stopwatch.StartNew();
            int totalSteps  = manifest.Steps.Count;
            int doneSteps   = 0;

            // C: adım callback — her op bitince UI güncelle
            void OnStep(string stepId, string op, long ms, bool success)
            {
                Dispatcher.Invoke(() =>
                {
                    var vm = _liveSteps.FirstOrDefault(s =>
                        string.Equals(s.Id, stepId, StringComparison.OrdinalIgnoreCase));
                    if (vm != null)
                    {
                        vm.StatusIcon  = success ? "✓" : "✗";
                        vm.StatusBrush = success
                            ? new SolidColorBrush(Color.FromRgb(0x50, 0xFA, 0x7B))
                            : new SolidColorBrush(Color.FromRgb(0xFF, 0x55, 0x55));
                        vm.RowBg = success
                            ? new SolidColorBrush(Color.FromRgb(0x22, 0x3A, 0x2A))
                            : new SolidColorBrush(Color.FromRgb(0x3A, 0x22, 0x22));
                        vm.RightText = $"{ms}ms";
                    }

                    doneSteps++;
                    var pct = totalSteps > 0 ? (double)doneSteps / totalSteps : 0;
                    AnimateProgress(pct);
                    txtProgress.Text = $"{doneSteps}/{totalSteps}";

                    AppendLog($"{(success ? "✓" : "✗")} {stepId} ({op}) {ms}ms");
                }, System.Windows.Threading.DispatcherPriority.Background);
            }

            ManifestRunResult result;
            try
            {
                result = await Dispatcher.InvokeAsync(() =>
                {
                    if (manifest.IsPreview)
                        return EgbimotoAppPreviewExtension.RunPreviewManifest(commandData, manifest);
                    else
                        return EgbimotoApp.RunManifest(commandData, manifest, OnStep);
                }, System.Windows.Threading.DispatcherPriority.Background);
            }
            catch (Exception ex)
            {
                sw.Stop();
                txtStatus.Text = $"❌ {ex.Message}";
                AppendLog($"İstisna ({sw.ElapsedMilliseconds}ms): {ex.Message}");
                btnRun.IsEnabled = true;
                return;
            }

            sw.Stop();

            // Tüm log satırlarını da göster (op'ların kendi ctx.Log çıktıları)
            var log = new StringBuilder(txtLog.Text);
            foreach (var line in result.Log)
                if (!txtLog.Text.Contains(line)) log.AppendLine(line);
            txtLog.Text = log.ToString();
            logScroll.ScrollToBottom();

            var cancelled = result.Success && result.ErrorMessage?.Contains("iptal") == true;

            // C: progress'i tamamla
            AnimateProgress(cancelled ? 0 : 1.0);

            // D: telemetri rozeti
            ShowTelemetry(result, sw.ElapsedMilliseconds);

            // D: rapor dosyası varsa "Raporu Aç" göster
            _lastReportPath = FindReportPath(result);
            btnOpenReport.Visibility = _lastReportPath != null ? Visibility.Visible : Visibility.Collapsed;

            txtStatus.Text = cancelled    ? $"⏹ İptal — {manifest.Title}"
                : result.Success ? $"✅ Tamamlandı — {manifest.Title}"
                : $"❌ Hata [{result.ErrorStep}]: {result.ErrorMessage}";
            txtStatus.Foreground = result.Success
                ? (cancelled ? (Brush)FindResource("AccentWarn") : (Brush)FindResource("AccentGreen"))
                : (Brush)FindResource("AccentRed");

            btnRun.IsEnabled = true;
        }

        // ── D: Telemetri ──────────────────────────────────────────────────────

        private void ShowTelemetry(ManifestRunResult r, long wallMs)
        {
            // DagExecutor telemetrisi yoksa (preview yolu) wall-clock kullan
            var steps  = r.TotalSteps > 0 ? r.TotalSteps : _liveSteps.Count;
            var ms     = r.DurationMs > 0 ? r.DurationMs : wallMs;
            var parts  = new List<string> { $"{steps} adım", $"{ms}ms" };
            if (r.CachedSteps > 0)  parts.Add($"⚡{r.CachedSteps} önbellek");
            if (r.SkippedSteps > 0) parts.Add($"⏭{r.SkippedSteps} atlandı");

            txtTelemetry.Text       = string.Join("  ·  ", parts);
            telemetryBadge.Visibility = Visibility.Visible;
        }

        // ── D: Rapor dosyası tespiti ──────────────────────────────────────────

        private static string? FindReportPath(ManifestRunResult r)
        {
            // Export op'ları dosya yolunu vars'a yazar. Son geçerli .html/.xlsx/.pdf yolunu bul.
            foreach (var v in r.Vars.Values.Reverse())
            {
                if (v is string s && LooksLikeReport(s) && File.Exists(s))
                    return s;
            }
            return null;
        }

        private static bool LooksLikeReport(string s)
        {
            var ext = Path.GetExtension(s).ToLowerInvariant();
            return ext is ".html" or ".xlsx" or ".pdf" or ".csv";
        }

        private void BtnOpenReport_Click(object sender, RoutedEventArgs e)
        {
            if (_lastReportPath == null || !File.Exists(_lastReportPath)) return;
            try
            {
                System.Diagnostics.Process.Start(
                    new System.Diagnostics.ProcessStartInfo(_lastReportPath) { UseShellExecute = true });
            }
            catch (Exception ex) { AppendLog($"Rapor açılamadı: {ex.Message}"); }
        }

        // ── C: Progress animasyonu ────────────────────────────────────────────

        private void AnimateProgress(double pct)
        {
            pct = Math.Max(0, Math.Min(1, pct));
            // progressFill genişliği = parent genişliği * pct
            if (progressFill.Parent is FrameworkElement parent && parent.ActualWidth > 0)
                progressFill.Width = parent.ActualWidth * pct;
        }

        private void ResetRunUi()
        {
            progressFill.Width        = 0;
            txtProgress.Text          = "";
            telemetryBadge.Visibility = Visibility.Collapsed;
            btnOpenReport.Visibility  = Visibility.Collapsed;
            _lastReportPath           = null;
            // Adım ikonlarını sıfırla
            foreach (var s in _liveSteps)
            {
                s.StatusIcon  = "○";
                s.StatusBrush = new SolidColorBrush(Color.FromRgb(0x90, 0x90, 0xA8));
                s.RowBg       = new SolidColorBrush(Color.FromRgb(0x31, 0x31, 0x50));
                s.RightText   = "";
            }
        }

        // ── Manifest Üret ─────────────────────────────────────────────────────

        private void BtnPatternGenerate_Click(object sender, RoutedEventArgs e)
        {
            var genWindow = new ManifestGeneratorWindow(startInAiMode: false)
            { Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner };
            genWindow.ShowDialog();
            LoadManifests();
        }

        private void BtnAiGenerate_Click(object sender, RoutedEventArgs e)
        {
            var genWindow = new ManifestGeneratorWindow(startInAiMode: true)
            { Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner };
            genWindow.ShowDialog();
            LoadManifests();
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();

        // ── Yardımcı ──────────────────────────────────────────────────────────

        private void AppendLog(string line)
        {
            txtLog.Text += line + "\n";
            logScroll.ScrollToBottom();
        }

        private static SolidColorBrush ColorFromHexBrush(string hex)
        {
            hex = hex.TrimStart('#');
            return new SolidColorBrush(Color.FromRgb(
                Convert.ToByte(hex[..2], 16),
                Convert.ToByte(hex[2..4], 16),
                Convert.ToByte(hex[4..6], 16)));
        }
    }
}
