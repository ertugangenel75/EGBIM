using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using EGBIMOTO.Core.Input;
using EGBIMOTO.Core.Manifest;

namespace EGBIMOTO.Addin.UI
{
    /// <summary>
    /// EgbimotoApp.RunManifest() çağrılmadan önce $INPUT token'larını çözümler.
    /// Revit'ten Level/View/Family/Param listelerini çeker, dialog gösterir.
    /// </summary>
    public sealed class ManifestInputService
    {
        private readonly Document              _doc;
        private readonly ManifestInputScanner  _scanner = new();

        public ManifestInputService(Document doc) => _doc = doc;

        /// <summary>
        /// $INPUT token yoksa manifest'i değiştirmeden döner.
        /// Kullanıcı iptal ederse null döner.
        /// </summary>
        public EgManifest? PrepareManifest(EgManifest manifest)
        {
            var defs = _scanner.Scan(manifest);
            if (defs.Count == 0) return manifest;

            var dialog = new ManifestInputDialog(manifest, defs)
            {
                AvailableLevels         = GetLevels(),
                AvailableViews          = GetViews(),
                AvailableSheets         = GetSheets(),
                AvailableFamilyTypes    = GetFamilyTypes(),
                AvailableParameterNames = GetParameterNames()
            };

            if (dialog.ShowDialog() != true || !dialog.Confirmed) return null;
            return _scanner.ApplyResolved(manifest, defs);
        }

        private List<string> GetLevels()
        {
            try { return new FilteredElementCollector(_doc).OfClass(typeof(Level)).Cast<Level>().OrderBy(l => l.Elevation).Select(l => l.Name).ToList(); }
            catch { return new List<string>(); }
        }

        private List<string> GetViews()
        {
            try { return new FilteredElementCollector(_doc).OfClass(typeof(View)).Cast<View>()
                .Where(v => !v.IsTemplate && v.ViewType != ViewType.Schedule).OrderBy(v => v.Name).Select(v => v.Name).ToList(); }
            catch { return new List<string>(); }
        }

        private List<string> GetSheets()
        {
            try { return new FilteredElementCollector(_doc).OfClass(typeof(ViewSheet)).Cast<ViewSheet>()
                .OrderBy(s => s.SheetNumber).Select(s => $"{s.SheetNumber} — {s.Name}").ToList(); }
            catch { return new List<string>(); }
        }

        private List<string> GetFamilyTypes()
        {
            try { return new FilteredElementCollector(_doc).OfClass(typeof(FamilySymbol)).Cast<FamilySymbol>()
                .OrderBy(fs => fs.FamilyName).ThenBy(fs => fs.Name)
                .Select(fs => $"{fs.FamilyName} : {fs.Name}").Distinct().ToList(); }
            catch { return new List<string>(); }
        }

        private List<string> GetParameterNames()
        {
            try
            {
                var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (ParameterElement pe in new FilteredElementCollector(_doc).OfClass(typeof(ParameterElement))) names.Add(pe.Name);
                foreach (SharedParameterElement sp in new FilteredElementCollector(_doc).OfClass(typeof(SharedParameterElement))) names.Add(sp.Name);
                return names.OrderBy(n => n).ToList();
            }
            catch { return new List<string>(); }
        }
    }
}
