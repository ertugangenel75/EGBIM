using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Mechanical;
using EGBIMOTO.Addin.Host;
using EGBIMOTO.Core.Ops;

namespace EGBIMOTO.Addin.Ops
{
    /// <summary>
    /// EGBIMOTO — Annotation Hizalama / Düzenleme Op'ları (AnnotationOps) — v10
    ///
    /// Kaynak mantık: github.com/simonmoreau/align-tag (MIT, Simon Moreau)
    /// EGBIMOTO'ya uyarlandı:
    ///   • Revit 2024+ tek API yolu (GetTaggedReferences / SetLeaderElbow / GetLeaderEnd)
    ///     — eski #if Version2019..2021 dalları kaldırıldı, Rv adaptörüyle hizalandı.
    ///   • RevitWriteScope (atomic-mode-aware Transaction/SubTransaction) ile sarıldı.
    ///   • OpContext params/log konvansiyonu, Türkçe çıktı alanları.
    ///
    /// Türk pafta pratiğinde kullanım:
    ///   — Kapı/pencere/oda etiketlerini düzenli hizalama (pafta teslim kalitesi)
    ///   — Üst üste binen tag'leri otomatik ayırma (untangle)
    ///   — Kesit/görünüş paftalarında leader çaprazlarını çözme (arrange)
    ///
    /// Op listesi:
    ///   align_tags          — seçili/görünümdeki tag'leri hizala veya eşit dağıt
    ///                         (mode: left|right|top|bottom|center|middle|
    ///                                distribute_h|distribute_v|untangle_h|untangle_v)
    ///   arrange_tags        — leader'lı tag'leri view kenarlarına otomatik diz,
    ///                         leader çaprazlarını çöz (cropbox gerekir)
    ///
    /// Hedef tipler: IndependentTag, TextNote, SpatialElementTag (RoomTag/SpaceTag/AreaTag)
    /// </summary>
    public static class AnnotationOps
    {
        // ─────────────────────────────────────────────────────────────────────
        // A01  align_tags
        //
        // input : List<Element>  (tag / text note) — boşsa aktif view'daki tüm
        //         IndependentTag + TextNote toplanır
        // params: mode      String  default="left"
        //                   left | right | top | bottom |
        //                   center | middle |
        //                   distribute_h | distribute_v |
        //                   untangle_h | untangle_v
        //         view_id   String  opsiyonel — boşsa aktif view
        //
        // output: List<Dict> {element_id, tip, mode, tasindi, durum}
        // ─────────────────────────────────────────────────────────────────────
        [EgOp("align_tags",
            RequiresTransaction = true,
            Description =
                "Seçili (veya aktif görünümdeki) tag/yazı elemanlarını hizalar ya da eşit dağıtır.\n\n" +
                "params:\n" +
                "  mode     — left | right | top | bottom | center | middle |\n" +
                "             distribute_h | distribute_v | untangle_h | untangle_v\n" +
                "             (default: left)\n" +
                "  view_id  — hedef görünüm ID'si (opsiyonel, boşsa aktif görünüm)\n\n" +
                "Hizalama view düzleminde (CropBox.Transform) yapılır. Leader'lar ölçüm için\n" +
                "geçici kaldırılıp geri yüklenir. Pinli elemanlar atlanır.\n\n" +
                "Input: List<Element> (tag/textnote) veya boş (view taranır).\n" +
                "Çıktı: List<Dictionary> — element_id, tip, mode, tasindi, durum",
            Category = "Annotation")]
        public static List<Dictionary<string, object?>> AlignTags(OpContext ctx)
        {
            var rctx     = RequireRevit(ctx);
            var doc      = rctx.Doc;
            var modeStr  = ctx.GetString("mode", "left").ToLowerInvariant();
            var viewIdStr= ctx.GetString("view_id", "");
            var alignType = ParseMode(modeStr);

            // ── Hedef görünüm ─────────────────────────────────────────────────
            View targetView = ResolveView(rctx, viewIdStr);
            if (targetView == null)
            {
                ctx.Log("  align_tags: Aktif/hedef görünüm bulunamadı → boş");
                return ErrRow("Görünüm bulunamadı.");
            }

            // ── Elemanları topla ──────────────────────────────────────────────
            var elements = ctx.InputAsOrDefault<List<Element>>(new List<Element>());
            if (elements.Count == 0)
            {
                elements = new FilteredElementCollector(doc, targetView.Id)
                    .WhereElementIsNotElementType()
                    .Where(e => e is IndependentTag or TextNote
                                || (e.GetType().IsSubclassOf(typeof(SpatialElementTag))))
                    .ToList();
            }

            if (elements.Count < 2)
            {
                ctx.Log($"  align_tags: hizalanacak en az 2 eleman gerekir (gelen: {elements.Count})");
                return ErrRow($"En az 2 eleman gerekir (gelen: {elements.Count}).");
            }

            ctx.Log($"  align_tags: mode='{modeStr}', {elements.Count} eleman, view='{targetView.Name}'");

            var rows = new List<Dictionary<string, object?>>();
            using var scope = new RevitWriteScope(doc, $"Tag Hizala: {modeStr}", rctx.IsAtomicMode);

            // ── 1. Hazırlık: leader'ları kaldır, gerçek bbox'ı ölç ────────────
            var prep = new List<PrepItem>();
            foreach (var e in elements)
            {
                XYZ? displacement = null;
                try
                {
                    switch (e)
                    {
                        case IndependentTag tag:
                            if (tag.HasLeader) tag.HasLeader = false;
                            break;
                        case TextNote note:
                            note.RemoveLeaders();
                            break;
                        case SpatialElementTag setag:
                            if (setag.HasLeader)
                            {
                                displacement = setag.LeaderEnd - setag.TagHeadPosition;
                                setag.HasLeader = false;
                            }
                            break;
                    }
                    prep.Add(new PrepItem(e, displacement));
                }
                catch (Exception ex)
                {
                    ctx.Log($"  align_tags: [{Rv.IdStr(e.Id)}] hazırlık atlandı — {ex.Message}");
                }
            }

            // Regen — kaldırılan leader sonrası bbox güncellensin
            doc.Regenerate();

            // ── 2. AnnotationBox üret (view düzleminde 2D köşe noktaları) ──────
            var boxes = prep
                .Select(p => AnnotationBox.Build(p, targetView))
                .Where(b => b != null)
                .Select(b => b!)
                .ToList();

            // ── 3. Hizala ─────────────────────────────────────────────────────
            ApplyAlign(boxes, alignType, targetView);

            // ── 4. Sonuç satırları ────────────────────────────────────────────
            foreach (var b in boxes)
            {
                rows.Add(new Dictionary<string, object?>
                {
                    ["element_id"] = Rv.IdStr(b.Parent.Id),
                    ["tip"]        = TypeLabel(b.Parent),
                    ["mode"]       = modeStr,
                    ["tasindi"]    = b.Moved,
                    ["durum"]      = b.Parent.Pinned ? "PINLI_ATLANDI" : "OK",
                });
            }

            scope.Commit();
            int moved = rows.Count(r => (bool?)r["tasindi"] == true);
            ctx.Log($"  align_tags: {moved}/{rows.Count} eleman taşındı");
            return rows;
        }

        // ─────────────────────────────────────────────────────────────────────
        // A02  arrange_tags
        //
        // input : yok (aktif view taranır — leader'lı IndependentTag'ler)
        // params: view_id  String  opsiyonel
        //
        // output: List<Dict> {element_id, taraf, durum}
        // not   : Aktif görünümde CropBox aktif olmalıdır.
        // ─────────────────────────────────────────────────────────────────────
        [EgOp("arrange_tags",
            RequiresTransaction = true,
            Description =
                "Leader'lı IndependentTag'leri görünüm kenarlarına otomatik dizer ve\n" +
                "leader çizgilerinin çaprazlarını (overlap) konum takasıyla çözer.\n\n" +
                "params:\n" +
                "  view_id  — hedef görünüm ID'si (opsiyonel, boşsa aktif görünüm)\n\n" +
                "GEREKSİNİM: hedef görünümde CropBox aktif olmalı (kenar referansı için).\n" +
                "Tag'ler leader ucunun X konumuna göre sol/sağ gruba ayrılır, kenarlara\n" +
                "eşit aralıkla yerleştirilir, sonra 2 geçişte leader çaprazları çözülür.\n\n" +
                "Input: yok (view taranır).\n" +
                "Çıktı: List<Dictionary> — element_id, taraf, durum",
            Category = "Annotation")]
        public static List<Dictionary<string, object?>> ArrangeTags(OpContext ctx)
        {
            var rctx      = RequireRevit(ctx);
            var doc       = rctx.Doc;
            var viewIdStr = ctx.GetString("view_id", "");

            View view = ResolveView(rctx, viewIdStr);
            if (view == null)
                return ErrRow("Görünüm bulunamadı.");

            if (!view.CropBoxActive)
            {
                ctx.Log("  arrange_tags: CropBox aktif değil — görünüme crop box uygulayın");
                return ErrRow("Görünümde CropBox aktif olmalı.");
            }

            var tags = new FilteredElementCollector(doc, view.Id)
                .OfClass(typeof(IndependentTag))
                .WhereElementIsNotElementType()
                .Cast<IndependentTag>()
                .Where(t => t.HasLeader)
                .ToList();

            if (tags.Count == 0)
            {
                ctx.Log("  arrange_tags: leader'lı tag bulunamadı");
                return ErrRow("Leader'lı tag bulunamadı.");
            }

            ctx.Log($"  arrange_tags: {tags.Count} leader'lı tag, view='{view.Name}'");

            using var scope = new RevitWriteScope(doc, "Tag Düzenle (Arrange)", rctx.IsAtomicMode);

            // ── Hazırlık: leader uçlarını serbest bırak, elbow'u head'e çek ───
            foreach (var tag in tags)
            {
                try
                {
                    tag.LeaderEndCondition = LeaderEndCondition.Free;
                    var rf = tag.GetTaggedReferences().FirstOrDefault();
                    if (rf != null) tag.SetLeaderElbow(rf, tag.TagHeadPosition);
                }
                catch { /* skip */ }
            }
            doc.Regenerate();

            // ── Sol/sağ grupla ────────────────────────────────────────────────
            var left  = new List<TagLeaderInfo>();
            var right = new List<TagLeaderInfo>();
            foreach (var tag in tags)
            {
                var info = TagLeaderInfo.Build(tag, doc, view);
                if (info == null) continue;
                (info.Side == Side.Left ? left : right).Add(info);
            }

            // ── Yerleşim noktaları ────────────────────────────────────────────
            var leftPts  = CreateSidePoints(view, left,  Side.Left);
            var rightPts = CreateSidePoints(view, right, Side.Right);

            // Y'ye göre sırala (leaderEnd)
            left  = left .OrderBy(x => x.LeaderEnd.X).OrderBy(x => x.LeaderEnd.Y).ToList();
            right = right.OrderByDescending(x => x.LeaderEnd.X).OrderBy(x => x.LeaderEnd.Y).ToList();

            PlaceAndUncross(leftPts,  left);
            PlaceAndUncross(rightPts, right);

            var rows = new List<Dictionary<string, object?>>();
            foreach (var info in left.Concat(right))
            {
                string status = "OK";
                try { info.UpdateTagPosition(view); }
                catch (Exception ex) { status = $"HATA: {ex.Message}"; }

                rows.Add(new Dictionary<string, object?>
                {
                    ["element_id"] = Rv.IdStr(info.Tag.Id),
                    ["taraf"]      = info.Side == Side.Left ? "Sol" : "Sağ",
                    ["durum"]      = status,
                });
            }

            scope.Commit();
            ctx.Log($"  arrange_tags: {rows.Count} tag yerleştirildi (sol: {left.Count}, sağ: {right.Count})");
            return rows;
        }

        // ═════════════════════════════════════════════════════════════════════
        //  Hizalama çekirdeği (align-tag AlignAnnotationElements'ten uyarlandı)
        // ═════════════════════════════════════════════════════════════════════

        private static void ApplyAlign(List<AnnotationBox> boxes, AlignKind kind, View view)
        {
            if (boxes.Count < 2) return;

            switch (kind)
            {
                case AlignKind.Left:
                {
                    var anchor = boxes.OrderBy(x => x.UpLeft.X).First();
                    foreach (var b in boxes)
                        b.MoveTo(new XYZ(anchor.UpLeft.X, b.UpLeft.Y, 0), kind, view);
                    break;
                }
                case AlignKind.Right:
                {
                    var anchor = boxes.OrderByDescending(x => x.UpRight.X).First();
                    foreach (var b in boxes)
                        b.MoveTo(new XYZ(anchor.UpRight.X, b.UpRight.Y, 0), kind, view);
                    break;
                }
                case AlignKind.Top:
                {
                    var anchor = boxes.OrderByDescending(x => x.UpRight.Y).First();
                    foreach (var b in boxes)
                        b.MoveTo(new XYZ(b.UpRight.X, anchor.UpRight.Y, 0), kind, view);
                    break;
                }
                case AlignKind.Bottom:
                {
                    var anchor = boxes.OrderBy(x => x.DownRight.Y).First();
                    foreach (var b in boxes)
                        b.MoveTo(new XYZ(b.DownRight.X, anchor.DownRight.Y, 0), kind, view);
                    break;
                }
                case AlignKind.Center: // ortak dikey eksen (X ortalaması)
                {
                    var sorted = boxes.OrderBy(x => x.UpRight.X).ToList();
                    double xc = (sorted.Last().Center.X + sorted.First().Center.X) / 2.0;
                    foreach (var b in sorted)
                        b.MoveTo(new XYZ(xc, b.Center.Y, 0), kind, view);
                    break;
                }
                case AlignKind.Middle: // ortak yatay eksen (Y ortalaması)
                {
                    var sorted = boxes.OrderBy(x => x.UpRight.Y).ToList();
                    double yc = (sorted.Last().Center.Y + sorted.First().Center.Y) / 2.0;
                    foreach (var b in sorted)
                        b.MoveTo(new XYZ(b.Center.X, yc, 0), kind, view);
                    break;
                }
                case AlignKind.DistributeV:
                {
                    var sorted = boxes.OrderBy(x => x.UpRight.Y).ToList();
                    var lo = sorted.First(); var hi = sorted.Last();
                    double step = (hi.Center.Y - lo.Center.Y) / (boxes.Count - 1);
                    int i = 0;
                    foreach (var b in sorted)
                    {
                        b.MoveTo(new XYZ(b.Center.X, lo.Center.Y + i * step, 0), kind, view);
                        i++;
                    }
                    break;
                }
                case AlignKind.DistributeH:
                {
                    var sorted = boxes.OrderBy(x => x.UpRight.X).ToList();
                    var lo = sorted.First(); var hi = sorted.Last();
                    double step = (hi.Center.X - lo.Center.X) / (boxes.Count - 1);
                    int i = 0;
                    foreach (var b in sorted)
                    {
                        b.MoveTo(new XYZ(lo.Center.X + i * step, b.Center.Y, 0), kind, view);
                        i++;
                    }
                    break;
                }
                case AlignKind.UntangleV:
                {
                    var sorted = boxes.OrderBy(b => b.GetLeaderEnd().Y).ToList();
                    var top = sorted.First();
                    double offset = 0;
                    foreach (var b in sorted)
                    {
                        b.MoveTo(new XYZ(b.UpLeft.X, top.UpLeft.Y + offset, 0), kind, view);
                        offset += (b.UpLeft.Y - b.DownLeft.Y); // tag yüksekliği kadar in
                    }
                    break;
                }
                case AlignKind.UntangleH:
                {
                    var sorted = boxes.OrderBy(b => b.GetLeaderEnd().X).ToList();
                    var left = sorted.First();
                    double offset = 0;
                    foreach (var b in sorted)
                    {
                        b.MoveTo(new XYZ(left.UpLeft.X + offset, b.UpLeft.Y, 0), kind, view);
                        offset += (b.UpRight.X - b.UpLeft.X); // tag genişliği kadar sağa
                    }
                    break;
                }
            }
        }

        // ═════════════════════════════════════════════════════════════════════
        //  Arrange yardımcıları (align-tag Arrange'den uyarlandı)
        // ═════════════════════════════════════════════════════════════════════

        private static void PlaceAndUncross(List<XYZ> points, List<TagLeaderInfo> tags)
        {
            foreach (var t in tags)
            {
                if (points.Count == 0) break;
                var near = NearestPoint(points, t.TagCenter);
                t.TagCenter = near;
                points.Remove(near);
            }
            Uncross(tags);
            Uncross(tags);
        }

        private static void Uncross(List<TagLeaderInfo> tags)
        {
            foreach (var a in tags)
                foreach (var b in tags)
                {
                    if (ReferenceEquals(a, b)) continue;
                    if (a.BaseLine == null || a.EndLine == null ||
                        b.BaseLine == null || b.EndLine == null) continue;

                    if (a.BaseLine.Intersect(b.BaseLine) == SetComparisonResult.Overlap
                        || a.BaseLine.Intersect(b.EndLine) == SetComparisonResult.Overlap
                        || a.EndLine.Intersect(b.BaseLine) == SetComparisonResult.Overlap
                        || a.EndLine.Intersect(b.EndLine) == SetComparisonResult.Overlap)
                    {
                        (a.TagCenter, b.TagCenter) = (b.TagCenter, a.TagCenter);
                    }
                }
        }

        private static XYZ NearestPoint(List<XYZ> points, XYZ basePt)
        {
            XYZ best = points[0];
            double bestD = basePt.DistanceTo(best);
            foreach (var p in points)
            {
                double d = basePt.DistanceTo(p);
                if (d < bestD) { best = p; bestD = d; }
            }
            return best;
        }

        private static List<XYZ> CreateSidePoints(View view, List<TagLeaderInfo> tags, Side side)
        {
            var pts = new List<XYZ>();
            if (tags.Count == 0) return pts;

            BoundingBoxXYZ bbox = view.CropBox;
            double tagH = tags.Max(x => x.TagHeight);
            double step = Math.Max(tagH * 1.2, 1e-3);
            int max = (int)Math.Round((bbox.Max.Y - bbox.Min.Y) / step);
            var baseRight = new XYZ(bbox.Max.X, bbox.Min.Y, 0);
            var baseLeft  = new XYZ(bbox.Min.X, bbox.Min.Y, 0);

            for (int i = max * 2; i > 0; i--)
                pts.Add((side == Side.Left ? baseLeft : baseRight) + new XYZ(0, step * i, 0));

            return pts;
        }

        // ═════════════════════════════════════════════════════════════════════
        //  Ortak yardımcılar
        // ═════════════════════════════════════════════════════════════════════

        private static View ResolveView(RevitOpContext rctx, string viewIdStr)
        {
            if (!string.IsNullOrEmpty(viewIdStr) && long.TryParse(viewIdStr, out long vid))
            {
                if (rctx.Doc.GetElement(Rv.MakeElementId(vid)) is View v) return v;
            }
            return rctx.UiDoc?.ActiveView ?? rctx.Doc.ActiveView;
        }

        private static AlignKind ParseMode(string m) => m switch
        {
            "left"          => AlignKind.Left,
            "right"         => AlignKind.Right,
            "top" or "up"   => AlignKind.Top,
            "bottom" or "down" => AlignKind.Bottom,
            "center"        => AlignKind.Center,
            "middle"        => AlignKind.Middle,
            "distribute_h" or "horizontally" => AlignKind.DistributeH,
            "distribute_v" or "vertically"   => AlignKind.DistributeV,
            "untangle_h"    => AlignKind.UntangleH,
            "untangle_v"    => AlignKind.UntangleV,
            _               => AlignKind.Left,
        };

        private static string TypeLabel(Element e) => e switch
        {
            IndependentTag => "Tag",
            TextNote       => "Yazı",
            RoomTag        => "Oda Etiketi",
            SpaceTag       => "Mahal Etiketi",
            AreaTag        => "Alan Etiketi",
            _ when e.GetType().IsSubclassOf(typeof(SpatialElementTag)) => "Mekan Etiketi",
            _              => e.Category?.Name ?? "Eleman",
        };

        private static List<Dictionary<string, object?>> ErrRow(string msg)
            => new() { new() { ["durum"] = "HATA", ["mesaj"] = msg } };

        private static RevitOpContext RequireRevit(OpContext ctx)
            => ctx as RevitOpContext
               ?? throw new InvalidOperationException(
                   $"[{ctx.CurrentStepId}] Bu op Revit bağlamı gerektirir.");

        // ═════════════════════════════════════════════════════════════════════
        //  İç tipler
        // ═════════════════════════════════════════════════════════════════════

        private enum AlignKind
        {
            Left, Right, Top, Bottom, Center, Middle,
            DistributeH, DistributeV, UntangleH, UntangleV
        }

        private enum Side { Left, Right }

        private sealed class PrepItem
        {
            public Element Element { get; }
            public XYZ? Displacement { get; }
            public PrepItem(Element e, XYZ? d) { Element = e; Displacement = d; }
        }

        /// <summary>
        /// Bir annotation elemanının view düzlemindeki 2D köşe kutusu.
        /// align-tag AnnotationElement'ten uyarlandı: bbox → view CropBox.Transform
        /// ile view koordinatına çevrilir, tüm hizalama 2D yapılır.
        /// </summary>
        private sealed class AnnotationBox
        {
            public Element Parent = null!;
            public XYZ UpLeft, UpRight, DownLeft, DownRight, Center = null!;
            public bool Moved;

            private Document _doc = null!;
            private View _view = null!;

            public static AnnotationBox? Build(PrepItem prep, View view)
            {
                var e = prep.Element;
                var doc = e.Document;

                var bbox = e.get_BoundingBox(view);
                if (bbox == null) return null;

                XYZ gMax = bbox.Max, gMin = bbox.Min;
                if (prep.Displacement != null)
                {
                    gMax -= prep.Displacement;
                    gMin -= prep.Displacement;
                }

                // Diyagonal seçimi (projeksiyon uzunluğu daha büyük olan köşe çifti)
                var plane = Plane.CreateByNormalAndOrigin(view.ViewDirection, view.Origin);
                double d1 = ProjDist(plane, gMax, gMin);
                var altMax = new XYZ(gMax.X, gMin.Y, gMax.Z);
                var altMin = new XYZ(gMin.X, gMax.Y, gMin.Z);
                double d2 = ProjDist(plane, altMax, altMin);
                if (d2 > d1) { gMax = altMax; gMin = altMin; }

                Transform inv = view.CropBox.Transform.Inverse;
                XYZ max = inv.OfPoint(gMax);
                XYZ min = inv.OfPoint(gMin);

                var box = new AnnotationBox
                {
                    Parent = e, _doc = doc, _view = view,
                    UpLeft    = new XYZ(Math.Min(min.X, max.X), Math.Max(max.Y, min.Y), 0),
                    UpRight   = new XYZ(Math.Max(min.X, max.X), Math.Max(max.Y, min.Y), 0),
                    DownLeft  = new XYZ(Math.Min(min.X, max.X), Math.Min(max.Y, min.Y), 0),
                    DownRight = new XYZ(Math.Max(min.X, max.X), Math.Min(max.Y, min.Y), 0),
                };
                box.Center = (box.UpRight + box.DownLeft) / 2.0;
                return box;
            }

            public XYZ GetLeaderEnd()
            {
                XYZ end = Center;
                try
                {
                    switch (Parent)
                    {
                        case IndependentTag tag when tag.HasLeader:
                            if (tag.LeaderEndCondition == LeaderEndCondition.Free)
                            {
                                var rf = tag.GetTaggedReferences().FirstOrDefault();
                                if (rf != null) end = tag.GetLeaderEnd(rf);
                            }
                            else
                            {
                                var tagged = TagLeaderInfo.GetTaggedElement(_doc, tag);
                                if (tagged != null)
                                    end = TagLeaderInfo.GetLeaderEndForElement(tagged, _view);
                            }
                            break;
                        case TextNote note when note.LeaderCount != 0:
                            end = note.GetLeaders().FirstOrDefault()?.End ?? Center;
                            break;
                        case SpatialElementTag setag when setag.HasLeader:
                            end = setag.LeaderEnd;
                            break;
                    }
                }
                catch { end = Center; }
                return end;
            }

            public void MoveTo(XYZ targetPt, AlignKind kind, View view)
            {
                if (Parent.Pinned) return;

                XYZ from = kind switch
                {
                    AlignKind.Right or AlignKind.Top => UpRight,
                    AlignKind.Bottom                 => DownRight,
                    AlignKind.Center or AlignKind.Middle or
                    AlignKind.DistributeH or AlignKind.DistributeV => Center,
                    _                                => UpLeft, // Left, Untangle*
                };

                XYZ disp = targetPt - from;
                if (disp.IsAlmostEqualTo(XYZ.Zero)) return;

                XYZ worldVec = view.CropBox.Transform.OfVector(disp);
                Transform tr = Transform.CreateTranslation(worldVec);

                switch (Parent)
                {
                    case IndependentTag tag:
                        MoveTag(tag, tr);
                        break;
                    case TextNote note:
                        MoveTextNote(note, tr);
                        break;
                    case SpatialElementTag setag:
                        MoveSpatialTag(setag, worldVec);
                        break;
                    default:
                        Parent.Location?.Move(worldVec);
                        break;
                }
                Moved = true;
            }

            private static void MoveTag(IndependentTag tag, Transform tr)
            {
                // Free leader: ucu koru, yalnız head'i taşı
                XYZ? freeEnd = null;
                Reference? rf = null;
                if (tag.HasLeader && tag.LeaderEndCondition == LeaderEndCondition.Free)
                {
                    rf = tag.GetTaggedReferences().FirstOrDefault();
                    if (rf != null) freeEnd = tag.GetLeaderEnd(rf);
                }

                tag.TagHeadPosition = tr.OfPoint(tag.TagHeadPosition);

                if (freeEnd != null && rf != null)
                    tag.SetLeaderEnd(rf, freeEnd);   // head taşınınca uç sabit kalsın
            }

            private static void MoveTextNote(TextNote note, Transform tr)
            {
                // Leader uçlarını sakla, coord taşı, uçları geri yaz
                var ends = note.LeaderCount != 0
                    ? note.GetLeaders().Select(l => (l.End, l.Elbow)).ToList()
                    : new List<(XYZ, XYZ)>();

                note.Coord = tr.OfPoint(note.Coord);

                if (ends.Count != 0)
                {
                    int i = 0;
                    foreach (var l in note.GetLeaders())
                    {
                        if (i >= ends.Count) break;
                        l.End = ends[i].Item1;
                        l.Elbow = ends[i].Item2;
                        i++;
                    }
                }
            }

            private static void MoveSpatialTag(SpatialElementTag setag, XYZ worldVec)
            {
                XYZ? leaderEnd = setag.HasLeader ? setag.LeaderEnd : (XYZ?)null;

                setag.Location?.Move(worldVec);

                // Head oda/mahal dışına çıktıysa leader aç
                if (!setag.IsOrphaned && !setag.HasLeader)
                {
                    if (setag is RoomTag rt && rt.Room != null &&
                        !rt.Room.IsPointInRoom(rt.TagHeadPosition))
                        setag.HasLeader = true;
                    else if (setag is SpaceTag sp && sp.Space != null &&
                        !sp.Space.IsPointInSpace(sp.TagHeadPosition))
                        setag.HasLeader = true;
                    else if (setag is AreaTag)
                        setag.HasLeader = true;
                }

                if (leaderEnd != null && setag.HasLeader)
                    setag.LeaderEnd = leaderEnd;
            }

            private static double ProjDist(Plane plane, XYZ a, XYZ b)
                => ProjOnPlane(a, plane).DistanceTo(ProjOnPlane(b, plane));

            private static XYZ ProjOnPlane(XYZ q, Plane plane)
            {
                XYZ n = plane.Normal.Normalize();
                return q - n.Multiply(n.DotProduct(q - plane.Origin));
            }
        }

        /// <summary>
        /// Arrange için tek bir leader'lı tag'in geometrik durumu.
        /// align-tag TagLeader'dan uyarlandı (Revit 2024+ API).
        /// </summary>
        private sealed class TagLeaderInfo
        {
            public IndependentTag Tag = null!;
            public Side Side;
            public double TagHeight, TagWidth;
            public XYZ LeaderEnd = null!;
            public Line? BaseLine, EndLine;

            private Document _doc = null!;
            private XYZ _headOffset = null!;
            private XYZ _elbow = null!;
            private XYZ _center = null!;

            public XYZ TagCenter
            {
                get => _center;
                set { _center = value; UpdateLeader(); }
            }

            public static TagLeaderInfo? Build(IndependentTag tag, Document doc, View view)
            {
                try
                {
                    var info = new TagLeaderInfo { Tag = tag, _doc = doc };

                    Transform inv = view.CropBox.Transform.Inverse;
                    XYZ head = inv.OfPoint(tag.TagHeadPosition);
                    head = new XYZ(head.X, head.Y, 0);

                    var tagged = GetTaggedElement(doc, tag);
                    info.LeaderEnd = tagged != null
                        ? GetLeaderEndForElement(tagged, view)
                        : (view.CropBox.Max + view.CropBox.Min) / 2.0;

                    // Taraf: leaderEnd view merkezinin solunda mı?
                    XYZ vc = (view.CropBox.Max + view.CropBox.Min) / 2.0;
                    info.Side = vc.X > info.LeaderEnd.X ? Side.Left : Side.Right;

                    // Tag boyutları (view düzleminde)
                    var bb = tag.get_BoundingBox(view);
                    if (bb == null) return null;
                    XYZ mx = inv.OfPoint(bb.Max);
                    XYZ mn = inv.OfPoint(bb.Min);
                    info.TagHeight = Math.Abs(mx.Y - mn.Y);
                    info.TagWidth  = Math.Abs(mx.X - mn.X);
                    info._center   = new XYZ((mx.X + mn.X) / 2.0, (mx.Y + mn.Y) / 2.0, 0);
                    info._headOffset = head - info._center;

                    info.UpdateLeader();
                    return info;
                }
                catch { return null; }
            }

            private void UpdateLeader()
            {
                XYZ ab = LeaderEnd - _center;
                double prod = ab.X * ab.Y;
                double mult = Math.Abs(prod) < 1e-12 ? 1 : prod / Math.Abs(prod);
                XYZ delta = new XYZ(ab.X - ab.Y * Math.Tan(mult * Math.PI / 4), 0, 0);
                _elbow = _center + delta;

                double tol = _doc.Application.ShortCurveTolerance;
                EndLine  = LeaderEnd.DistanceTo(_elbow) > tol
                    ? Line.CreateBound(LeaderEnd, _elbow)
                    : Line.CreateBound(XYZ.Zero, new XYZ(0, 0, 1));
                BaseLine = _elbow.DistanceTo(_center) > tol
                    ? Line.CreateBound(_elbow, _center)
                    : Line.CreateBound(XYZ.Zero, new XYZ(0, 0, 1));
            }

            public void UpdateTagPosition(View view)
            {
                Tag.LeaderEndCondition = LeaderEndCondition.Attached;

                XYZ edgeOffset = Side == Side.Left
                    ? new XYZ(-Math.Abs(TagWidth) * 0.5 - 0.1, 0, 0)
                    : new XYZ( Math.Abs(TagWidth) * 0.5 + 0.1, 0, 0);

                Tag.TagHeadPosition =
                    view.CropBox.Transform.OfPoint(_headOffset + _center + edgeOffset);

                var rf = Tag.GetTaggedReferences().FirstOrDefault();
                if (rf != null)
                    Tag.SetLeaderElbow(rf, view.CropBox.Transform.OfPoint(_elbow));
            }

            public static Element? GetTaggedElement(Document doc, IndependentTag tag)
            {
                try
                {
                    LinkElementId linkId = tag.GetTaggedElementIds().FirstOrDefault();
                    if (linkId == null) return null;

                    if (linkId.HostElementId == ElementId.InvalidElementId)
                    {
                        if (doc.GetElement(linkId.LinkInstanceId) is RevitLinkInstance li)
                        {
                            var ldoc = li.GetLinkDocument();
                            return ldoc?.GetElement(linkId.LinkedElementId);
                        }
                        return null;
                    }
                    return doc.GetElement(linkId.HostElementId);
                }
                catch { return null; }
            }

            public static XYZ GetLeaderEndForElement(Element tagged, View view)
            {
                var bb = tagged.get_BoundingBox(view);
                Transform inv = view.CropBox.Transform.Inverse;
                XYZ end = bb != null
                    ? (bb.Max + bb.Min) / 2.0
                    : (view.CropBox.Max + view.CropBox.Min) / 2.0 + new XYZ(0.001, 0, 0);
                end = inv.OfPoint(end);
                return new XYZ(Math.Round(end.X, 4), Math.Round(end.Y, 4), 0);
            }
        }
    }
}
