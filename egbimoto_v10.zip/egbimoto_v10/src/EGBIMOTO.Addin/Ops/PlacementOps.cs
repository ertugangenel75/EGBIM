using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using EGBIMOTO.Addin.Host;
using EGBIMOTO.Core.Ops;

namespace EGBIMOTO.Addin.Ops
{
    /// <summary>
    /// EGBIMOTO V4 — Yerleştirme Op'ları (PlacementOps)
    ///
    /// Op'lar:
    ///   collect_doors_in_room    — Odanın boundary'sindeki kapıları bulur
    ///   get_door_wall_clearances — Kapının sol/sağ duvar mesafesi (mm)
    ///   calc_placement_point     — Offset + yükseklik → XYZ dict üretir
    ///   place_family_on_wall     — Duvara host family yerleştirir [Transaction]
    ///   get_room_ceiling_center  — Oda tavan merkez XYZ listesi
    ///   place_family_on_ceiling  — Tavana face-based family yerleştirir [Transaction]
    ///
    /// Transaction tarafı: STUB — iş mantığı manifest tasarımı netleşince doldurulacak.
    /// </summary>
    public static class PlacementOps
    {
        // ─────────────────────────────────────────────────────────────────────
        // P01: collect_doors_in_room
        // ─────────────────────────────────────────────────────────────────────

        [EgOp("collect_doors_in_room",
            Description = "Odanın boundary segmentlerinden host duvarlarını bulur, o duvarlardaki kapıları döner",
            Category    = "Yerleştirme")]
        public static List<Element> CollectDoorsInRoom(OpContext ctx)
        {
            var rctx = RequireRevit(ctx);
            var rooms = ctx.InputAsOrDefault<List<Element>>();

            var result = new List<Element>();

            foreach (var el in rooms)
            {
                if (el is not Room room) continue;

                // Oda boundary duvarlarını topla
                var opts     = new SpatialElementBoundaryOptions();
                var segments = room.GetBoundarySegments(opts);
                var wallIds  = new HashSet<ElementId>();

                foreach (var loop in segments)
                foreach (var seg in loop)
                {
                    var hostId = seg.ElementId;
                    if (hostId != ElementId.InvalidElementId)
                        wallIds.Add(hostId);
                }

                // Bu duvarları host eden kapıları bul
                var doors = new FilteredElementCollector(rctx.Doc)
                    .OfCategory(BuiltInCategory.OST_Doors)
                    .WhereElementIsNotElementType()
                    .Cast<FamilyInstance>()
                    .Where(fi =>
                    {
                        var hostId = fi.Host?.Id;
                        return hostId != null && wallIds.Contains(hostId);
                    })
                    .Cast<Element>();

                result.AddRange(doors);
            }

            // Tekrar edenleri kaldır
            result = result
                .GroupBy(e => Rv.GetId(e.Id))
                .Select(g => g.First())
                .ToList();

            ctx.Log($"  collect_doors_in_room: {rooms.Count} oda → {result.Count} kapı");
            return result;
        }

        // ─────────────────────────────────────────────────────────────────────
        // P02: get_door_wall_clearances
        // ─────────────────────────────────────────────────────────────────────

        [EgOp("get_door_wall_clearances",
            Description = "Her kapı için duvardaki sol/sağ serbest mesafeyi mm olarak döner",
            Category    = "Yerleştirme")]
        public static List<Dictionary<string, object?>> GetDoorWallClearances(OpContext ctx)
        {
            var rctx  = RequireRevit(ctx);
            var doors = ctx.InputAsOrDefault<List<Element>>();
            var rows  = new List<Dictionary<string, object?>>();

            foreach (var el in doors)
            {
                if (el is not FamilyInstance fi) continue;
                if (fi.Host is not Wall wall)    continue;

                // Kapı genişliği (ft → mm)
                double doorWidthMm = 0;
                var widthParam = fi.Symbol.get_Parameter(BuiltInParameter.DOOR_WIDTH);
                if (widthParam != null)
                    doorWidthMm = widthParam.AsDouble() * 304.8;

                // Duvar uzunluğu (LocationCurve → ft → mm)
                double wallLengthMm = 0;
                if (wall.Location is LocationCurve lc)
                    wallLengthMm = lc.Curve.Length * 304.8;

                // Kapı konumu duvar boyunca (projeksiyon)
                double leftMm  = 0;
                double rightMm = 0;

                if (fi.Location is LocationPoint lp && wall.Location is LocationCurve wallCurve)
                {
                    var pt       = lp.Point;
                    var line     = wallCurve.Curve;
                    double param = line.Project(pt).Parameter;   // normalize edilmemiş ft
                    double distFromStart = param * 304.8;        // mm

                    leftMm  = distFromStart - doorWidthMm / 2.0;
                    rightMm = wallLengthMm - distFromStart - doorWidthMm / 2.0;
                }

                rows.Add(new Dictionary<string, object?>
                {
                    ["element_id"]    = Rv.IdStr(el.Id),
                    ["wall_id"]       = Rv.IdStr(wall.Id),
                    ["left_mm"]       = Math.Round(leftMm,  1),
                    ["right_mm"]      = Math.Round(rightMm, 1),
                    ["door_width_mm"] = Math.Round(doorWidthMm, 1),
                    ["wall_length_mm"]= Math.Round(wallLengthMm, 1),
                });
            }

            ctx.Log($"  get_door_wall_clearances: {rows.Count} kapı işlendi");
            return rows;
        }

        // ─────────────────────────────────────────────────────────────────────
        // P03: calc_placement_point
        // ─────────────────────────────────────────────────────────────────────

        [EgOp("calc_placement_point",
            Description = "Girdi elemanının origin'inden offset_x/y_mm + height_mm ile XYZ dict üretir",
            Category    = "Yerleştirme")]
        public static Dictionary<string, object?> CalcPlacementPoint(OpContext ctx)
        {
            var rctx     = RequireRevit(ctx);
            var elements = ctx.InputAsOrDefault<List<Element>>();

            double offsetXft = ctx.GetDouble("offset_x_mm", 0) / 304.8;
            double offsetYft = ctx.GetDouble("offset_y_mm", 0) / 304.8;
            double heightFt  = ctx.GetDouble("height_mm",   0) / 304.8;

            var first = elements.FirstOrDefault();
            XYZ origin = XYZ.Zero;
            ElementId levelId = ElementId.InvalidElementId;

            if (first?.Location is LocationPoint lp)
                origin = lp.Point;
            else if (first?.Location is LocationCurve lcv)
                origin = lcv.Curve.Evaluate(0.5, true);

            // Level bul
            var lvlParam = first?.get_Parameter(BuiltInParameter.FAMILY_LEVEL_PARAM)
                        ?? first?.get_Parameter(BuiltInParameter.ROOM_LEVEL_ID);
            if (lvlParam != null)
                levelId = lvlParam.AsElementId();

            var target = new XYZ(
                origin.X + offsetXft,
                origin.Y + offsetYft,
                origin.Z + heightFt);

            ctx.Log($"  calc_placement_point: ({target.X:F3}, {target.Y:F3}, {target.Z:F3}) ft");
            return new Dictionary<string, object?>
            {
                ["x"]        = target.X,
                ["y"]        = target.Y,
                ["z"]        = target.Z,
                ["level_id"] = levelId.Value.ToString(),
            };
        }

        // ─────────────────────────────────────────────────────────────────────
        // P04: get_room_ceiling_center
        // ─────────────────────────────────────────────────────────────────────

        [EgOp("get_room_ceiling_center",
            Description = "Her odanın tavan düzeyindeki merkez XYZ koordinatını döner",
            Category    = "Yerleştirme")]
        public static List<Dictionary<string, object?>> GetRoomCeilingCenter(OpContext ctx)
        {
            var rctx  = RequireRevit(ctx);
            var rooms = ctx.InputAsOrDefault<List<Element>>();
            var rows  = new List<Dictionary<string, object?>>();

            foreach (var el in rooms)
            {
                if (el is not Room room) continue;

                // Oda üst yüzey yüksekliği: alt kotu + tavan yüksekliği (ft)
                double floorElev   = room.Level?.Elevation ?? 0;
                double roomHeightFt = room.get_Parameter(BuiltInParameter.ROOM_HEIGHT)
                                         ?.AsDouble() ?? 0;
                double ceilingZ    = floorElev + roomHeightFt;

                // Oda merkezi: Location veya bounding box XY ortası
                double cx = 0, cy = 0;
                if (room.Location is LocationPoint lp)
                {
                    cx = lp.Point.X;
                    cy = lp.Point.Y;
                }
                else
                {
                    var bb = room.get_BoundingBox(null);
                    if (bb != null)
                    {
                        cx = (bb.Min.X + bb.Max.X) / 2.0;
                        cy = (bb.Min.Y + bb.Max.Y) / 2.0;
                    }
                }

                rows.Add(new Dictionary<string, object?>
                {
                    ["element_id"] = Rv.IdStr(room.Id),
                    ["room_name"]  = room.Name,
                    ["x"]          = Math.Round(cx,        6),
                    ["y"]          = Math.Round(cy,        6),
                    ["z"]          = Math.Round(ceilingZ,  6),
                });
            }

            ctx.Log($"  get_room_ceiling_center: {rows.Count} oda");
            return rows;
        }

        // ─────────────────────────────────────────────────────────────────────
        // P05: place_family_on_wall   [Transaction STUB]
        // ─────────────────────────────────────────────────────────────────────

        [EgOp("place_family_on_wall",
            RequiresTransaction = true,
            Description = "Duvara host family yerleştirir. Transaction gerektirir. [STUB]",
            Category    = "Yerleştirme")]
        public static int PlaceFamilyOnWall(OpContext ctx)
        {
            var rctx       = RequireRevit(ctx);
            var walls      = ctx.InputAsOrDefault<List<Element>>();
            var familyName = ctx.GetString("family_name");
            var typeName   = ctx.GetString("type_name");
            double offsetMm   = ctx.GetDouble("offset_mm",  1200);
            double spacingMm  = ctx.GetDouble("spacing_mm", 0);

            // ── FamilySymbol bul ──────────────────────────────────────────────
            var symbol = FindFamilySymbol(rctx.Doc, familyName, typeName);
            if (symbol == null)
            {
                ctx.Log($"  place_family_on_wall: '{familyName}/{typeName}' tipi bulunamadı → 0 yerleştirme");
                return 0;
            }

            if (!symbol.IsActive)
                symbol.Activate();

            int placed = 0;

            // ── STUB: Transaction bloğu manifest runner tarafından yönetilir ──
            // Her duvar için yerleştirme noktası hesaplanır.
            // Şu an sadece sayım döner; NewFamilyInstance çağrısı
            // TransactionScope aktifken doldurulacak.
            foreach (var el in walls)
            {
                if (el is not Wall wall) continue;
                if (wall.Location is not LocationCurve lc) continue;

                double wallLenFt  = lc.Curve.Length;
                double offsetFt   = offsetMm  / 304.8;
                double spacingFt  = spacingMm / 304.8;

                // Kaç adet yerleştirileceğini hesapla (spacing > 0 ise çoklu)
                int count = spacingFt > 0
                    ? Math.Max(1, (int)(wallLenFt / spacingFt))
                    : 1;

                // TODO: rctx.Doc.Create.NewFamilyInstance(point, symbol, wall, level, StructuralType.NonStructural)
                placed += count;
            }

            ctx.Log($"  place_family_on_wall [STUB]: {walls.Count} duvar → {placed} eleman (transaction olmadan)");
            return placed;
        }

        // ─────────────────────────────────────────────────────────────────────
        // P06: place_family_on_ceiling   [Transaction STUB]
        // ─────────────────────────────────────────────────────────────────────

        [EgOp("place_family_on_ceiling",
            RequiresTransaction = true,
            Description = "Tavan yüzeyine face-based family yerleştirir. Transaction gerektirir. [STUB]",
            Category    = "Yerleştirme")]
        public static int PlaceFamilyOnCeiling(OpContext ctx)
        {
            var rctx       = RequireRevit(ctx);
            var ceilings   = ctx.InputAsOrDefault<List<Element>>();
            var familyName = ctx.GetString("family_name");
            var typeName   = ctx.GetString("type_name");
            double offsetXmm = ctx.GetDouble("offset_x_mm", 0);
            double offsetYmm = ctx.GetDouble("offset_y_mm", 0);

            var symbol = FindFamilySymbol(rctx.Doc, familyName, typeName);
            if (symbol == null)
            {
                ctx.Log($"  place_family_on_ceiling: '{familyName}/{typeName}' tipi bulunamadı → 0 yerleştirme");
                return 0;
            }

            if (!symbol.IsActive)
                symbol.Activate();

            int placed = 0;

            foreach (var el in ceilings)
            {
                if (el is not Ceiling ceiling) continue;

                var bb = ceiling.get_BoundingBox(null);
                if (bb == null) continue;

                // Tavan merkezi
                double cx = (bb.Min.X + bb.Max.X) / 2.0 + offsetXmm / 304.8;
                double cy = (bb.Min.Y + bb.Max.Y) / 2.0 + offsetYmm / 304.8;
                double cz =  bb.Max.Z;                          // üst yüzey

                // Face-based referans: tavan alt yüzü
                // TODO: Options.ComputeReferences=true ile GeometryElement al,
                //       alt face'i bul → rctx.Doc.Create.NewFamilyInstance(face, pt, dir, symbol)
                _ = new XYZ(cx, cy, cz); // placeholder — compiler uyarısını önler

                placed++;
            }

            ctx.Log($"  place_family_on_ceiling [STUB]: {ceilings.Count} tavan → {placed} eleman (transaction olmadan)");
            return placed;
        }

        // ─────────────────────────────────────────────────────────────────────
        // P07: place_family_along_mep   (GERÇEK — askı/destek yerleştirme)
        //
        // Boru/kanal/kablo taşıyıcı hatları boyunca, belirtilen aralıkla
        // (spacing_mm) verilen aileyi (askı, destek, etiket vb.) yerleştirir.
        // Manuel family + manuel aralık → manifest ile tam kontrol.
        //
        // Hat boyunca yürüme: her segment LocationCurve'ü uçtan uca,
        // uç boşluğu (end_setback_mm) bırakarak spacing aralıklarla bölünür.
        //
        // input : List<Element>  (Pipe/Duct/CableTray segmentleri)
        // params: family_name      String  zorunlu (askı ailesi)
        //         type_name        String  zorunlu (aile tipi)
        //         spacing_mm       Double  default=2000  (askı arası mesafe)
        //         end_setback_mm   Double  default=300   (hat ucundan boşluk)
        //         vertical_offset_mm Double default=0    (hat altına/üstüne kaydırma)
        //
        // output: List<Dictionary> — host_id, placed_count, spacing_mm, run_length_m
        // ─────────────────────────────────────────────────────────────────────
        [EgOp("place_family_along_mep",
            RequiresTransaction = true,
            Description =
                "Boru/kanal/kablo taşıyıcı hatları boyunca belirtilen aralıkla (spacing_mm) " +
                "verilen aileyi (askı, destek, etiket) yerleştirir. Manuel family + manuel aralık.\n" +
                "Input: List<Element> (MEP hat segmentleri). " +
                "params: family_name, type_name (zorunlu), spacing_mm (default 2000), " +
                "end_setback_mm (default 300), vertical_offset_mm (default 0).",
            Category = "Yerleştirme")]
        public static List<Dictionary<string, object?>> PlaceFamilyAlongMep(OpContext ctx)
        {
            var rctx       = RequireRevit(ctx);
            var doc        = rctx.Doc;
            var runs       = ctx.InputAsOrDefault<List<Element>>(new List<Element>());
            var familyName = ctx.GetString("family_name", "");
            var typeName   = ctx.GetString("type_name", "");
            double spacingMm   = ctx.GetDouble("spacing_mm",        2000);
            double endSetbackMm= ctx.GetDouble("end_setback_mm",    300);
            double vOffsetMm   = ctx.GetDouble("vertical_offset_mm", 0);

            var results = new List<Dictionary<string, object?>>();

            if (string.IsNullOrWhiteSpace(familyName) || string.IsNullOrWhiteSpace(typeName))
            {
                results.Add(new Dictionary<string, object?>
                {
                    ["status"]  = "PARAM_MISSING",
                    ["message"] = "family_name ve type_name zorunludur."
                });
                return results;
            }

            var symbol = FindFamilySymbol(doc, familyName, typeName);
            if (symbol == null)
            {
                results.Add(new Dictionary<string, object?>
                {
                    ["status"]  = "FAMILY_NOT_FOUND",
                    ["message"] = $"'{familyName}/{typeName}' tipi projede bulunamadı."
                });
                return results;
            }

            if (!symbol.IsActive) symbol.Activate();

            double spacingFt = spacingMm    / 304.8;
            double setbackFt = endSetbackMm / 304.8;
            double vOffsetFt = vOffsetMm    / 304.8;

            if (spacingFt <= 0) spacingFt = 2000 / 304.8;

            using var scope = new RevitWriteScope(doc, "MEP Hattı Boyunca Aile Yerleştir", rctx.IsAtomicMode);

            foreach (var run in runs)
            {
                if (run.Location is not LocationCurve lc || lc.Curve == null) continue;

                var curve   = lc.Curve;
                double lenFt = curve.Length;
                if (lenFt <= 2 * setbackFt) { continue; } // çok kısa segment

                // Yerleştirilebilir bölge: setback'ten setback'e
                double startFt = setbackFt;
                double endFt   = lenFt - setbackFt;
                double usableLen = endFt - startFt;

                int count = Math.Max(1, (int)Math.Floor(usableLen / spacingFt) + 1);

                // Hattın bağlı olduğu level (varsa)
                var level = GetElementLevel(doc, run);

                int placedHere = 0;
                for (int i = 0; i < count; i++)
                {
                    double dist = startFt + i * spacingFt;
                    if (dist > endFt + 1e-6) break;

                    // Eğri üzerinde normalize parametre (0..1)
                    double t = lenFt > 0 ? dist / lenFt : 0;
                    XYZ pt;
                    try { pt = curve.Evaluate(t, true); }
                    catch { continue; }

                    if (Math.Abs(vOffsetFt) > 1e-9)
                        pt = new XYZ(pt.X, pt.Y, pt.Z + vOffsetFt);

                    try
                    {
                        FamilyInstance? inst;
                        if (level != null)
                            inst = doc.Create.NewFamilyInstance(
                                pt, symbol, level, StructuralType.NonStructural);
                        else
                            inst = doc.Create.NewFamilyInstance(
                                pt, symbol, StructuralType.NonStructural);

                        if (inst != null) placedHere++;
                    }
                    catch (Exception ex)
                    {
                        ctx.Log($"  place_family_along_mep: yerleştirme hatası ({Rv.IdStr(run.Id)}): {ex.Message}");
                    }
                }

                results.Add(new Dictionary<string, object?>
                {
                    ["host_id"]      = Rv.GetId(run.Id),
                    ["category"]     = run.Category?.Name ?? "?",
                    ["placed_count"] = placedHere,
                    ["spacing_mm"]   = spacingMm,
                    ["run_length_m"] = Math.Round(lenFt * 0.3048, 2),
                });
            }

            scope.Commit();
            int total = results.Sum(r => r.TryGetValue("placed_count", out var v) && v is int c ? c : 0);
            ctx.Log($"  place_family_along_mep: {runs.Count} hat → {total} aile yerleştirildi.");
            return results;
        }

        // Elemanın bağlı olduğu Level'ı bulur (null olabilir).
        private static Level? GetElementLevel(Document doc, Element el)
        {
            try
            {
                var lvlId = el.LevelId;
                if (lvlId != null && lvlId != ElementId.InvalidElementId)
                    return doc.GetElement(lvlId) as Level;

                // Yedek: RBS_START_LEVEL_PARAM (MEP eğrileri için)
                var p = el.get_Parameter(BuiltInParameter.RBS_START_LEVEL_PARAM);
                if (p != null && p.AsElementId() != ElementId.InvalidElementId)
                    return doc.GetElement(p.AsElementId()) as Level;
            }
            catch { }
            return null;
        }

        // ─────────────────────────────────────────────────────────────────────
        // Yardımcı metodlar
        // ─────────────────────────────────────────────────────────────────────

        private static RevitOpContext RequireRevit(OpContext ctx)
            => ctx as RevitOpContext
               ?? throw new InvalidOperationException(
                   $"[{ctx.CurrentStepId}] Bu op Revit bağlamı gerektirir.");

        private static FamilySymbol? FindFamilySymbol(Document doc, string familyName, string typeName)
            => new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .FirstOrDefault(s =>
                    s.FamilyName.Equals(familyName, StringComparison.OrdinalIgnoreCase) &&
                    s.Name.Equals(typeName,          StringComparison.OrdinalIgnoreCase));
    }
}
