// Copyright 2026 Ertuğan Genel
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.IO;
using System.Reflection;
using Autodesk.Revit.UI;
using EGBIMOTO.Addin.Commands;

namespace EGBIMOTO.Addin
{
    /// <summary>
    /// EGBIMOTO Addin giriş noktası — V2.0
    ///
    /// Ribbon yapısı (kalıcı 7 buton + manifest browser):
    ///   Tab: EGBIMOTO
    ///     Panel: BIM Veri     → IFC, IDS, Parametre
    ///     Panel: Hesap        → Poz Eşle, Cost, Kalıp
    ///     Panel: Otomasyon    → Manifest Browser
    ///
    /// Yeni buton eklemek:
    ///   1. Commands/ altına yeni IExternalCommand yaz
    ///   2. Aşağıya bir AddButton() satırı ekle
    ///   3. Build et — bitti
    /// </summary>
    public sealed class App : IExternalApplication
    {
        public Result OnStartup(UIControlledApplication app)
        {
            try
            {
                var addinDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)!;
                EgbimotoApp.Initialize(addinDir);
                BuildRibbon(app, addinDir);
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("EGBIMOTO — Başlatma Hatası", ex.ToString());
                return Result.Failed;
            }
        }

        public Result OnShutdown(UIControlledApplication app) => Result.Succeeded;

        // ── Ribbon ────────────────────────────────────────────────────────────

        private static void BuildRibbon(UIControlledApplication app, string addinDir)
        {
            var asm = Assembly.GetExecutingAssembly().Location;

            // Tab
            try { app.CreateRibbonTab("EGBIMOTO"); } catch { /* zaten var */ }

            // ── Panel: BIM Veri ────────────────────────────────────────────────
            var pBimVeri = app.CreateRibbonPanel("EGBIMOTO", "BIM Veri");

            AddButton(pBimVeri, asm, "EG_IFC",    "IFC\nDışa Aktar",  typeof(IfcExportCommand),
                "Modeli IFC formatında dışa aktarır.");

            AddButton(pBimVeri, asm, "EG_IDS",    "IDS\nDoğrula",     typeof(IdsValidateCommand),
                "IDS kurallarına göre model doğrular.");

            AddButton(pBimVeri, asm, "EG_PARAM",  "Parametre\nEkle",  typeof(ParamAddCommand),
                "EGBIM paylaşımlı parametrelerini modele ekler.");

            // ── Panel: Hesap ───────────────────────────────────────────────────
            var pHesap = app.CreateRibbonPanel("EGBIMOTO", "Hesap");

            AddButton(pHesap, asm, "EG_POZ",   "Poz\nEşle",       typeof(PozMatchCommand),
                "Elemanları ÇŞB 2026 poz kodlarıyla eşleştirir.");

            AddButton(pHesap, asm, "EG_COST",  "Maliyet\nHesap",  typeof(CostCalcCommand),
                "Seçili elemanlara göre maliyet hesabı yapar.");

            AddButton(pHesap, asm, "EG_KALIP", "Kalıp\nKontrol",  typeof(KalipControlCommand),
                "Kalıp yüzey metrajı hesaplar ve raporlar.");

            // ── Panel: Otomasyon ───────────────────────────────────────────────
            var pOto = app.CreateRibbonPanel("EGBIMOTO", "Otomasyon");

            AddButton(pOto, asm, "EG_BROWSER", "Manifest\nBrowser", typeof(ManifestBrowserCommand),
                "Tüm manifest iş akışlarını listeler ve çalıştırır.");
        }

        private static void AddButton(
            RibbonPanel panel,
            string      assemblyPath,
            string      name,
            string      text,
            Type        commandType,
            string      tooltip = "")
        {
            var data = new PushButtonData(name, text, assemblyPath, commandType.FullName!)
            {
                ToolTip = tooltip
            };
            try { panel.AddItem(data); }
            catch { /* duplicate — skip */ }
        }
    }
}
