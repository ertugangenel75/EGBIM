param(
  [string]$Configuration = "Release"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Project = Join-Path $Root "src\EGBIMOTO.Addin\EGBIMOTO.Addin.csproj"

if (!(Test-Path $Project)) {
  throw "Project file not found: $Project"
}

Write-Host "[EGBIMOTO] Building Revit 2026 ($Configuration)..."
dotnet build $Project -c $Configuration -p:RevitVersion=2026 -p:Platform=x64

$candidates = @(
  (Join-Path $Root "src\EGBIMOTO.Addin\bin\x64\$Configuration\net8.0-windows"),
  (Join-Path $Root "src\EGBIMOTO.Addin\bin\$Configuration\net8.0-windows")
)

$outDir = $null
foreach ($c in $candidates) {
  if (Test-Path (Join-Path $c "EGBIMOTO.Addin.dll")) { $outDir = $c; break }
}
if ($null -eq $outDir) {
  throw "Build output not found. Checked: $($candidates -join ', ')"
}

$revitAddins = Join-Path $env:APPDATA "Autodesk\Revit\Addins\2026"
$deployDir = Join-Path $revitAddins "EGBIMOTO"
New-Item -ItemType Directory -Force -Path $deployDir | Out-Null

Write-Host "[EGBIMOTO] Copying files to $deployDir"
Copy-Item -Path (Join-Path $outDir "*") -Destination $deployDir -Recurse -Force

$assemblyPath = Join-Path $deployDir "EGBIMOTO.Addin.dll"
$addinFile = Join-Path $revitAddins "EGBIMOTO.addin"
$addinXml = @"
<?xml version="1.0" encoding="utf-8" standalone="no"?>
<RevitAddIns>
  <AddIn Type="Application">
    <Name>EGBIMOTO</Name>
    <Assembly>$assemblyPath</Assembly>
    <AddInId>8F4D1F76-7C7A-4C8F-B7B5-7B5E7A202607</AddInId>
    <FullClassName>EGBIMOTO.Addin.App</FullClassName>
    <VendorId>EG</VendorId>
    <VendorDescription>EGBIMOTO</VendorDescription>
  </AddIn>
</RevitAddIns>
"@
Set-Content -Path $addinFile -Value $addinXml -Encoding UTF8

Write-Host "[EGBIMOTO] Deployed for Revit 2026"
Write-Host "[EGBIMOTO] Addin file: $addinFile"
Write-Host "[EGBIMOTO] Assembly:   $assemblyPath"
