# EGBIMOTO — Dokümantasyon

EGBIMOTO, Revit için manifest-tabanlı BIM otomasyon platformu. Türk AEC
standartlarına (TR BIM, ÇŞB 2026, TS500, TBDY 2018, IFC/IDS) odaklı.

## Kılavuzlar

| Doküman | İçerik |
|---------|--------|
| [HIZLI_BASLANGIC.md](HIZLI_BASLANGIC.md) | Kurulum, ilk manifest çalıştırma, AI üretici |
| [KURULUM_DAGITIM.md](KURULUM_DAGITIM.md) | İki kurulum yöntemi, MSI installer, çoklu Revit sürümü |
| [MANIFEST_YAZIM_REHBERI.md](MANIFEST_YAZIM_REHBERI.md) | Manifest JSON yapısı, DAG mantığı, örnekler |
| [OP_REFERANSI.md](OP_REFERANSI.md) | 384 op'un kategoriye göre tam referansı |
| [MIMARI.md](MIMARI.md) | Katmanlar, çalışma akışı, tasarım ilkeleri |

## Hızlı Bakış

- **384 operasyon**, 16 kategori
- **222 hazır manifest**, 30+ klasör
- **2 katman:** `EGBIMOTO.Core` (Revit bağımsız) + `EGBIMOTO.Addin` (Revit bağlı)
- **3 Revit sürümü:** 2024, 2025, 2026
- **AI + Pattern** manifest üretimi

## Değişiklik Notları

Sürüm geçmişi için kök dizindeki `CHANGELOG_v*.md` dosyalarına bakın.
En güncel: `CHANGELOG_v10.md`.
