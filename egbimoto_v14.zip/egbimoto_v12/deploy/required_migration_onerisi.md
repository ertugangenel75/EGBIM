# GetX → RequireX Migrasyon Adayları

Kodda default'suz okunan (`presence: recommended`) VE 356 manifest korpusunda
kullanıldığı her adımda açıkça verilen paramlar. RequireX'e geçiş mevcut
manifestleri KIRMAZ (korpusta %100 veriliyor) ve eksik girdide net hata sağlar.

| Op | Param | Tip | Korpus kullanımı |
|---|---|---|---|
| `schedule_gate` | `title` | String | 3/3 |
| `table_validate_schema` | `optional_fields` | String | 4/4 |
